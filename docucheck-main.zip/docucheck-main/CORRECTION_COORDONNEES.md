# 🔧 Corrections de la détection des zones manuscrites

## ❌ Problème identifié

Vous avez reçu des coordonnées `0.00,1.63,99.49,97.43` qui couvrent **presque toute la page** (99.49% × 97.43%), ce qui n'est clairement pas correct pour une zone manuscrite.

### Causes du problème

L'algorithme initial était **trop permissif** :
- Considérait tout texte avec confiance < 80% comme manuscrit
- Regroupait les zones trop facilement (distance 5%)
- Pas de limite sur la taille maximale des zones
- Détectait le texte imprimé comme manuscrit

## ✅ Solutions implémentées

### 1. Critères de détection plus stricts

**Avant** :
```typescript
const isLowConfidence = confidence < 80;  // Trop permissif
const isShortText = word.text.length <= 20;

if (isLowConfidence || isShortText) {  // OU = trop large
  // Détecte comme manuscrit
}
```

**Maintenant** :
```typescript
const isVeryLowConfidence = confidence < 60;  // Plus strict
const isInLowerHalf = yPosition > 40%;  // Position typique
const isShortText = word.text.length < 15;
const isSmallArea = wordArea < 2%;  // Zone petite

// Nécessite AU MOINS 2 critères sur 4
if (criteriaCount >= 2) {
  // Détecte comme manuscrit
}
```

### 2. Filtrage des zones trop grandes

```typescript
// Rejeter les zones qui couvrent plus de 30% de la page
.filter(zone => zone.area < 0.30)
```

### 3. Clustering plus restrictif

**Avant** :
- Distance horizontale : 5% de la largeur
- Distance verticale : 5% de la hauteur
- Marge : 5%

**Maintenant** :
- Distance horizontale : **2%** de la largeur
- Distance verticale : **3%** de la hauteur
- Marge : **3%**

### 4. Détection du bruit

```typescript
// Si plus de 50 zones détectées → probablement du bruit
if (potentialZones.length > 50) {
  // Appliquer un filtrage encore plus strict
  // Garder seulement confiance < 50%
}
```

### 5. Configuration centralisée

Nouveau fichier **`manuscriptDetectionConfig.ts`** avec tous les paramètres ajustables :

```typescript
export const MANUSCRIPT_DETECTION_CONFIG = {
  CONFIDENCE_THRESHOLD: 60,        // Seuil de confiance
  MIN_Y_POSITION: 40,              // Position minimale (%)
  MAX_TEXT_LENGTH: 15,             // Longueur max du texte
  MAX_WORD_AREA: 0.02,            // Surface max d'un mot (2%)
  MIN_CRITERIA_COUNT: 2,           // Critères minimum
  MAX_POTENTIAL_ZONES: 50,         // Max zones avant filtrage strict
  STRICT_CONFIDENCE_THRESHOLD: 50, // Seuil filtrage strict
  MAX_ZONE_AREA: 0.30,            // Surface max zone finale (30%)
  
  CLUSTERING: {
    MAX_DISTANCE_X: 0.02,          // 2%
    MAX_DISTANCE_Y: 0.03,          // 3%
  },
  
  ZONE_MARGIN: 0.03,               // 3%
  DEBUG_LOGS: true,
};
```

## 📊 Résultats attendus

### Avant (exemple de votre cas)
```
Coordonnées: "0.00,1.63,99.49,97.43"
→ Zone de 99.49% × 97.43% = TOUTE LA PAGE ❌
```

### Maintenant
```
Coordonnées: "15.50,72.30,25.80,12.40"
→ Zone de 25.80% × 12.40% = Zone localisée ✅
```

## 🧪 Comment tester

1. **Relancez l'analyse** sur vos documents
2. **Vérifiez les logs console** :
   ```
   Zones potentielles manuscrites détectées: X
   Zones finales après filtrage: Y
   ```
3. **Inspectez les coordonnées** :
   ```javascript
   console.log(results[0].coordinates_manuscrits);
   // Devrait être une zone raisonnable (< 40% de la page)
   ```

## ⚙️ Ajustements possibles

Si les résultats ne sont toujours pas bons, modifiez la config dans **`manuscriptDetectionConfig.ts`** :

### Si ça détecte trop (trop de zones)
```typescript
CONFIDENCE_THRESHOLD: 50,  // Plus strict
MIN_CRITERIA_COUNT: 3,     // Plus de critères requis
MAX_ZONE_AREA: 0.20,       // Zones plus petites (20%)
```

### Si ça ne détecte pas assez
```typescript
CONFIDENCE_THRESHOLD: 70,  // Plus permissif
MIN_Y_POSITION: 30,        // Chercher plus haut
MIN_CRITERIA_COUNT: 2,     // Moins de critères
```

### Profils prédéfinis

Vous pouvez aussi utiliser les profils :

```typescript
import { getDetectionProfile } from './manuscriptDetectionConfig';

// Profil STRICT - Moins de faux positifs
const strictConfig = getDetectionProfile('STRICT');

// Profil NORMAL - Par défaut
const normalConfig = getDetectionProfile('NORMAL');

// Profil PERMISSIF - Détecte plus
const permissiveConfig = getDetectionProfile('PERMISSIVE');
```

## 📝 Logs de débogage

Avec `DEBUG_LOGS: true`, vous verrez :

```
Zones potentielles manuscrites détectées: 45
Zones finales après filtrage: 3
```

Si vous voyez :
- **> 100 zones potentielles** → Seuils trop permissifs
- **0 zones finales** → Seuils trop stricts
- **1-5 zones finales** → Probablement correct ✅

## 🔍 Validation visuelle

Utilisez le composant `ManuscriptZoneOverlay` pour visualiser :

```tsx
<ManuscriptZoneOverlay
  coordinates={analysis.coordinates_manuscrits}
  imageWidth={imageWidth}
  imageHeight={imageHeight}
/>
```

La zone devrait entourer uniquement les éléments manuscrits, pas toute la page.

## 📚 Fichiers modifiés

1. **`manuscriptDetectionService.ts`** - Algorithme amélioré
2. **`manuscriptDetectionConfig.ts`** - Configuration centralisée (nouveau)

## 🎯 Prochaines étapes

1. **Testez** avec vos documents
2. **Vérifiez** les coordonnées dans la console
3. **Ajustez** la config si nécessaire
4. **Validez** visuellement avec le composant overlay

Si les coordonnées sont toujours incorrectes, partagez-moi :
- Les nouvelles coordonnées obtenues
- Le type de document (devis, facture, etc.)
- Où se trouvent réellement les éléments manuscrits sur la page

Et je pourrai affiner encore plus l'algorithme ! 🚀
