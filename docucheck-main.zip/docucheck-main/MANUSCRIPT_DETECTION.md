# Détection automatique des zones manuscrites

## Vue d'ensemble

Cette fonctionnalité combine **GPT-4o Vision** et **Tesseract.js** pour une détection précise des éléments manuscrits dans les documents CEE :

- **GPT-4o Vision** : Identifie et lit les éléments manuscrits (signatures, tampons, textes)
- **Tesseract.js OCR** : Localise précisément ces éléments avec des coordonnées exactes

## Architecture

```
Image → GPT Vision (détection sémantique) → Tesseract (localisation) → Résultat fusionné
```

### Services créés

1. **`manuscriptDetectionService.ts`**
   - Détecte les zones manuscrites avec Tesseract
   - Calcule les bounding boxes précises
   - Distingue manuscrit vs imprimé
   - Fonctionne côté client (pas de coût API)

2. **`gptVisionService.ts`** (modifié)
   - GPT se concentre sur la compréhension sémantique
   - Appelle automatiquement la détection manuscrite
   - Fusionne les résultats

3. **`ManuscriptZoneOverlay.tsx`** (composant)
   - Visualise les zones détectées sur l'image
   - Overlay rouge semi-transparent

## Utilisation

### 1. Analyse automatique

Le service `analyzeDocumentWithGpt` détecte automatiquement les coordonnées :

```typescript
import { analyzeDocumentWithGpt } from '@/services/gptVisionService';

const results = await analyzeDocumentWithGpt(imageDataUrls);

// Les résultats contiennent maintenant les coordonnées précises
results.forEach(page => {
  console.log('Coordonnées manuscrites:', page.coordinates_manuscrits);
  // Format: "x,y,width,height" (en pourcentage 0-100)
});
```

### 2. Détection manuelle (optionnel)

Si vous voulez utiliser uniquement la détection :

```typescript
import { detectManuscriptZones } from '@/services/manuscriptDetectionService';

const detection = await detectManuscriptZones(imageDataUrl);

console.log('Zones trouvées:', detection.zones);
console.log('Boîte englobante:', detection.globalBoundingBox);
```

### 3. Visualisation

Utilisez le composant pour afficher les zones détectées :

```tsx
import { ManuscriptZoneOverlay } from '@/components/ManuscriptZoneOverlay';

<div style={{ position: 'relative' }}>
  <img src={imageUrl} alt="Document" />
  <ManuscriptZoneOverlay
    coordinates={analysis.coordinates_manuscrits}
    imageWidth={imageWidth}
    imageHeight={imageHeight}
  />
</div>
```

## Format des coordonnées

Les coordonnées sont en **pourcentage** (0-100) de la taille de l'image :

```
"x,y,width,height"
```

- **x** : Position X du coin supérieur gauche (% de la largeur)
- **y** : Position Y du coin supérieur gauche (% de la hauteur)
- **width** : Largeur de la zone (% de la largeur)
- **height** : Hauteur de la zone (% de la hauteur)

**Exemple** : `"15.5,72.3,25.8,12.4"` signifie :
- Zone commence à 15.5% de la gauche
- Zone commence à 72.3% du haut
- Zone fait 25.8% de largeur
- Zone fait 12.4% de hauteur

## Algorithme de détection

### 1. Analyse OCR (Tesseract)
```
Image → Tesseract → Mots avec confiance et position
```

### 2. Identification manuscrite
Critères pour identifier du manuscrit :
- Confiance OCR < 80% (texte difficile à lire)
- Texte court et isolé (≤ 20 caractères)
- Position typique (bas de page)

### 3. Clustering
- Regroupe les zones proches (5% de distance)
- Crée une boîte englobante
- Ajoute une marge de 5%

### 4. Classification
Types détectés :
- `signature` : Zone très petite
- `stamp` : Zone allongée (ratio > 2)
- `handwriting` : Texte manuscrit (confiance < 60%)
- `mixed` : Combinaison

## Avantages

✅ **Précision** : Coordonnées basées sur la vraie analyse d'image  
✅ **Automatique** : Pas besoin de configuration manuelle  
✅ **Gratuit** : Tesseract.js fonctionne côté client  
✅ **Rapide** : Traitement parallèle des pages  
✅ **Robuste** : Fallback si détection échoue  

## Limitations

⚠️ **Qualité d'image** : Nécessite des images de bonne qualité  
⚠️ **Zones manuscrites floues** : Peut manquer du texte très peu lisible  
⚠️ **Performance** : Tesseract peut être lent sur des images haute résolution  

## Configuration avancée

### Ajuster la sensibilité

Dans `manuscriptDetectionService.ts`, vous pouvez modifier :

```typescript
// Seuil de confiance pour identifier du manuscrit
const isLowConfidence = confidence < 80; // Augmenter = plus strict

// Distance de clustering
const maxDistanceX = imageWidth * 0.05; // Réduire = zones plus fragmentées

// Marge autour des zones
const marginX = (cluster.x2 - cluster.x) * 0.05; // Augmenter = zones plus larges
```

### Performances

Pour améliorer les performances sur de gros documents :

```typescript
// Traiter en batch avec limite
const batchSize = 5;
for (let i = 0; i < images.length; i += batchSize) {
  const batch = images.slice(i, i + batchSize);
  await detectManuscriptZonesInBatch(batch);
}
```

## Dépannage

### Les coordonnées sont vides

1. Vérifier que l'image contient du manuscrit détectable
2. Augmenter la résolution de l'image
3. Vérifier les logs console pour les erreurs Tesseract

### Les zones sont imprécises

1. Ajuster le seuil de confiance
2. Modifier les paramètres de clustering
3. Améliorer la qualité de l'image source

### Performances lentes

1. Réduire la résolution des images
2. Traiter en batch plus petit
3. Utiliser le cache pour éviter les re-détections

## Tests

Pour tester la détection :

```typescript
// Test simple
const testImage = "data:image/jpeg;base64,...";
const result = await detectManuscriptZones(testImage);

console.log('Détection réussie:', result.hasManuscript);
console.log('Nombre de zones:', result.zones.length);
console.log('Coordonnées globales:', result.globalBoundingBox);
```

## Évolutions futures

- [ ] Support multi-langues pour l'OCR
- [ ] Détection de types de signatures spécifiques
- [ ] Cache des résultats de détection
- [ ] Mode "haute précision" avec résolution adaptative
- [ ] Export des zones en JSON pour validation manuelle
