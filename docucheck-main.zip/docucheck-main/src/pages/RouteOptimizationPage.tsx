
import { useState, useEffect } from "react";
import { useToast } from "@/components/ui/use-toast";
import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import RouteMap from "@/components/route/RouteMap";
import DepartementMap from "@/components/route/DepartementMap";
import AppointmentList from "@/components/route/AppointmentList";
import LocationForm from "@/components/route/LocationForm";
import AppointmentUploader from "@/components/route/AppointmentUploader";
import AppointmentShareTools from "@/components/route/AppointmentShareTools";
import { Appointment, OptimizedRoute } from "@/types/route";
import { optimizeRoute } from "@/services/routeOptimizationService";

const RouteOptimizationPage = () => {
  const { toast } = useToast();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [filteredAppointments, setFilteredAppointments] = useState<Appointment[]>([]);
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [optimizedRoute, setOptimizedRoute] = useState<OptimizedRoute | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Try to get user's location on page load
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          toast({
            title: "Localisation réussie",
            description: "Votre position actuelle a été détectée",
          });
        },
        (error) => {
          console.error("Erreur de géolocalisation:", error);
          toast({
            title: "Erreur de localisation",
            description: "Impossible de détecter votre position actuelle",
            variant: "destructive",
          });
        }
      );
    }
  }, [toast]);

  // Filtrer les rendez-vous en fonction du département sélectionné
  useEffect(() => {
    if (selectedDepartment) {
      const filtered = appointments.filter(app => {
        const postalCodeMatch = app.address.match(/\b\d{5}\b/);
        if (!postalCodeMatch) return false;
        const appointmentDeptCode = postalCodeMatch[0].substring(0, 2);
        return appointmentDeptCode === selectedDepartment;
      });
      setFilteredAppointments(filtered);
    } else {
      setFilteredAppointments(appointments);
    }
  }, [selectedDepartment, appointments]);

  const handleAddAppointment = (appointment: Appointment) => {
    setAppointments([...appointments, appointment]);
    toast({
      title: "Rendez-vous ajouté",
      description: `${appointment.name} ajouté à la liste`,
    });
    
    // Réinitialiser l'itinéraire optimisé car il n'est plus valide
    setOptimizedRoute(null);
  };

  const handleRemoveAppointment = (id: string) => {
    setAppointments(appointments.filter(app => app.id !== id));
    toast({
      title: "Rendez-vous supprimé",
      description: "Le rendez-vous a été retiré de la liste",
    });
    
    // Réinitialiser l'itinéraire optimisé car il n'est plus valide
    setOptimizedRoute(null);
  };

  const handleImportAppointments = (importedAppointments: Appointment[]) => {
    setAppointments(prev => [...prev, ...importedAppointments]);
    
    // Réinitialiser l'itinéraire optimisé car il n'est plus valide
    setOptimizedRoute(null);
  };

  const handleOptimizeRoute = async () => {
    if (filteredAppointments.length < 2) {
      toast({
        title: "Impossible d'optimiser",
        description: "Ajoutez au moins 2 rendez-vous pour optimiser le trajet",
        variant: "destructive",
      });
      return;
    }

    if (!currentLocation) {
      toast({
        title: "Position de départ manquante",
        description: "Veuillez définir votre position actuelle",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await optimizeRoute(currentLocation, filteredAppointments);
      setOptimizedRoute(result);
      toast({
        title: "Trajet optimisé",
        description: `Itinéraire optimisé avec ${result.waypoints.length} arrêts`,
      });
    } catch (error) {
      console.error("Erreur d'optimisation:", error);
      toast({
        title: "Erreur d'optimisation",
        description: "Impossible d'optimiser le trajet. Veuillez réessayer.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const refreshLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          toast({
            title: "Position mise à jour",
            description: "Votre position actuelle a été actualisée",
          });
        },
        (error) => {
          console.error("Erreur de géolocalisation:", error);
          toast({
            title: "Erreur de localisation",
            description: "Impossible de mettre à jour votre position",
            variant: "destructive",
          });
        }
      );
    }
  };

  const handleDepartmentClick = (deptCode: string, deptAppointments: Appointment[]) => {
    setSelectedDepartment(prevCode => prevCode === deptCode ? null : deptCode);
    
    if (deptAppointments.length > 0) {
      toast({
        title: `Département ${deptCode} sélectionné`,
        description: `${deptAppointments.length} rendez-vous dans ce département`
      });
    } else {
      toast({
        title: `Département ${deptCode} sélectionné`,
        description: "Aucun rendez-vous dans ce département"
      });
    }
    
    // Réinitialiser l'itinéraire optimisé car le filtre a changé
    setOptimizedRoute(null);
  };

  const handleAppointmentTeamChange = (appointmentId: string, teamId: string | undefined) => {
    setAppointments(appointments.map(app => 
      app.id === appointmentId ? { ...app, teamId } : app
    ));
    
    toast({
      title: "Équipe assignée",
      description: "Le rendez-vous a été assigné à l'équipe"
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6">
        <h1 className="text-3xl font-bold mb-6">Optimisation des Tournées</h1>
        
        <Tabs defaultValue="map" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="map">Carte</TabsTrigger>
            <TabsTrigger value="appointments">Rendez-vous</TabsTrigger>
            <TabsTrigger value="optimization">Optimisation</TabsTrigger>
            <TabsTrigger value="share">Équipes & Partage</TabsTrigger>
          </TabsList>
          
          <TabsContent value="map" className="space-y-4">
            <Card className="mb-4">
              <CardHeader>
                <CardTitle>Carte des rendez-vous</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4 h-[70vh]">
                  <div className="h-full">
                    <DepartementMap 
                      appointments={appointments}
                      onDepartmentClick={handleDepartmentClick}
                    />
                  </div>
                  <div className="h-full">
                    <RouteMap 
                      currentLocation={currentLocation} 
                      appointments={filteredAppointments}
                      optimizedRoute={optimizedRoute}
                    />
                  </div>
                </div>
                {selectedDepartment && (
                  <div className="mt-4">
                    <Button variant="outline" onClick={() => setSelectedDepartment(null)}>
                      {filteredAppointments.length > 0 
                        ? `Tous les départements (${appointments.length} rendez-vous)` 
                        : "Tous les départements"}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="appointments" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Gestion des rendez-vous</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-4">Ajouter un rendez-vous</h3>
                      <LocationForm 
                        onAddLocation={handleAddAppointment}
                        currentLocation={currentLocation}
                        onRefreshLocation={refreshLocation}
                      />
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-4">Importer des rendez-vous</h3>
                      <AppointmentUploader 
                        onAppointmentsImported={handleImportAppointments}
                        isLoading={isLoading}
                      />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-medium mb-4">
                      {selectedDepartment 
                        ? `Rendez-vous du département ${selectedDepartment} (${filteredAppointments.length})` 
                        : `Liste des rendez-vous (${appointments.length})`}
                    </h3>
                    <AppointmentList 
                      appointments={filteredAppointments}
                      onRemoveAppointment={handleRemoveAppointment} 
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="optimization" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Optimisation du trajet</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Button 
                      onClick={handleOptimizeRoute} 
                      disabled={isLoading || filteredAppointments.length < 2}
                      className="w-full mb-4"
                    >
                      {isLoading ? "Optimisation en cours..." : "Optimiser le trajet"}
                    </Button>
                    
                    {optimizedRoute && (
                      <Card>
                        <CardHeader>
                          <CardTitle>Résultats d'optimisation</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="mb-2"><strong>Distance totale:</strong> {(optimizedRoute.distance / 1000).toFixed(2)} km</p>
                          <p className="mb-2"><strong>Durée estimée:</strong> {Math.floor(optimizedRoute.duration / 60)} min</p>
                          <p className="mb-4"><strong>Nombre d'arrêts:</strong> {optimizedRoute.waypoints.length}</p>
                          
                          <h4 className="font-medium mb-2">Ordre de visite optimal:</h4>
                          <ol className="list-decimal ml-6 space-y-1">
                            {optimizedRoute.waypoints.map((point, index) => (
                              <li key={index}>{point.name}</li>
                            ))}
                          </ol>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                  <div className="h-[50vh]">
                    <RouteMap 
                      currentLocation={currentLocation} 
                      appointments={filteredAppointments}
                      optimizedRoute={optimizedRoute}
                      showOptimizedRouteOnly={true}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="share" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Partager l'itinéraire</CardTitle>
              </CardHeader>
              <CardContent>
                <AppointmentShareTools 
                  appointments={filteredAppointments}
                  optimizedWaypoints={optimizedRoute?.waypoints.map(wp => 
                    filteredAppointments.find(app => app.id === filteredAppointments[wp.originalIndex]?.id)
                  ).filter((app): app is Appointment => !!app)}
                  onAppointmentTeamChange={handleAppointmentTeamChange}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default RouteOptimizationPage;
