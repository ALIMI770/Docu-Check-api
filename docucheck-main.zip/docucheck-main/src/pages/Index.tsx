/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable prefer-rest-params */

import { useState, useEffect } from "react";
import Header from "@/components/Header";
import AnalysisReport from "@/components/AnalysisReport";
import DocumentUploadSection from "@/components/DocumentUploadSection";
import { DocumentType, DocumentStatus, AnalysisResult } from "@/types/document";
import { useToast } from "@/components/ui/use-toast";
import { analyzeDocuments } from "@/services/ocrService";
import PromptDetailsTable from "@/components/PromptDetailsTable";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge"; // Add missing Badge import
import CreditSystem from "@/components/CreditSystem";
import { initiateStripeCheckout } from "@/services/stripeService";

const Index = () => {
  const { toast } = useToast();
  const [documents, setDocuments] = useState<Record<DocumentType, DocumentStatus>>({
    devis: { uploaded: false, file: null, preview: null },
    facture: { uploaded: false, file: null, preview: null },
    attestation: { uploaded: false, file: null, preview: null },
  });
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [batchResults, setBatchResults] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [processingStep, setProcessingStep] = useState<{step: number, message: string} | null>(null);
  const [singleFileMode, setSingleFileMode] = useState(true); // Commencer par le mode PDF unique
  const [singlePdfFile, setSinglePdfFile] = useState<File | null>(null);
  const [availableCredits, setAvailableCredits] = useState(3); // Start with 3 free credits
  const [activeTab, setActiveTab] = useState<string>("upload"); // Default to upload tab

  useEffect(() => {
    const handleToast = (e: CustomEvent) => {
      toast({
        title: e.detail.title,
        description: e.detail.description,
        variant: e.detail.variant,
      });
    };

    window.addEventListener('toast', handleToast as EventListener);
    
    return () => {
      window.removeEventListener('toast', handleToast as EventListener);
    };
  }, [toast]);

  useEffect(() => {
    // Load user credits from localStorage
    const user = localStorage.getItem("user");
    if (user) {
      const userData = JSON.parse(user);
      setAvailableCredits(userData.credits || 3);
    }
  }, []);

  const handleFileUpload = (type: DocumentType, file: File) => {
    const fileUrl = URL.createObjectURL(file);
    
    setDocuments((prev) => ({
      ...prev,
      [type]: {
        uploaded: true,
        file: file,
        preview: fileUrl,
      },
    }));

    toast({
      title: "Document téléversé",
      description: `Le ${type} a été téléversé avec succès.`,
    });
  };
  
  const handleSingleFileUpload = (file: File) => {
    setSinglePdfFile(file);
    
    // Marquer tous les documents comme présents dans le mode fichier unique
    setDocuments({
      devis: { uploaded: true, file: null, preview: null },
      facture: { uploaded: true, file: null, preview: null },
      attestation: { uploaded: true, file: null, preview: null },
    });
    
    toast({
      title: "Dossier PDF téléversé",
      description: "Le dossier complet a été téléversé et sera analysé automatiquement.",
    });
  };

  const startAnalysis = async () => {
    // Check if user has enough credits
    // if (availableCredits <= 0) {
    //   toast({
    //     title: "Pas de crédits",
    //     description: "Veuillez acheter des crédits pour continuer.",
    //     variant: "destructive",
    //   });
    //   setActiveTab("credits");
    //   return;
    // }

    let canProceed = false;
    
    if (singleFileMode) {
      canProceed = !!singlePdfFile;
      if (!canProceed) {
        toast({
          title: "Dossier manquant",
          description: "Veuillez téléverser un dossier PDF complet.",
          variant: "destructive",
        });
        return;
      }
    } else {
      canProceed = Object.values(documents).some((doc) => doc.uploaded);
      if (!canProceed) {
        toast({
          title: "Documents manquants",
          description: "Veuillez téléverser au moins un document.",
          variant: "destructive",
        });
        return;
      }
    }

    setIsAnalyzing(true);
    setProcessingStep({step: 1, message: "Initialisation de l'analyse..."});
    
    const originalConsoleLog = console.log;
    console.log = function() {
      const args = Array.from(arguments);
      
      const message = args.join(' ');
      if (message.includes('Étape ')) {
        const stepMatch = message.match(/Étape (\d+)\/\d+: (.*)/);
        if (stepMatch) {
          setProcessingStep({
            step: parseInt(stepMatch[1]),
            message: stepMatch[2]
          });
        }
      }
      
      originalConsoleLog.apply(console, args);
    };
    
    try {
      let result;
      
      if (singleFileMode && singlePdfFile) {
        // Analyse en mode fichier unique
        result = await analyzeDocuments({
          devis: null,
          facture: null,
          attestation: null
        }, singlePdfFile);
      } else {
        // Analyse en mode documents séparés
        result = await analyzeDocuments({
          devis: documents.devis.file,
          facture: documents.facture.file,
          attestation: documents.attestation.file
        });
      }
      
      setAnalysisResult(result);
      
      // Update user credits in localStorage after successful analysis
      const user = localStorage.getItem("user");
      if (user) {
        const userData = JSON.parse(user);
        userData.credits = availableCredits - 1;
        localStorage.setItem("user", JSON.stringify(userData));
      }
      
      // Deduct one credit after successful analysis
      setAvailableCredits(prev => prev - 1);
      
      toast({
        title: "Analyse terminée",
        description: `Score de conformité: ${result.score}%. Il vous reste ${availableCredits - 1} crédit(s).`,
      });
    } catch (error) {
      console.error("Erreur lors de l'analyse:", error);
      toast({
        title: "Erreur d'analyse",
        description: "Une erreur est survenue lors de l'analyse des documents.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
      setProcessingStep(null);
      console.log = originalConsoleLog;
    }
  };

  const resetAnalysis = () => {
    setDocuments({
      devis: { uploaded: false, file: null, preview: null },
      facture: { uploaded: false, file: null, preview: null },
      attestation: { uploaded: false, file: null, preview: null },
    });
    setAnalysisResult(null);
    setBatchResults(null);
    setProcessingStep(null);
    setSinglePdfFile(null);
  };

  const handlePurchaseCredits = async (packageId: string) => {
    try {
      toast({
        title: "Redirection vers le paiement",
        description: "Vous allez être redirigé vers la page de paiement sécurisée.",
      });
      
      const checkoutUrl = await initiateStripeCheckout(packageId);
      
      // In a real app, redirect to Stripe checkout
      window.open(checkoutUrl, "_blank");
      
      // For demonstration, let's add credits immediately
      // In a real app, this would happen after Stripe webhook confirmation
      const creditPackages = {
        'basic': 5,
        'standard': 20,
        'premium': 50
      };
      
      setTimeout(() => {
        const creditsToAdd = creditPackages[packageId as keyof typeof creditPackages] || 0;
        const newCredits = availableCredits + creditsToAdd;
        setAvailableCredits(newCredits);
        
        // Update user credits in localStorage
        const user = localStorage.getItem("user");
        if (user) {
          const userData = JSON.parse(user);
          userData.credits = newCredits;
          localStorage.setItem("user", JSON.stringify(userData));
        }
        
        toast({
          title: "Crédits ajoutés",
          description: `${creditsToAdd} crédits ont été ajoutés à votre compte.`,
        });
      }, 3000);
      
    } catch (error) {
      console.error("Erreur lors de l'achat:", error);
      toast({
        title: "Erreur de paiement",
        description: "Une erreur est survenue lors de la redirection vers le paiement.",
        variant: "destructive",
      });
    }
  };
  
  // Gestion du traitement par lot
  const handleBatchAnalysisComplete = (results: any) => {
    // Mise à jour des crédits utilisés
    if (results.individual_analyses && results.individual_analyses.length > 0) {
      const creditsUsed = results.individual_analyses.length;
      const newCredits = Math.max(0, availableCredits - creditsUsed);
      
      setAvailableCredits(newCredits);
      
      // Update user credits in localStorage
      const user = localStorage.getItem("user");
      if (user) {
        const userData = JSON.parse(user);
        userData.credits = newCredits;
        localStorage.setItem("user", JSON.stringify(userData));
      }
    }
    
    // Affichage des résultats du traitement par lot
    setBatchResults(results);
    
    // Passer automatiquement à l'onglet des résultats par lot
    setActiveTab("batch-results");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto py-8 px-4 md:px-8">
        <Tabs defaultValue="upload" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full mb-6">
            <TabsTrigger value="upload" className="flex-1">Téléversement de documents</TabsTrigger>
            <TabsTrigger value="results" className="flex-1" disabled={!analysisResult}>Résultats d'analyse</TabsTrigger>
            <TabsTrigger value="batch-results" className="flex-1" disabled={!batchResults}>Résultats par lot</TabsTrigger>
            <TabsTrigger value="credits" className="flex-1">Mes crédits</TabsTrigger>
          </TabsList>
          
          <TabsContent value="upload">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="lg:col-span-1">
                <DocumentUploadSection
                  documents={documents}
                  isAnalyzing={isAnalyzing}
                  processingStep={processingStep}
                  onFileUpload={handleFileUpload}
                  onSingleFileUpload={handleSingleFileUpload}
                  onStartAnalysis={startAnalysis}
                  onReset={resetAnalysis}
                  hasResults={!!analysisResult}
                  singleFileMode={singleFileMode}
                  setSingleFileMode={setSingleFileMode}
                  // availableCredits={availableCredits}
                  availableCredits={30}
                  onBatchAnalysisComplete={handleBatchAnalysisComplete}
                />
              </div>
              
              <div className="lg:col-span-1">
                <Tabs defaultValue="report" className="w-full">
                  <TabsList className="w-full">
                    <TabsTrigger value="report" className="flex-1">Rapport d'analyse</TabsTrigger>
                    <TabsTrigger value="details" className="flex-1">Analyse détaillée</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="report" className="mt-4">
                    <AnalysisReport 
                      result={analysisResult} 
                      isAnalyzing={isAnalyzing} 
                      processingStep={processingStep}
                    />
                  </TabsContent>
                  
                  <TabsContent value="details" className="mt-4">
                    <PromptDetailsTable result={analysisResult} />
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="results">
            {analysisResult && (
              <div className="grid grid-cols-1 gap-6">
                {/* <AnalysisReport 
                  result={analysisResult} 
                  isAnalyzing={false} 
                  processingStep={null}
                /> */}
                <PromptDetailsTable result={analysisResult} />
              </div>
            )}
          </TabsContent>

          <TabsContent value="batch-results">
            {batchResults ? (
              <div className="grid grid-cols-1 gap-6">
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h2 className="text-xl font-semibold mb-4">Résultats d'analyse par lot</h2>
                  
                  {/* Résumé global */}
                  <div className="bg-blue-50 p-4 rounded-lg mb-6 border border-blue-100">
                    <h3 className="text-lg font-medium text-blue-800 mb-2">Résumé global</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="bg-white p-3 rounded-md shadow-sm">
                        <p className="text-sm text-gray-500">Documents analysés</p>
                        <p className="text-2xl font-bold">{batchResults.individual_analyses?.length || 0}</p>
                      </div>
                      <div className="bg-white p-3 rounded-md shadow-sm">
                        <p className="text-sm text-gray-500">Score moyen</p>
                        <p className="text-2xl font-bold">{batchResults.global_analysis?.score || 0}%</p>
                      </div>
                      <div className="bg-white p-3 rounded-md shadow-sm">
                        <p className="text-sm text-gray-500">Types de documents</p>
                        <p className="text-2xl font-bold">{Object.keys(batchResults.global_analysis?.document_types_found || {}).length}</p>
                      </div>
                      <div className="bg-white p-3 rounded-md shadow-sm">
                        <p className="text-sm text-gray-500">Cohérence SIRET</p>
                        <p className="text-2xl font-bold text-blue-600">{batchResults.global_analysis?.siret_consistency}</p>
                      </div>
                    </div>
                    
                    {/* Types de documents trouvés */}
                    {batchResults.global_analysis?.document_types_found && (
                      <div className="mt-4">
                        <h4 className="font-medium text-blue-700 mb-2">Types de documents identifiés</h4>
                        <div className="flex flex-wrap gap-2">
                          {Object.entries(batchResults.global_analysis.document_types_found).map(([type, count]: [string, any]) => (
                            <Badge key={type} variant="outline" className="bg-white">
                              {type}: {count}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {/* Liste des analyses individuelles */}
                  <h3 className="text-lg font-medium mb-3">Analyses individuelles</h3>
                  <div className="border rounded-lg overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fichier</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SIRET</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Entreprise</th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Signatures</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {batchResults.individual_analyses?.map((analysis: any, index: number) => (
                            <tr key={index} className="hover:bg-gray-50">
                              <td className="px-6 py-4 text-sm font-medium text-gray-900">
                                {analysis.filename}
                              </td>
                              <td className="px-6 py-4 text-sm text-gray-500">
                                {analysis.document_type || "Non identifié"}
                                {analysis.is_attestation_cee && (
                                  <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700">CEE</Badge>
                                )}
                              </td>
                              <td className="px-6 py-4 text-sm text-gray-500 font-mono">
                                {analysis.siret || "Non détecté"}
                              </td>
                              <td className="px-6 py-4 text-sm text-gray-500">
                                {analysis.company_name || "Non détecté"}
                              </td>
                              <td className="px-6 py-4 text-sm text-gray-500">
                                <div className="flex items-center space-x-2">
                                  <Badge 
                                    variant="outline" 
                                    className={analysis.signature ? "bg-green-50 text-green-700" : "bg-gray-100 text-gray-700"}
                                  >
                                    {analysis.signature ? "✓" : "✗"} Signature
                                  </Badge>
                                  <Badge 
                                    variant="outline" 
                                    className={analysis.stamp_present ? "bg-green-50 text-green-700" : "bg-gray-100 text-gray-700"}
                                  >
                                    {analysis.stamp_present ? "✓" : "✗"} Tampon
                                  </Badge>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-md">
                <p className="text-gray-500">Aucun résultat d'analyse par lot disponible.</p>
                <p className="mt-2 text-sm text-gray-400">Utilisez l'option "Traitement par lots" sur la page de téléversement pour analyser plusieurs documents.</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="credits">
            <CreditSystem 
              availableCredits={availableCredits}
              onPurchaseCredits={handlePurchaseCredits}
            />
          </TabsContent>
        </Tabs>
      </main>
      
      <footer className="py-6 text-center text-gray-500 mt-8 border-t">
        <p className="text-sm">
          DocuCheck AI - Solution de vérification de conformité des dossiers CEE
        </p>
      </footer>
    </div>
  );
};

export default Index;
