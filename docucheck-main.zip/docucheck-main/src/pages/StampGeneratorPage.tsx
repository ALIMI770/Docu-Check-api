
import { useState, useEffect, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/Header";
import StampGenerator from "@/components/StampGenerator";
import { Skeleton } from "@/components/ui/skeleton";

const StampGeneratorPage = () => {
  const { toast } = useToast();
  const [availableCredits, setAvailableCredits] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const isMounted = useRef(true);
  
  useEffect(() => {
    console.log("StampGeneratorPage mounted");
    // Set the mounted flag to true
    isMounted.current = true;
    
    const loadUserCredits = () => {
      try {
        const user = localStorage.getItem("user");
        if (user && isMounted.current) {
          const userData = JSON.parse(user);
          setAvailableCredits(userData.credits || 0);
          console.log("Credits loaded:", userData.credits || 0);
        } else if (isMounted.current) {
          console.log("No user found, setting credits to 0");
          setAvailableCredits(0);
        }
      } catch (error) {
        console.error("Erreur lors du chargement des crédits:", error);
        if (isMounted.current) {
          toast({
            title: "Erreur",
            description: "Impossible de charger vos crédits",
            variant: "destructive",
          });
          setAvailableCredits(0);
        }
      } finally {
        if (isMounted.current) {
          setIsLoading(false);
        }
      }
    };

    // Small delay to ensure proper DOM mounting
    const timer = setTimeout(loadUserCredits, 200);
    
    // Cleanup function to prevent state updates after unmount
    return () => {
      console.log("StampGeneratorPage unmounting");
      isMounted.current = false;
      clearTimeout(timer);
    };
  }, [toast]);
  
  const useCredits = (amount: number): boolean => {
    if (availableCredits === null || availableCredits < amount) {
      toast({
        title: "Crédits insuffisants",
        description: `Vous avez besoin de ${amount} crédit(s) pour cette opération.`,
        variant: "destructive",
      });
      return false;
    }
    
    try {
      // Mise à jour des crédits dans l'état et localStorage
      const newCredits = availableCredits - amount;
      setAvailableCredits(newCredits);
      console.log(`Credits updated: ${availableCredits} -> ${newCredits}`);
      
      // Mise à jour dans localStorage
      const user = localStorage.getItem("user");
      if (user) {
        const userData = JSON.parse(user);
        userData.credits = newCredits;
        localStorage.setItem("user", JSON.stringify(userData));
        console.log("User credits updated in localStorage");
      }
      
      toast({
        title: "Crédits utilisés",
        description: `${amount} crédit(s) ont été utilisés. Il vous reste ${newCredits} crédit(s).`,
      });
      
      return true;
    } catch (error) {
      console.error("Erreur lors de l'utilisation des crédits:", error);
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour vos crédits",
        variant: "destructive",
      });
      return false;
    }
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="container mx-auto py-8 px-4 md:px-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <Skeleton className="h-8 w-72 mb-2" />
              <Skeleton className="h-4 w-96" />
            </div>
            <Skeleton className="h-10 w-36 mt-4 md:mt-0" />
          </div>
          <Skeleton className="h-[500px] w-full rounded-lg" />
        </main>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto py-8 px-4 md:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Générateur de Tampon d'Entreprise</h1>
            <p className="text-gray-600">
              Créez un tampon professionnel et appliquez-le sur vos documents
            </p>
          </div>
          
          <div className="mt-4 md:mt-0 bg-blue-50 px-4 py-2 rounded-md border border-blue-100">
            <p className="text-blue-800 font-medium">
              {availableCredits !== null ? `${availableCredits} crédit${availableCredits !== 1 ? 's' : ''} disponible${availableCredits !== 1 ? 's' : ''}` : "Chargement des crédits..."}
            </p>
          </div>
        </div>
        
        {availableCredits !== null && (
          <StampGenerator useCredits={useCredits} />
        )}
      </main>
      
      <footer className="py-6 text-center text-gray-500 mt-8 border-t">
        <p className="text-sm">
          DocuCheck AI - Solution de vérification de conformité des dossiers CEE et génération de tampons
        </p>
      </footer>
    </div>
  );
};

export default StampGeneratorPage;
