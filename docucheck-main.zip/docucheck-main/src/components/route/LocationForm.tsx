
import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Appointment } from "@/types/route";
import { useToast } from "@/components/ui/use-toast";
import { geocodeAddress } from "@/services/geocodingService";
import { searchAddressSuggestions, AddressSuggestion } from "@/services/addressService";
import { Locate, MapPin } from "lucide-react";

interface LocationFormProps {
  onAddLocation: (location: Appointment) => void;
  currentLocation: { lat: number; lng: number } | null;
  onRefreshLocation: () => void;
}

const LocationForm = ({ onAddLocation, currentLocation, onRefreshLocation }: LocationFormProps) => {
  const { toast } = useToast();
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [addressSuggestions, setAddressSuggestions] = useState<AddressSuggestion[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [time, setTime] = useState("");
  const [duration, setDuration] = useState("");
  const [notes, setNotes] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const suggestionRef = useRef<HTMLDivElement>(null);

  // Fermer les suggestions si on clique ailleurs
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionRef.current && !suggestionRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Recherche d'adresses avec délai
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (address && address.length > 2) {
        setIsSearching(true);
        try {
          const suggestions = await searchAddressSuggestions(address);
          setAddressSuggestions(suggestions);
          setShowSuggestions(suggestions.length > 0);
        } catch (error) {
          console.error("Erreur de recherche d'adresses:", error);
        } finally {
          setIsSearching(false);
        }
      } else {
        setAddressSuggestions([]);
        setShowSuggestions(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [address]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim() || !address.trim()) {
      toast({
        title: "Champs requis",
        description: "Veuillez remplir le nom et l'adresse du rendez-vous",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Géocodage de l'adresse
      const geoResult = await geocodeAddress(address);
      
      if (!geoResult) {
        toast({
          title: "Adresse introuvable",
          description: "Impossible de localiser cette adresse. Veuillez être plus précis.",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }
      
      // Créer le nouvel appointement
      const newAppointment: Appointment = {
        id: Date.now().toString(),
        name,
        address,
        lat: geoResult.lat,
        lng: geoResult.lng,
        time: time || undefined,
        duration: duration ? parseInt(duration) : undefined,
        notes: notes || undefined,
      };
      
      onAddLocation(newAppointment);
      
      // Réinitialiser le formulaire
      setName("");
      setAddress("");
      setTime("");
      setDuration("");
      setNotes("");
      
    } catch (error) {
      console.error("Erreur lors de l'ajout du rendez-vous:", error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de l'ajout du rendez-vous",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectSuggestion = (suggestion: AddressSuggestion) => {
    setAddress(suggestion.address);
    setShowSuggestions(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Nom du client / lieu</Label>
        <Input
          id="name"
          placeholder="ex: Jean Dupont"
          value={name}
          onChange={(e) => setName(e.target.value)}
          disabled={isLoading}
        />
      </div>
      
      <div className="space-y-2 relative">
        <Label htmlFor="address">Adresse complète</Label>
        <div className="relative">
          <Input
            id="address"
            placeholder="ex: 24 Rue de Rivoli, 75004 Paris"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            disabled={isLoading}
            className={isSearching ? "pr-8" : ""}
          />
          {isSearching && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full"></div>
            </div>
          )}
          
          {/* Suggestions d'adresses */}
          {showSuggestions && (
            <div 
              ref={suggestionRef}
              className="absolute z-50 mt-1 w-full bg-background border border-input rounded-md shadow-lg max-h-60 overflow-auto"
            >
              {addressSuggestions.map((suggestion, index) => (
                <div
                  key={index}
                  className="flex items-start px-3 py-2 hover:bg-accent cursor-pointer"
                  onClick={() => handleSelectSuggestion(suggestion)}
                >
                  <MapPin className="h-4 w-4 mr-2 mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-sm">{suggestion.address}</p>
                    <p className="text-xs text-muted-foreground truncate">{suggestion.displayName}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="time">Heure (optionnel)</Label>
          <Input
            id="time"
            type="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            disabled={isLoading}
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="duration">Durée en min. (optionnel)</Label>
          <Input
            id="duration"
            type="number"
            placeholder="ex: 60"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
            disabled={isLoading}
            min="1"
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="notes">Notes (optionnel)</Label>
        <Textarea
          id="notes"
          placeholder="Informations supplémentaires..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          disabled={isLoading}
          className="resize-none"
          rows={3}
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <Button 
          type="submit" 
          disabled={isLoading || !name.trim() || !address.trim()}
          className="w-full"
        >
          {isLoading ? "Ajout en cours..." : "Ajouter le rendez-vous"}
        </Button>
        
        <Button
          type="button"
          variant="outline"
          onClick={onRefreshLocation}
          className="flex items-center justify-center gap-2 w-full"
          disabled={isLoading}
        >
          <Locate className="h-4 w-4" />
          Actualiser ma position
        </Button>
      </div>
    </form>
  );
};

export default LocationForm;
