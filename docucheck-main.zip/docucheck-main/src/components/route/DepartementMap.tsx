
import { useEffect, useRef, useState } from 'react';
import { Appointment } from '@/types/route';
import { useToast } from '@/components/ui/use-toast';

interface DepartmentData {
  code: string;
  name: string;
  count: number;
  appointments: Appointment[];
}

interface DepartementMapProps {
  appointments: Appointment[];
  onDepartmentClick: (departmentCode: string, appointments: Appointment[]) => void;
}

const DepartementMap = ({ appointments, onDepartmentClick }: DepartementMapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const [mapInitialized, setMapInitialized] = useState(false);
  const [departmentData, setDepartmentData] = useState<Record<string, DepartmentData>>({});

  // Initialiser la carte
  useEffect(() => {
    if (!mapRef.current || mapInitialized) return;

    // On utilise OpenStreetMap avec Leaflet
    const loadLeaflet = async () => {
      try {
        // Vérifier si Leaflet est déjà chargé
        if (!window.L) {
          // Charger la CSS de Leaflet
          const linkEl = document.createElement('link');
          linkEl.rel = 'stylesheet';
          linkEl.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
          document.head.appendChild(linkEl);

          // Charger le JavaScript de Leaflet
          const script = document.createElement('script');
          script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
          script.async = true;
          
          await new Promise((resolve, reject) => {
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
          });
        }

        // Initialiser la carte après le chargement de Leaflet
        setTimeout(() => {
          initMap();
          setMapInitialized(true);
        }, 100);

      } catch (error) {
        console.error('Erreur lors du chargement de Leaflet:', error);
        toast({
          title: "Erreur de chargement",
          description: "Impossible de charger la carte des départements.",
          variant: "destructive",
        });
      }
    };

    loadLeaflet();
    
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapRef, mapInitialized]);

  // Fonction d'initialisation de la carte
  const initMap = async () => {
    if (!window.L || !mapRef.current || mapInitialized) return;

    // Position centrée sur la France
    const position = [46.603354, 2.3522219];
    
    const map = window.L.map(mapRef.current).setView(position, 6);
    
    // Ajouter la couche OpenStreetMap avec style plus clair
    window.L.tileLayer('https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    
    try {
      // Charger les données GeoJSON des départements français
      const response = await fetch('https://france-geojson.gregoiredavid.fr/repo/departements.geojson');
      const geojsonData = await response.json();
      
      // Ajouter la couche des départements
      window.L.geoJSON(geojsonData, {
        style: (feature) => ({
          fillColor: getDepartmentColor(feature?.properties?.code),
          weight: 1,
          opacity: 1,
          color: '#666',
          fillOpacity: 0.7
        }),
        onEachFeature: (feature, layer) => {
          if (feature.properties) {
            const deptCode = feature.properties.code;
            const deptName = feature.properties.nom;
            const count = getDepartmentCount(deptCode);
            const deptAppointments = getDepartmentAppointments(deptCode);
            
            // Ajouter les données au state pour référence ultérieure
            setDepartmentData(prev => ({
              ...prev,
              [deptCode]: {
                code: deptCode,
                name: deptName,
                count,
                appointments: deptAppointments
              }
            }));
            
            // Ajouter tooltip et événement de clic
            layer.bindTooltip(`${deptName} (${deptCode}): ${count} rendez-vous`);
            
            // Ajouter un marqueur avec le nombre de rendez-vous au centre du département
            if (count > 0) {
              const bounds = layer.getBounds();
              const center = bounds.getCenter();
              
              // Créer une icône personnalisée avec le nombre de rendez-vous
              const icon = window.L.divIcon({
                html: `<div class="dept-count ${count > 10 ? 'high' : count > 5 ? 'medium' : 'low'}">${count}</div>`,
                className: '',
                iconSize: [30, 30],
                iconAnchor: [15, 15]
              });
              
              // Ajouter le marqueur
              window.L.marker([center.lat, center.lng], { icon })
                .addTo(map)
                .on('click', () => {
                  onDepartmentClick(deptCode, deptAppointments);
                });
            }
            
            // Ajouter l'événement de clic sur le département
            layer.on('click', () => {
              onDepartmentClick(deptCode, deptAppointments);
            });
          }
        }
      }).addTo(map);
      
      // Ajouter le CSS pour les marqueurs de comptage
      const style = document.createElement('style');
      style.textContent = `
        .dept-count {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 30px;
          height: 30px;
          border-radius: 50%;
          background-color: white;
          border: 2px solid #666;
          color: #000;
          font-weight: bold;
          font-size: 12px;
          box-shadow: 0 0 5px rgba(0,0,0,0.3);
        }
        .dept-count.low {
          background-color: #ADEDD9;
          border-color: #82CDCF;
        }
        .dept-count.medium {
          background-color: #C49BDE;
          border-color: #9b87f5;
        }
        .dept-count.high {
          background-color: #FF9AA2;
          border-color: #FF6B7A;
        }
      `;
      document.head.appendChild(style);
      
    } catch (error) {
      console.error('Erreur lors du chargement des données GeoJSON:', error);
      toast({
        title: "Erreur de données",
        description: "Impossible de charger les données des départements.",
        variant: "destructive",
      });
    }
  };

  // Obtenir la couleur en fonction du nombre de rendez-vous
  const getDepartmentColor = (deptCode?: string): string => {
    if (!deptCode) return '#F1F0FB'; // Gris clair pour les départements sans code
    
    const count = getDepartmentCount(deptCode);
    
    if (count === 0) return '#F1F0FB';      // Gris très clair
    if (count < 5) return '#E5DEFF';        // Violet très clair
    if (count < 10) return '#D6BCFA';       // Violet clair
    if (count < 20) return '#9b87f5';       // Violet moyen
    if (count < 30) return '#7E69AB';       // Violet foncé
    return '#6E59A5';                       // Violet très foncé
  };

  // Compter les rendez-vous par département
  const getDepartmentCount = (deptCode: string): number => {
    return appointments.filter(app => {
      // Extraire le code postal depuis l'adresse
      const postalCodeMatch = app.address.match(/\b\d{5}\b/);
      if (!postalCodeMatch) return false;
      
      // Les deux premiers chiffres du code postal correspondent au département
      const appointmentDeptCode = postalCodeMatch[0].substring(0, 2);
      return appointmentDeptCode === deptCode;
    }).length;
  };

  // Récupérer les rendez-vous d'un département
  const getDepartmentAppointments = (deptCode: string): Appointment[] => {
    return appointments.filter(app => {
      const postalCodeMatch = app.address.match(/\b\d{5}\b/);
      if (!postalCodeMatch) return false;
      const appointmentDeptCode = postalCodeMatch[0].substring(0, 2);
      return appointmentDeptCode === deptCode;
    });
  };

  return (
    <div className="h-full w-full border rounded-md overflow-hidden relative">
      <div ref={mapRef} className="h-full w-full" />
      {!mapInitialized && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/80">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
            <p>Chargement de la carte des départements...</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default DepartementMap;
