
import { useEffect, useRef, useState } from 'react';
import { Appointment, OptimizedRoute } from '@/types/route';
import { useToast } from '@/components/ui/use-toast';

// Assurez-vous que TypeScript reconnaît l'extension de Window avec la propriété L
declare global {
  interface Window {
    L: any;
  }
}

interface RouteMapProps {
  currentLocation: { lat: number; lng: number } | null;
  appointments: Appointment[];
  optimizedRoute: OptimizedRoute | null;
  showOptimizedRouteOnly?: boolean;
}

const RouteMap = ({ 
  currentLocation, 
  appointments,
  optimizedRoute,
  showOptimizedRouteOnly = false
}: RouteMapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const [mapInitialized, setMapInitialized] = useState(false);
  const [apiLoaded, setApiLoaded] = useState(false);
  const [mapInstance, setMapInstance] = useState<any>(null);
  const [markersLayer, setMarkersLayer] = useState<any>(null);
  const [routeLayer, setRouteLayer] = useState<any>(null);

  // Initialiser la carte
  useEffect(() => {
    if (!mapRef.current || mapInitialized) return;

    // On utilise OpenStreetMap avec Leaflet
    const loadLeaflet = async () => {
      try {
        // Vérifier si Leaflet est déjà chargé
        if (!window.L) {
          // Charger la CSS de Leaflet
          const linkEl = document.createElement('link');
          linkEl.rel = 'stylesheet';
          linkEl.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
          document.head.appendChild(linkEl);

          // Charger le JavaScript de Leaflet
          const script = document.createElement('script');
          script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
          script.async = true;
          
          await new Promise((resolve, reject) => {
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
          });
        }

        // Initialiser la carte après le chargement de Leaflet
        setTimeout(() => {
          initMap();
          setApiLoaded(true);
        }, 100);

      } catch (error) {
        console.error('Erreur lors du chargement de Leaflet:', error);
        toast({
          title: "Erreur de chargement",
          description: "Impossible de charger la carte. Veuillez rafraîchir la page.",
          variant: "destructive",
        });
      }
    };

    loadLeaflet();
    
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapRef, mapInitialized]);

  // Fonction d'initialisation de la carte
  const initMap = () => {
    if (!window.L || !mapRef.current || mapInitialized) return;

    // Position par défaut (Paris)
    const defaultPosition = [48.856614, 2.3522219];
    const position = currentLocation ? [currentLocation.lat, currentLocation.lng] : defaultPosition;
    
    const map = window.L.map(mapRef.current).setView(position, 13);
    
    // Ajouter la couche OpenStreetMap
    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    
    // Créer un groupe pour les marqueurs
    const markers = window.L.layerGroup().addTo(map);
    
    // Créer un groupe pour l'itinéraire
    const route = window.L.layerGroup().addTo(map);
    
    setMapInstance(map);
    setMarkersLayer(markers);
    setRouteLayer(route);
    setMapInitialized(true);
  };

  // Mettre à jour les marqueurs quand les rendez-vous changent
  useEffect(() => {
    if (!mapInstance || !markersLayer || !apiLoaded) return;

    // Effacer tous les marqueurs
    markersLayer.clearLayers();

    // Ajouter le marqueur de position actuelle s'il existe
    if (currentLocation && (!showOptimizedRouteOnly || !optimizedRoute)) {
      const currentLocationIcon = window.L.divIcon({
        html: `<div class="w-6 h-6 rounded-full bg-blue-600 border-2 border-white flex items-center justify-center text-white">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="1"/></svg>
              </div>`,
        className: '',
        iconSize: [24, 24],
        iconAnchor: [12, 12]
      });

      const marker = window.L.marker([currentLocation.lat, currentLocation.lng], {
        icon: currentLocationIcon,
        zIndexOffset: 1000
      }).addTo(markersLayer);
      
      marker.bindPopup("<b>Votre position actuelle</b>");
    }

    // Ajouter les marqueurs pour chaque rendez-vous s'il n'y a pas d'itinéraire optimisé ou si on veut voir tous les points
    if (!showOptimizedRouteOnly || !optimizedRoute) {
      appointments.forEach((appointment, index) => {
        const appointmentIcon = window.L.divIcon({
          html: `<div class="w-6 h-6 rounded-full bg-red-500 border-2 border-white flex items-center justify-center text-white">
                  ${index + 1}
                </div>`,
          className: '',
          iconSize: [24, 24],
          iconAnchor: [12, 12]
        });

        const marker = window.L.marker([appointment.lat, appointment.lng], {
          icon: appointmentIcon
        }).addTo(markersLayer);
        
        marker.bindPopup(`<b>${appointment.name}</b><br>${appointment.address}`);
      });
    }

    // Ajuster la vue pour voir tous les marqueurs
    if (appointments.length > 0 && !optimizedRoute) {
      const group = new window.L.FeatureGroup();
      markersLayer.eachLayer((layer: any) => {
        group.addLayer(layer);
      });
      
      if (group.getBounds().isValid()) {
        mapInstance.fitBounds(group.getBounds(), { padding: [50, 50] });
      }
    }
  }, [currentLocation, appointments, mapInstance, markersLayer, apiLoaded, optimizedRoute, showOptimizedRouteOnly]);

  // Afficher l'itinéraire optimisé s'il existe
  useEffect(() => {
    if (!mapInstance || !routeLayer || !markersLayer || !apiLoaded || !optimizedRoute) return;

    // Effacer l'ancien itinéraire
    routeLayer.clearLayers();

    // Si on affiche uniquement l'itinéraire optimisé, on doit aussi mettre à jour les marqueurs
    if (showOptimizedRouteOnly) {
      markersLayer.clearLayers();

      // Ajouter les marqueurs dans l'ordre optimisé
      optimizedRoute.waypoints.forEach((waypoint, index) => {
        const waypointIcon = window.L.divIcon({
          html: `<div class="w-6 h-6 rounded-full bg-green-500 border-2 border-white flex items-center justify-center text-white">
                  ${index + 1}
                </div>`,
          className: '',
          iconSize: [24, 24],
          iconAnchor: [12, 12]
        });

        const marker = window.L.marker([waypoint.lat, waypoint.lng], {
          icon: waypointIcon
        }).addTo(markersLayer);
        
        marker.bindPopup(`<b>${waypoint.name}</b><br>Étape ${index + 1}`);
      });
    }

    // Dessiner le polyline de l'itinéraire s'il y a des coordonnées de géométrie
    if (optimizedRoute.routeGeometry && optimizedRoute.routeGeometry.length > 0) {
      const polyline = window.L.polyline(optimizedRoute.routeGeometry, {
        color: '#3B82F6',
        weight: 5,
        opacity: 0.7
      }).addTo(routeLayer);
      
      // Ajuster la vue pour voir tout l'itinéraire
      mapInstance.fitBounds(polyline.getBounds(), { padding: [50, 50] });
    } else {
      // S'il n'y a pas de géométrie, on relie simplement les points dans l'ordre
      const points = optimizedRoute.waypoints.map(wp => [wp.lat, wp.lng]);
      if (points.length > 0) {
        const polyline = window.L.polyline(points, {
          color: '#3B82F6',
          weight: 5,
          opacity: 0.7,
          dashArray: '10, 10'
        }).addTo(routeLayer);
        
        mapInstance.fitBounds(polyline.getBounds(), { padding: [50, 50] });
      }
    }
  }, [optimizedRoute, mapInstance, routeLayer, markersLayer, apiLoaded, showOptimizedRouteOnly]);

  return (
    <div className="h-full w-full border rounded-md overflow-hidden relative">
      <div ref={mapRef} className="h-full w-full" />
      {!apiLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/80">
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
            <p>Chargement de la carte...</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default RouteMap;
