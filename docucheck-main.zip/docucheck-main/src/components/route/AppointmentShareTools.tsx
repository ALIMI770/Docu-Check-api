
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Appointment, Team } from "@/types/route";
import { 
  generateAppointmentMessage, 
  generateWhatsAppLink, 
  generateSMSLink,
  generateTeamAppointmentsMessage
} from "@/services/routeOptimizationService";
import { useToast } from "@/components/ui/use-toast";
import { Copy, Send, UserCircle, Users } from "lucide-react";
import TeamManager from './TeamManager';

interface AppointmentShareToolsProps {
  appointments: Appointment[];
  optimizedWaypoints?: Appointment[];
  onAppointmentTeamChange: (appointmentId: string, teamId: string | undefined) => void;
}

const AppointmentShareTools = ({ appointments, optimizedWaypoints, onAppointmentTeamChange }: AppointmentShareToolsProps) => {
  const { toast } = useToast();
  const [phoneNumber, setPhoneNumber] = useState("");
  const [isValidPhone, setIsValidPhone] = useState(false);
  const [teams, setTeams] = useState<Team[]>([]);

  // Utilisez les waypoints optimisés s'ils existent, sinon utilisez les rendez-vous normaux
  const displayAppointments = optimizedWaypoints || appointments;

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setPhoneNumber(value);
    // Validation simple du numéro de téléphone (au moins 10 chiffres)
    setIsValidPhone(value.replace(/\D/g, '').length >= 10);
  };

  const copyAppointmentDetails = (appointment: Appointment, index: number) => {
    const message = generateAppointmentMessage(appointment, index);
    navigator.clipboard.writeText(message);
    
    toast({
      title: "Copié",
      description: "Les détails du rendez-vous ont été copiés dans le presse-papier",
    });
  };

  const openWhatsApp = (appointment: Appointment, index: number) => {
    if (!isValidPhone) {
      toast({
        title: "Numéro invalide",
        description: "Veuillez entrer un numéro de téléphone valide",
        variant: "destructive",
      });
      return;
    }
    
    const message = generateAppointmentMessage(appointment, index);
    const whatsappLink = generateWhatsAppLink(phoneNumber, message);
    window.open(whatsappLink, '_blank');
  };

  const sendSMS = (appointment: Appointment, index: number) => {
    if (!isValidPhone) {
      toast({
        title: "Numéro invalide",
        description: "Veuillez entrer un numéro de téléphone valide",
        variant: "destructive",
      });
      return;
    }
    
    const message = generateAppointmentMessage(appointment, index);
    const smsLink = generateSMSLink(phoneNumber, message);
    window.open(smsLink, '_blank');
  };

  // Fonction pour partager tous les RDV d'une équipe via WhatsApp
  const shareTeamAppointments = (teamId: string, teamName: string, teamPhone: string) => {
    const teamAppointments = appointments.filter(app => app.teamId === teamId);
    
    if (teamAppointments.length === 0) {
      toast({
        title: "Aucun rendez-vous",
        description: `L'équipe ${teamName} n'a aucun rendez-vous attribué`,
        variant: "destructive",
      });
      return;
    }
    
    const message = generateTeamAppointmentsMessage(teamAppointments, teamName);
    const whatsappLink = generateWhatsAppLink(teamPhone, message);
    window.open(whatsappLink, '_blank');
  };

  if (displayAppointments.length === 0) {
    return (
      <div className="text-center p-6 bg-muted rounded-lg">
        <p className="text-muted-foreground">Aucun rendez-vous à partager</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="individual">
        <TabsList className="mb-4">
          <TabsTrigger value="individual" className="flex items-center gap-1">
            <UserCircle className="h-4 w-4" />
            Partage individuel
          </TabsTrigger>
          <TabsTrigger value="teams" className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            Gestion par équipes
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="individual">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="phone-number">Numéro de téléphone du poseur</Label>
              <Input
                id="phone-number"
                placeholder="ex: +33 6 12 34 56 78"
                value={phoneNumber}
                onChange={handlePhoneChange}
              />
              <p className="text-xs text-muted-foreground">
                Utilisé pour envoyer les itinéraires par WhatsApp ou SMS
              </p>
            </div>

            <div className="border rounded-md overflow-hidden">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr className="border-b">
                    <th className="py-2 px-4 text-left font-medium text-sm">N°</th>
                    <th className="py-2 px-4 text-left font-medium text-sm">Rendez-vous</th>
                    <th className="py-2 px-4 text-left font-medium text-sm">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {displayAppointments.map((appointment, index) => (
                    <tr key={appointment.id} className="border-b last:border-0">
                      <td className="py-3 px-4 font-medium">{index + 1}</td>
                      <td className="py-3 px-4">
                        <p className="font-medium">{appointment.name}</p>
                        <p className="text-xs text-muted-foreground">{appointment.address}</p>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyAppointmentDetails(appointment, index)}
                            title="Copier les détails"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openWhatsApp(appointment, index)}
                            disabled={!isValidPhone}
                            title="Envoyer par WhatsApp"
                            className="bg-[#25D366] text-white hover:bg-[#128C7E] hover:text-white"
                          >
                            <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                            </svg>
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => sendSMS(appointment, index)}
                            disabled={!isValidPhone}
                            title="Envoyer par SMS"
                          >
                            <Send className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="teams">
          <TeamManager 
            appointments={appointments} 
            onAppointmentTeamChange={onAppointmentTeamChange}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AppointmentShareTools;
