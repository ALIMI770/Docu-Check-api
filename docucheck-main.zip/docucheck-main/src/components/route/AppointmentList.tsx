
import { Appointment } from "@/types/route";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Trash } from "lucide-react";

interface AppointmentListProps {
  appointments: Appointment[];
  onRemoveAppointment: (id: string) => void;
}

const AppointmentList = ({ appointments, onRemoveAppointment }: AppointmentListProps) => {
  if (appointments.length === 0) {
    return (
      <div className="text-center p-6 bg-muted rounded-lg">
        <p className="text-muted-foreground">Aucun rendez-vous ajouté</p>
        <p className="text-sm text-muted-foreground mt-2">
          Utilisez le formulaire pour ajouter des rendez-vous à votre tournée
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
      {appointments.map((appointment) => (
        <Card key={appointment.id} className="p-3 hover:bg-accent/5 transition-colors">
          <div className="flex justify-between items-start">
            <div>
              <h4 className="font-medium">{appointment.name}</h4>
              <p className="text-sm text-muted-foreground mt-1">{appointment.address}</p>
              {appointment.time && (
                <p className="text-xs mt-1">
                  <span className="font-medium">Heure:</span> {appointment.time}
                  {appointment.duration && ` (${appointment.duration} min)`}
                </p>
              )}
              {appointment.notes && (
                <p className="text-xs mt-1 italic">{appointment.notes}</p>
              )}
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="text-destructive hover:text-destructive hover:bg-destructive/10"
              onClick={() => onRemoveAppointment(appointment.id)}
            >
              <Trash className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
};

export default AppointmentList;
