
import { useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { Upload, FileSpreadsheet, CheckCircle } from 'lucide-react';
import { Appointment } from '@/types/route';
import * as XLSX from 'xlsx';
import { v4 as uuidv4 } from 'uuid';
import { geocodeAddress } from '@/services/geocodingService';

interface AppointmentUploaderProps {
  onAppointmentsImported: (appointments: Appointment[]) => void;
  isLoading: boolean;
}

const AppointmentUploader = ({ onAppointmentsImported, isLoading }: AppointmentUploaderProps) => {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;

    const file = e.target.files[0];
    const fileExt = file.name.split('.').pop()?.toLowerCase();

    if (fileExt !== 'csv' && fileExt !== 'xlsx' && fileExt !== 'xls') {
      toast({
        title: "Format non supporté",
        description: "Veuillez téléverser un fichier CSV ou Excel",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    setUploadSuccess(false);

    try {
      const appointments = await parseFile(file);
      if (appointments.length === 0) {
        toast({
          title: "Fichier vide",
          description: "Aucun rendez-vous trouvé dans le fichier",
          variant: "destructive",
        });
        setIsProcessing(false);
        return;
      }

      // Geocoder les adresses
      const geocodedAppointments = await geocodeAppointments(appointments);
      
      onAppointmentsImported(geocodedAppointments);
      
      setUploadSuccess(true);
      toast({
        title: "Import réussi",
        description: `${geocodedAppointments.length} rendez-vous importés avec succès`,
      });
    } catch (error) {
      console.error("Erreur lors de l'import du fichier:", error);
      toast({
        title: "Erreur d'import",
        description: "Une erreur est survenue lors du traitement du fichier",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const parseFile = async (file: File): Promise<Partial<Appointment>[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'binary' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet);
          
          // Normaliser les données en fonction des en-têtes de colonnes possibles
          const appointments = jsonData.map((row: any) => {
            return {
              id: uuidv4(),
              name: row.nom || row.client || row.name || row.contact || "",
              address: row.adresse || row.address || "",
              time: row.heure || row.time || row.horaire || "",
              duration: row.duree || row.duration || row.temps || "",
              notes: row.notes || row.commentaire || row.commentaires || row.remarques || "",
            };
          });
          
          resolve(appointments);
        } catch (error) {
          reject(error);
        }
      };
      
      reader.onerror = (error) => reject(error);
      
      reader.readAsBinaryString(file);
    });
  };

  const geocodeAppointments = async (appointments: Partial<Appointment>[]): Promise<Appointment[]> => {
    const geocodedAppointments: Appointment[] = [];
    
    // Traiter les adresses séquentiellement pour éviter de surcharger l'API de géocodage
    for (const app of appointments) {
      if (!app.address || !app.name) continue;
      
      try {
        const geoResult = await geocodeAddress(app.address);
        
        if (geoResult) {
          geocodedAppointments.push({
            id: app.id || uuidv4(),
            name: app.name,
            address: app.address,
            lat: geoResult.lat,
            lng: geoResult.lng,
            time: app.time,
            duration: app.duration ? parseInt(app.duration.toString()) : undefined,
            notes: app.notes
          });
        }
      } catch (error) {
        console.error(`Erreur de géocodage pour l'adresse ${app.address}:`, error);
      }
    }
    
    return geocodedAppointments;
  };

  return (
    <div className="border-2 border-dashed rounded-lg p-4 transition-all hover:border-primary/60 hover:bg-primary/5">
      <label htmlFor="file-upload" className="cursor-pointer w-full block">
        <div className="flex flex-col items-center py-3">
          {uploadSuccess ? (
            <CheckCircle className="h-8 w-8 text-green-500 mb-2" />
          ) : (
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mb-2">
              <FileSpreadsheet className="h-5 w-5 text-primary" />
            </div>
          )}
          
          <p className="text-sm font-medium">
            Importer des rendez-vous
          </p>
          
          {uploadSuccess ? (
            <p className="text-xs text-green-600 mt-1">Fichier importé avec succès</p>
          ) : (
            <div className="flex flex-col items-center mt-2">
              <div className="flex items-center">
                <Upload className="h-3 w-3 text-gray-400 mr-1" />
                <span className="text-xs text-gray-500">
                  {isProcessing ? "Traitement en cours..." : "Glisser ou cliquer pour téléverser"}
                </span>
              </div>
              <span className="text-xs text-gray-400 mt-1">(Fichiers CSV, Excel acceptés)</span>
            </div>
          )}
        </div>
      </label>
      
      <Input 
        ref={fileInputRef}
        id="file-upload" 
        type="file" 
        accept=".csv,.xlsx,.xls" 
        className="hidden" 
        onChange={handleFileUpload}
        disabled={isProcessing || isLoading}
      />
    </div>
  );
};

export default AppointmentUploader;
