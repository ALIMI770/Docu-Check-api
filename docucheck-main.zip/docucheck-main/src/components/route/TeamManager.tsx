
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Appointment, Team } from "@/types/route";
import { useToast } from "@/components/ui/use-toast";
import { Users, UserPlus, Trash2 } from "lucide-react";
import { v4 as uuidv4 } from 'uuid';

interface TeamManagerProps {
  appointments: Appointment[];
  onAppointmentTeamChange: (appointmentId: string, teamId: string | undefined) => void;
}

const TeamManager = ({ appointments, onAppointmentTeamChange }: TeamManagerProps) => {
  const { toast } = useToast();
  const [teams, setTeams] = useState<Team[]>([]);
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamPhone, setNewTeamPhone] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);

  const handleAddTeam = () => {
    if (!newTeamName.trim()) {
      toast({
        title: "Nom d'équipe requis",
        description: "Veuillez saisir un nom d'équipe valide",
        variant: "destructive"
      });
      return;
    }

    const newTeam: Team = {
      id: uuidv4(),
      name: newTeamName.trim(),
      phoneNumber: newTeamPhone.trim()
    };

    setTeams([...teams, newTeam]);
    setNewTeamName('');
    setNewTeamPhone('');
    setDialogOpen(false);

    toast({
      title: "Équipe ajoutée",
      description: `L'équipe "${newTeam.name}" a été ajoutée avec succès`
    });
  };

  const handleRemoveTeam = (teamId: string) => {
    // Retirer l'équipe de tous les rendez-vous associés
    appointments.forEach(app => {
      if (app.teamId === teamId) {
        onAppointmentTeamChange(app.id, undefined);
      }
    });

    // Supprimer l'équipe
    setTeams(teams.filter(team => team.id !== teamId));
    
    toast({
      title: "Équipe supprimée",
      description: "L'équipe a été supprimée avec succès"
    });
  };

  const getTeamAppointmentsCount = (teamId: string): number => {
    return appointments.filter(app => app.teamId === teamId).length;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Gestion des équipes</h3>
        
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="flex items-center gap-1">
              <UserPlus className="h-4 w-4" />
              <span>Nouvelle équipe</span>
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Ajouter une équipe</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="teamName">Nom de l'équipe</Label>
                <Input
                  id="teamName"
                  placeholder="ex: Équipe Nord"
                  value={newTeamName}
                  onChange={(e) => setNewTeamName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="teamPhone">Numéro de téléphone</Label>
                <Input
                  id="teamPhone"
                  placeholder="ex: +33 6 12 34 56 78"
                  value={newTeamPhone}
                  onChange={(e) => setNewTeamPhone(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button>
              <Button onClick={handleAddTeam}>Ajouter l'équipe</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {teams.length === 0 ? (
        <div className="text-center py-8 bg-muted/50 rounded-lg">
          <Users className="h-12 w-12 text-muted-foreground mx-auto mb-2 opacity-50" />
          <p className="text-muted-foreground">Aucune équipe créée</p>
          <p className="text-xs text-muted-foreground mt-1">Ajoutez des équipes pour leur assigner des rendez-vous</p>
        </div>
      ) : (
        <div className="space-y-3">
          {teams.map(team => (
            <div key={team.id} className="p-3 border rounded-lg bg-card">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h4 className="font-medium">{team.name}</h4>
                  <p className="text-xs text-muted-foreground">{team.phoneNumber || "Pas de numéro"}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                    {getTeamAppointmentsCount(team.id)} RDV
                  </span>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => handleRemoveTeam(team.id)}
                    className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="mt-3">
                <Label htmlFor={`assign-${team.id}`} className="text-xs mb-1 block">Attribuer des rendez-vous</Label>
                <Select 
                  onValueChange={(value) => onAppointmentTeamChange(value, team.id)}
                >
                  <SelectTrigger id={`assign-${team.id}`} className="w-full text-sm">
                    <SelectValue placeholder="Sélectionnez un rendez-vous" />
                  </SelectTrigger>
                  <SelectContent>
                    {appointments
                      .filter(app => !app.teamId || app.teamId === team.id)
                      .map(app => (
                        <SelectItem key={app.id} value={app.id}>
                          {app.name} - {app.address.substring(0, 30)}...
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          ))}
        </div>
      )}

      {teams.length > 0 && (
        <div className="mt-4">
          <Label className="text-xs mb-1 block">Attribution rapide</Label>
          <div className="grid grid-cols-2 gap-2">
            {appointments.map(app => (
              <div key={app.id} className="p-2 border rounded text-xs">
                <div className="font-medium truncate">{app.name}</div>
                <div className="text-muted-foreground truncate">{app.address}</div>
                
                <Select 
                  value={app.teamId || ""}
                  onValueChange={(value) => onAppointmentTeamChange(app.id, value || undefined)}
                >
                  <SelectTrigger className="h-7 mt-1 text-xs">
                    <SelectValue placeholder="Assigner à une équipe" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Aucune équipe</SelectItem>
                    {teams.map(team => (
                      <SelectItem key={team.id} value={team.id}>{team.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default TeamManager;
