import React from 'react';

interface InfoItemProps {
  label: string;
  value: string;
  variant?: 'default' | 'secondary' | 'destructive' | 'outline';
}

/**
 * Composant pour afficher un élément d'information avec label et valeur
 */
export const InfoItem: React.FC<InfoItemProps> = ({
  label,
  value,
  variant = 'default'
}) => {
  const getVariantClass = () => {
    switch (variant) {
      case 'default':
        return 'text-primary';
      case 'destructive':
        return 'text-red-600';
      case 'secondary':
        return 'text-gray-600';
      default:
        return '';
    }
  };

  return (
    <div className="flex flex-col">
      <span className="text-sm text-gray-500">{label}</span>
      <span className={`font-medium ${getVariantClass()}`}>{value}</span>
    </div>
  );
};

export default InfoItem;
