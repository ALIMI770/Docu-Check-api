import React from 'react';
import { Badge } from './badge';

interface ManuscritItemProps {
  label: string;
  present: boolean;
  score?: number;
  value?: string | React.ReactNode;
  small?: boolean;
  textPresent?: string;
  textAbsent?: string;
}

const ManuscritItem = ({ 
  label, 
  present,
  score,
  value,
  small = false,
  textPresent,
  textAbsent
}: ManuscritItemProps) => {
  return (
    <div className={`flex items-center ${small ? 'text-xs mb-1' : 'text-sm mb-2'} justify-between`}>
      <span className="font-medium">{label}</span>
      <div className="flex items-center">
        {value && (
          <span
            className={`${small ? 'text-xs' : 'text-sm'} mr-2 italic`}
            style={{ whiteSpace: 'pre-line' }}
          >
            {Array.isArray(value) ? value : value}
          </span>
        )}
        <Badge 
          variant={present ? "default" : "default"} 
          className={`${small ? 'text-xs px-1.5 py-0' : ''} ${present ? "bg-green-100 text-green-800 hover:bg-green-100" : "bg-red-100 text-red-800 hover:bg-red-100"}`}
        >
          {present 
            ? `${textPresent || "Présent"} (${score ?? "N/A"}%)`
            : textAbsent || "Non détecté"}
        </Badge>
      </div>
    </div>
  );
};

export default ManuscritItem;
