import React from 'react';

interface ManuscriptZoneOverlayProps {
  coordinates: string; // Format: "x,y,width,height"
  imageWidth: number;
  imageHeight: number;
}

/**
 * Composant pour visualiser la zone manuscrite détectée sur une image
 * Affiche un rectangle rouge semi-transparent sur la zone détectée
 */
export const ManuscriptZoneOverlay: React.FC<ManuscriptZoneOverlayProps> = ({
  coordinates,
  imageWidth,
  imageHeight
}) => {
  if (!coordinates || coordinates === "") {
    return null;
  }

  try {
    const [x, y, width, height] = coordinates.split(',').map(Number);
    
    // Validation des coordonnées
    if (isNaN(x) || isNaN(y) || isNaN(width) || isNaN(height)) {
      console.error("Coordonnées invalides:", coordinates);
      return null;
    }

    // Convertir les pourcentages en pixels
    const xPx = (x / 100) * imageWidth;
    const yPx = (y / 100) * imageHeight;
    const widthPx = (width / 100) * imageWidth;
    const heightPx = (height / 100) * imageHeight;

    return (
      <div
        style={{
          position: 'absolute',
          left: `${xPx}px`,
          top: `${yPx}px`,
          width: `${widthPx}px`,
          height: `${heightPx}px`,
          border: '2px solid #ef4444',
          backgroundColor: 'rgba(239, 68, 68, 0.1)',
          pointerEvents: 'none',
          zIndex: 10,
        }}
        title={`Zone manuscrite détectée: ${coordinates}`}
      >
        <div
          style={{
            position: 'absolute',
            top: '-24px',
            left: '0',
            backgroundColor: '#ef4444',
            color: 'white',
            padding: '2px 6px',
            fontSize: '11px',
            borderRadius: '3px',
            whiteSpace: 'nowrap',
          }}
        >
          Zone manuscrite
        </div>
      </div>
    );
  } catch (error) {
    console.error("Erreur lors de l'affichage de la zone manuscrite:", error);
    return null;
  }
};
