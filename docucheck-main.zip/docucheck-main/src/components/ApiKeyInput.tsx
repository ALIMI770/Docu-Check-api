
import { CheckCircle } from 'lucide-react';

const ApiKeyInput = () => {
  return (
    <div className="p-4 border rounded-lg bg-white shadow-sm relative">
      <div className="flex items-center mb-2">
        <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
        <h3 className="text-sm font-medium">Configuration prête à l'emploi</h3>
      </div>
      
      <div className="mt-2">
        <p className="text-xs text-gray-500">
          L'analyse des documents est entièrement configurée et prête à l'emploi. 
          La clé API OpenAI est intégrée dans l'application.
        </p>
        
        <div className="mt-2 bg-green-50 p-2 rounded text-xs text-green-700">
          <div className="flex items-center">
            <CheckCircle className="h-3.5 w-3.5 mr-1.5" />
            <p>Intelligence artificielle activée pour l'analyse de conformité CEE</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApiKeyInput;
