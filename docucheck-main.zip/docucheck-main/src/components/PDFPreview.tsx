
import { useState, useEffect } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, FileText, AlertCircle, Loader2 } from 'lucide-react';
import { PDF_CONVERSION } from '@/services/utils/fileUtils';
import 'react-pdf/dist/esm/Page/TextLayer.css';
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';

// Configurer le worker pour PDF.js
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

interface PDFPreviewProps {
  file: File;
}

const PDFPreview = ({ file }: PDFPreviewProps) => {
  const [numPages, setNumPages] = useState<number | null>(null);
  const [pageNumber, setPageNumber] = useState<number>(1);
  const [fileUrl, setFileUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Convertir le fichier en URL
    const url = URL.createObjectURL(file);
    setFileUrl(url);
    setPageNumber(1);
    setError(null);
    setLoading(true);

    return () => {
      // Nettoyer l'URL lorsque le composant est démonté
      if (url) {
        URL.revokeObjectURL(url);
      }
    };
  }, [file]);

  const onDocumentLoadSuccess = ({ numPages }: { numPages: number }) => {
    setNumPages(numPages);
    setLoading(false);
  };

  const onDocumentLoadError = (error: Error) => {
    console.error('Erreur lors du chargement du PDF:', error);
    setError(`Impossible de charger le document: ${error.message}`);
    setLoading(false);
  };

  const changePage = (offset: number) => {
    if (numPages) {
      const newPage = pageNumber + offset;
      if (newPage >= 1 && newPage <= numPages) {
        setPageNumber(newPage);
      }
    }
  };

  const previousPage = () => changePage(-1);
  const nextPage = () => changePage(1);

  if (loading) {
    return (
      <div className="h-full w-full flex flex-col items-center justify-center">
        <Loader2 className="h-8 w-8 text-blue-500 animate-spin mb-4" />
        <p className="text-sm text-gray-600">Chargement du document...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-full w-full flex flex-col items-center justify-center">
        <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
        <h3 className="text-lg font-medium mb-2">Erreur de prévisualisation</h3>
        <p className="text-sm text-red-600 text-center mb-4">{error}</p>
        <p className="text-xs text-gray-500 text-center">
          Le document est peut-être endommagé ou dans un format non supporté.
        </p>
      </div>
    );
  }

  // Si c'est un fichier PDF
  if (file.type === 'application/pdf' && fileUrl) {
    return (
      <div className="flex flex-col h-full">
        <div className="flex-grow overflow-auto">
          <Document
            file={fileUrl}
            onLoadSuccess={onDocumentLoadSuccess}
            onLoadError={onDocumentLoadError}
            loading={
              <div className="flex justify-center items-center h-full">
                <Loader2 className="h-8 w-8 text-blue-500 animate-spin" />
              </div>
            }
          >
            <Page
              pageNumber={pageNumber}
              renderTextLayer={true}
              renderAnnotationLayer={true}
              width={window.innerWidth < 768 ? window.innerWidth - 80 : 500}
              // Utiliser une scale plus faible pour la prévisualisation (moins de détails mais plus rapide)
              scale={PDF_CONVERSION.PREVIEW_DPI / 72}
            />
          </Document>
        </div>
        
        {numPages && numPages > 1 && (
          <div className="flex items-center justify-between pt-4 border-t mt-4">
            <Button
              variant="outline"
              onClick={previousPage}
              disabled={pageNumber <= 1}
              size="sm"
            >
              <ChevronLeft className="h-4 w-4 mr-1" /> Précédent
            </Button>
            
            <span className="text-sm">
              Page {pageNumber} sur {numPages}
            </span>
            
            <Button
              variant="outline"
              onClick={nextPage}
              disabled={pageNumber >= (numPages || 1)}
              size="sm"
            >
              Suivant <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        )}
      </div>
    );
  }

  // Si c'est une image
  if (fileUrl && PDF_CONVERSION.SUPPORTED_IMAGE_FORMATS.includes(file.type)) {
    return (
      <div className="h-full flex flex-col items-center justify-center">
        <img
          src={fileUrl}
          alt="Document preview"
          className="max-h-full max-w-full object-contain"
        />
      </div>
    );
  }

  // Fallback pour les autres types de fichiers
  return (
    <div className="h-full w-full flex flex-col items-center justify-center">
      <FileText className="h-12 w-12 text-gray-400 mb-4" />
      <h3 className="text-lg font-medium mb-2">Prévisualisation non disponible</h3>
      <p className="text-sm text-gray-500 text-center">
        Le type de fichier ({file.type || 'inconnu'}) ne peut pas être affiché.
      </p>
    </div>
  );
};

export default PDFPreview;
