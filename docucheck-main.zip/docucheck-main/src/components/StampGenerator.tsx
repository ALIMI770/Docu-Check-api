
import { useState, useRef, useEffect } from "react";
import StampForm from "./stamp/StampForm";
import StampPreview from "./stamp/StampPreview";
import StampPdfUploader from "./stamp/StampPdfUploader";
import StampImporter from "./stamp/StampImporter";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Info } from "lucide-react";
import { STAMP_DIMENSIONS } from "@/hooks/use-pdf-processor";

interface CompanyInfo {
  name: string;
  address: string;
  siret: string;
  vatNumber: string;
  rcsNumber?: string;
}

const StampGenerator = ({ useCredits }: { useCredits: (amount: number) => boolean }) => {
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [stampImage, setStampImage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("generator");
  const { toast } = useToast();
  const isMounted = useRef(true);

  useEffect(() => {
    console.log("StampGenerator mounted");
    isMounted.current = true;
    
    return () => {
      console.log("StampGenerator unmounting");
      isMounted.current = false;
    };
  }, []);
  
  const handleCompanyInfo = (info: CompanyInfo) => {
    try {
      if (isMounted.current) {
        console.log("Company info updated:", info);
        setCompanyInfo(info);
        setError(null);
      }
    } catch (err) {
      console.error("Error updating company info:", err);
      if (isMounted.current) {
        setError("Une erreur est survenue lors de la mise à jour des informations de l'entreprise");
      }
    }
  };
  
  const handleStampImage = (image: string) => {
    if (isMounted.current) {
      console.log("Stamp image generated/imported");
      setStampImage(image);
      toast({
        title: "Tampon prêt",
        description: "Votre tampon est maintenant prêt à être appliqué sur vos documents",
      });
    }
  };

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    console.log("Tab changed to:", value);
  };
  
  if (error) {
    return (
      <div className="p-4 border border-red-300 bg-red-50 rounded-md text-red-700">
        <h3 className="font-medium">Erreur</h3>
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="p-4 border border-blue-200 bg-blue-50 rounded-md">
        <div className="flex items-start space-x-3">
          <Info className="h-5 w-5 text-blue-600 mt-0.5" />
          <div>
            <h3 className="font-medium text-blue-800">Format du tampon</h3>
            <p className="text-sm text-blue-700">
              Le tampon sera généré au format {Math.round(STAMP_DIMENSIONS.width / (72/25.4))} × {Math.round(STAMP_DIMENSIONS.height / (72/25.4))} mm. Positionnement&nbsp;: vous pourrez l'ajuster précisément à la main sur chaque page ou enregistrer des templates selon vos besoins.
            </p>
          </div>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="generator">Créer un tampon</TabsTrigger>
          <TabsTrigger value="import">Importer un tampon</TabsTrigger>
          <TabsTrigger value="pdf" onClick={() => console.log("PDF tab clicked")}>Appliquer sur PDF</TabsTrigger>
        </TabsList>
        
        <TabsContent value="generator" className="space-y-6">
          {isLoading ? (
            <>
              <Skeleton className="h-[300px] w-full rounded-lg" />
              <Skeleton className="h-[400px] w-full rounded-lg" />
            </>
          ) : (
            <>
              <StampForm 
                onCompanyInfo={handleCompanyInfo} 
                useCredits={useCredits} 
                setIsLoading={setIsLoading}
              />
              {companyInfo && (
                <StampPreview 
                  companyInfo={companyInfo} 
                  onStampImage={handleStampImage}
                  key={`stamp-preview-${companyInfo.name}`}
                />
              )}
            </>
          )}
        </TabsContent>
        
        <TabsContent value="import" className="space-y-6">
          <StampImporter 
            onStampImage={handleStampImage}
            key="stamp-importer"
          />
        </TabsContent>
        
        <TabsContent value="pdf" className="space-y-6">
          <StampPdfUploader 
            stampImage={stampImage}
            key={`stamp-pdf-uploader-${activeTab === "pdf" ? "active" : "inactive"}`}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default StampGenerator;
