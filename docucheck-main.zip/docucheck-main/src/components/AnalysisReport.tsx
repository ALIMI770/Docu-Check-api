
import { AnalysisResult } from "@/types/document";
import ScoreDisplay from "./analysis/ScoreDisplay";
import AnalysisList from "./analysis/AnalysisList";
import AnalysisRecommendations from "./analysis/AnalysisRecommendations";
import AnalysisLoading from "./analysis/AnalysisLoading";
import EmptyAnalysis from "./analysis/EmptyAnalysis";

interface AnalysisReportProps {
  result: AnalysisResult | null;
  isAnalyzing: boolean;
  processingStep: {step: number, message: string} | null;
}

const AnalysisReport = ({ result, isAnalyzing, processingStep }: AnalysisReportProps) => {
  if (isAnalyzing) {
    return <AnalysisLoading processingStep={processingStep} />;
  }

  if (!result) {
    return <EmptyAnalysis />;
  }

  // S'assurer que toutes les propriétés nécessaires existent
  const score = result.score || 0;
  const checks = result.checks || [];
  const recommendations = result.recommendations || [];
  const timestamp = result.timestamp || new Date().toISOString();

  // Ajouter des logs de débogage pour voir les données reçues
  // console.log("Rapport d'analyse reçu:", JSON.stringify(result, null, 2));

  return (
    <div className="bg-white rounded-lg shadow-md h-full flex flex-col">
      <div className="p-6 border-b">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Rapport d'analyse</h2>
          <div className="text-sm text-gray-500">
            {new Date(timestamp).toLocaleString('fr-FR')}
          </div>
        </div>
        
        <ScoreDisplay score={score} />
        
        {result.siretFound && (
          <div className="mt-4 p-3 bg-blue-50 rounded-md border border-blue-100">
            <p className="text-sm font-medium text-blue-800">
              SIRET identifié : <span className="font-mono">{result.siretFound}</span>
            </p>
          </div>
        )}
        
        {/* Ajouter une section d'erreur si présente */}
        {result.error && (
          <div className="mt-4 p-3 bg-red-50 rounded-md border border-red-100">
            <p className="text-sm font-medium text-red-800">
              Erreur: {result.error}
            </p>
          </div>
        )}
      </div>
      
      <div className="flex-1 overflow-auto p-6">
        <div className="mb-6">
          {checks.length > 0 ? (
            <AnalysisList checks={checks} />
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>Aucune vérification n'a pu être effectuée.</p>
              <p className="text-sm mt-2">Essayez d'améliorer la qualité des documents ou de réessayer l'analyse.</p>
            </div>
          )}
        </div>
        
        <div className="mt-6 pt-6 border-t border-gray-200">
          {recommendations.length > 0 ? (
            <AnalysisRecommendations recommendations={recommendations} />
          ) : (
            <p className="text-sm text-gray-500">Aucune recommandation disponible.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default AnalysisReport;
