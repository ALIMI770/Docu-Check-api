
import { useState } from "react";
import { Upload, CheckCircle, FileText } from "lucide-react";
import { DocumentType } from "@/types/document";

interface UploadZoneProps {
  type: DocumentType;
  isUploaded: boolean;
  onFileUpload: (type: DocumentType, file: File) => void;
}

const documentLabels: Record<DocumentType, string> = {
  devis: "Devis",
  facture: "Facture",
  attestation: "Attestation sur l'honneur"
};

const UploadZone = ({ type, isUploaded, onFileUpload }: UploadZoneProps) => {
  const [isDragging, setIsDragging] = useState(false);
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = () => {
    setIsDragging(false);
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'application/pdf'].includes(file.type)) {
        onFileUpload(type, file);
      } else {
        alert("Seuls les fichiers image (PNG, JPEG, GIF, WEBP) et PDF sont acceptés.");
      }
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      if (['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'application/pdf'].includes(file.type)) {
        onFileUpload(type, file);
      } else {
        alert("Seuls les fichiers image (PNG, JPEG, GIF, WEBP) et PDF sont acceptés.");
      }
    }
  };
  
  return (
    <div 
      className={`border-2 rounded-lg p-4 flex flex-col items-center justify-center cursor-pointer transition-all ${
        isDragging 
          ? "border-primary border-dashed bg-primary/5" 
          : isUploaded 
            ? "border-green-500 bg-green-50" 
            : "border-dashed border-gray-300 hover:border-primary/60 hover:bg-primary/5"
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <label htmlFor={`file-${type}`} className="cursor-pointer w-full">
        <div className="flex flex-col items-center py-3">
          {isUploaded ? (
            <CheckCircle className="h-8 w-8 text-green-500 mb-2" />
          ) : (
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mb-2">
              {type === "devis" ? (
                <FileText className="h-5 w-5 text-primary" />
              ) : type === "facture" ? (
                <FileText className="h-5 w-5 text-primary" />
              ) : (
                <FileText className="h-5 w-5 text-primary" />
              )}
            </div>
          )}
          
          <p className="text-sm font-medium">
            {documentLabels[type]}
          </p>
          
          {isUploaded ? (
            <p className="text-xs text-green-600 mt-1">Document téléversé</p>
          ) : (
            <div className="flex flex-col items-center mt-2">
              <div className="flex items-center">
                <Upload className="h-3 w-3 text-gray-400 mr-1" />
                <span className="text-xs text-gray-500">Glisser ou cliquer pour téléverser</span>
              </div>
              <span className="text-xs text-gray-400 mt-1">(PNG, JPEG, GIF, WEBP, PDF acceptés)</span>
            </div>
          )}
        </div>
      </label>
      
      <input 
        type="file" 
        id={`file-${type}`} 
        accept="image/png,image/jpeg,image/gif,image/webp,application/pdf" 
        className="hidden" 
        onChange={handleFileChange}
      />
    </div>
  );
};

export default UploadZone;
