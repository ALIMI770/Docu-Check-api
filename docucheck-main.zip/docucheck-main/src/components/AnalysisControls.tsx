
import { useState } from "react";
import { DocumentType, DocumentStatus } from "@/types/document";
import { useToast } from "@/components/ui/use-toast";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

interface AnalysisControlsProps {
  documents: Record<DocumentType, DocumentStatus>;
  isAnalyzing: boolean;
  processingStep: {step: number, message: string} | null;
  onStartAnalysis: () => void;
  onReset: () => void;
  hasResults: boolean;
  singleFileMode?: boolean;
}

const AnalysisControls = ({
  documents,
  isAnalyzing,
  processingStep,
  onStartAnalysis,
  onReset,
  hasResults,
  singleFileMode = false
}: AnalysisControlsProps) => {
  // En mode fichier unique, vérifier si un document a été téléversé
  const allUploaded = singleFileMode 
    ? Object.values(documents).some(doc => doc.uploaded)
    : Object.values(documents).some(doc => doc.uploaded);
  
  return (
    <div className="mt-6 space-y-3">
      <Button
        className="w-full"
        onClick={onStartAnalysis}
        disabled={isAnalyzing || !allUploaded}
      >
        {isAnalyzing ? (
          <>
            <span className="animate-spin mr-2">⚙️</span>
            Analyse en cours...
          </>
        ) : (
          "Lancer l'analyse"
        )}
      </Button>
      
      {/* Indicateur de progression du traitement */}
      {processingStep && (
        <div className="mt-4">
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className="bg-blue-600 h-2.5 rounded-full" 
              style={{ width: `${(processingStep.step / 6) * 100}%` }}
            ></div>
          </div>
          <p className="text-sm text-gray-600 mt-2">
            Étape {processingStep.step}/6: {processingStep.message}
          </p>
        </div>
      )}
      
      {hasResults && (
        <Button
          variant="outline"
          className="w-full"
          onClick={onReset}
        >
          Réinitialiser
        </Button>
      )}
    </div>
  );
};

export default AnalysisControls;
