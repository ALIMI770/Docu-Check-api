
import { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { FileText, CreditCard, Stamp, LogOut, Navigation, Map } from "lucide-react";

interface UserData {
  name: string;
  email: string;
  credits: number;
}

const Header = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [userData, setUserData] = useState<UserData | null>(null);
  
  useEffect(() => {
    // Load user data from localStorage
    const userString = localStorage.getItem("user");
    if (userString) {
      setUserData(JSON.parse(userString));
    }
  }, []);
  
  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("user");
    
    toast({
      title: "Déconnexion réussie",
      description: "Vous avez été déconnecté avec succès",
    });
    
    navigate("/login");
  };
  
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };
  
  return (
    <header className="bg-white border-b">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/" className="flex items-center gap-2">
              <FileText className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold text-primary">DocuCheck AI</span>
            </Link>
            
            <nav className="hidden md:flex items-center gap-6 text-sm font-medium ml-6">
              <Link
                to="/"
                className={`transition-colors ${
                  location.pathname === "/"
                    ? "text-primary"
                    : "text-gray-600 hover:text-primary"
                }`}
              >
                <span className="flex items-center gap-1">
                  <FileText className="h-4 w-4" />
                  Analyse de documents
                </span>
              </Link>
              
              <Link
                to="/stamp-generator"
                className={`transition-colors ${
                  location.pathname === "/stamp-generator"
                    ? "text-primary"
                    : "text-gray-600 hover:text-primary"
                }`}
              >
                <span className="flex items-center gap-1">
                  <Stamp className="h-4 w-4" />
                  Générateur de tampon
                </span>
              </Link>
              
              <Link
                to="/route-optimization"
                className={`transition-colors ${
                  location.pathname === "/route-optimization"
                    ? "text-primary"
                    : "text-gray-600 hover:text-primary"
                }`}
              >
                <span className="flex items-center gap-1">
                  <Map className="h-4 w-4" />
                  Optimisation de tournées
                </span>
              </Link>
            </nav>
          </div>
          
          <div className="flex items-center gap-4">
            {userData && (
              <div className="hidden md:flex items-center gap-2 text-sm text-blue-700 bg-blue-50 px-3 py-1 rounded-full">
                <CreditCard className="h-4 w-4" />
                <span>{userData.credits} crédit{userData.credits !== 1 ? 's' : ''}</span>
              </div>
            )}
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-9 w-9 rounded-full">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src="" alt="Avatar" />
                    <AvatarFallback className="bg-primary text-white">
                      {userData ? getInitials(userData.name) : "UT"}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{userData?.name || "Utilisateur"}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {userData?.email || "utilisateur@exemple.fr"}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/" className="flex cursor-pointer items-center">
                    <FileText className="mr-2 h-4 w-4" />
                    <span>Analyse de documents</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/stamp-generator" className="flex cursor-pointer items-center">
                    <Stamp className="mr-2 h-4 w-4" />
                    <span>Générateur de tampon</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/route-optimization" className="flex cursor-pointer items-center">
                    <Map className="mr-2 h-4 w-4" />
                    <span>Optimisation de tournées</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  className="flex cursor-pointer items-center text-red-600 focus:text-red-600"
                  onClick={handleLogout}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Déconnexion</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
      
      {/* Mobile navigation */}
      <div className="md:hidden border-t">
        <nav className="flex justify-around">
          <Link
            to="/"
            className={`flex flex-col items-center py-2 flex-1 text-xs ${
              location.pathname === "/"
                ? "text-primary border-t-2 border-primary"
                : "text-gray-500"
            }`}
          >
            <FileText className="h-5 w-5 mb-1" />
            <span>Documents</span>
          </Link>
          
          <Link
            to="/stamp-generator"
            className={`flex flex-col items-center py-2 flex-1 text-xs ${
              location.pathname === "/stamp-generator"
                ? "text-primary border-t-2 border-primary"
                : "text-gray-500"
            }`}
          >
            <Stamp className="h-5 w-5 mb-1" />
            <span>Tampons</span>
          </Link>
          
          <Link
            to="/route-optimization"
            className={`flex flex-col items-center py-2 flex-1 text-xs ${
              location.pathname === "/route-optimization"
                ? "text-primary border-t-2 border-primary"
                : "text-gray-500"
            }`}
          >
            <Map className="h-5 w-5 mb-1" />
            <span>Tournées</span>
          </Link>
          
          <button
            onClick={handleLogout}
            className="flex flex-col items-center py-2 flex-1 text-xs text-gray-500"
          >
            <LogOut className="h-5 w-5 mb-1" />
            <span>Déconnexion</span>
          </button>
        </nav>
      </div>
    </header>
  );
};

export default Header;
