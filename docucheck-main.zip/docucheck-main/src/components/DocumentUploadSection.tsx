
import { DocumentType, DocumentStatus } from "@/types/document";
import UploadZone from "@/components/UploadZone";
import AnalysisControls from "@/components/AnalysisControls";
import SingleFileUpload from "@/components/SingleFileUpload";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trash2, FileCheck, AlertCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { analyzeMultipleDocumentsWithGpt } from "@/services/gptVisionService";

interface DocumentUploadSectionProps {
  documents: Record<DocumentType, DocumentStatus>;
  isAnalyzing: boolean;
  processingStep: {step: number, message: string} | null;
  onFileUpload: (type: DocumentType, file: File) => void;
  onSingleFileUpload: (file: File) => void;
  onStartAnalysis: () => void;
  onReset: () => void;
  hasResults: boolean;
  singleFileMode: boolean;
  setSingleFileMode: (mode: boolean) => void;
  availableCredits?: number;
  onBatchAnalysisComplete?: (results: any) => void;
}

const DocumentUploadSection = ({
  documents,
  isAnalyzing,
  processingStep,
  onFileUpload,
  onSingleFileUpload,
  onStartAnalysis,
  onReset,
  hasResults,
  singleFileMode,
  setSingleFileMode,
  availableCredits = 0,
  onBatchAnalysisComplete
}: DocumentUploadSectionProps) => {
  const [multipleFiles, setMultipleFiles] = useState<File[]>([]);
  const [isBatchProcessing, setIsBatchProcessing] = useState(false);
  const [batchProgress, setBatchProgress] = useState(0);
  const [currentProcessingFile, setCurrentProcessingFile] = useState<string>("");
  const { toast } = useToast();

  // Écouter les événements de progression du traitement par lot
  useEffect(() => {
    const handleBatchProgress = (e: CustomEvent) => {
      setBatchProgress(e.detail.progress);
      setCurrentProcessingFile(e.detail.currentFile);
    };

    window.addEventListener('batchProcessProgress', handleBatchProgress as EventListener);
    
    return () => {
      window.removeEventListener('batchProcessProgress', handleBatchProgress as EventListener);
    };
  }, []);

  const handleMultipleFilesUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!event.target.files) return;
    
    const newFiles = Array.from(event.target.files);
    setMultipleFiles(prev => [...prev, ...newFiles]);
  };

  const removeFile = (index: number) => {
    setMultipleFiles(prev => prev.filter((_, i) => i !== index));
  };
  
  const handleBatchAnalysis = async () => {
    if (multipleFiles.length === 0 || availableCredits < multipleFiles.length) {
      toast({
        title: "Traitement impossible",
        description: "Vérifiez que vous avez suffisamment de crédits pour analyser tous les fichiers.",
        variant: "destructive",
      });
      return;
    }
    
    setIsBatchProcessing(true);
    
    try {
      // Utiliser l'implémentation réelle du traitement par lot
      const batchResults = await analyzeMultipleDocumentsWithGpt(multipleFiles);
      
      // Notifier la fin du traitement
      toast({
        title: "Traitement par lot terminé",
        description: `${multipleFiles.length} fichiers ont été analysés.${batchResults.errors ? ` (${batchResults.errors.length} erreurs)` : ''}`,
        variant: batchResults.errors ? "default" : "default",
      });
      
      // Transmettre les résultats pour affichage
      if (onBatchAnalysisComplete) {
        onBatchAnalysisComplete(batchResults);
      }
      
      // Réinitialiser après l'analyse par lot
      setBatchProgress(100);
      setTimeout(() => {
        setIsBatchProcessing(false);
        setBatchProgress(0);
        setMultipleFiles([]);
      }, 1500);
      
    } catch (error) {
      console.error("Erreur lors du traitement par lot:", error);
      toast({
        title: "Erreur de traitement",
        description: "Une erreur est survenue lors du traitement par lot.",
        variant: "destructive",
      });
      setIsBatchProcessing(false);
      setBatchProgress(0);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Documents requis</h2>
      
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => setSingleFileMode(true)}
            className={`px-3 py-1.5 text-sm rounded-md ${singleFileMode ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'}`}
            disabled={isBatchProcessing}
          >
            PDF unique
          </button>
          <button 
            onClick={() => setSingleFileMode(false)}
            className={`px-3 py-1.5 text-sm rounded-md ${!singleFileMode ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'}`}
            disabled={isBatchProcessing}
          >
            Documents séparés
          </button>
        </div>
        {availableCredits > 0 && (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            {availableCredits} crédits disponibles
          </Badge>
        )}
      </div>
      
      {singleFileMode ? (
        <div className="mb-4">
          <SingleFileUpload onFileUpload={onSingleFileUpload} disabled={isBatchProcessing} />
          
          <div className="mt-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center justify-between">
                  Traitement par lots
                  <Badge variant="outline" className="ml-2">Nouveau</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Déposez plusieurs PDF pour les traiter en série. Chaque dossier consomme 1 crédit.
                </p>
                
                {!isBatchProcessing ? (
                  <div className="flex items-center justify-center w-full">
                    <label htmlFor="dropzone-file-batch" className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 border-gray-300">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <p className="mb-2 text-sm text-gray-500">
                          <span className="font-semibold">Cliquez pour ajouter</span> ou glissez des fichiers
                        </p>
                        <p className="text-xs text-gray-500">PDF (MAX. 20MB par fichier)</p>
                      </div>
                      <input id="dropzone-file-batch" type="file" className="hidden" multiple accept=".pdf,.jpg,.jpeg,.png" onChange={handleMultipleFilesUpload} />
                    </label>
                  </div>
                ) : (
                  <div className="w-full">
                    <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                      <div 
                        className="bg-blue-600 h-2.5 rounded-full transition-all duration-300" 
                        style={{ width: `${batchProgress}%` }}
                      ></div>
                    </div>
                    <p className="text-center text-sm text-gray-600">
                      {currentProcessingFile ? (
                        <>Traitement de <span className="font-medium">{currentProcessingFile}</span>... {batchProgress}%</>
                      ) : (
                        <>Traitement en cours... {batchProgress}%</>
                      )}
                    </p>
                  </div>
                )}
                
                {multipleFiles.length > 0 && (
                  <div className="mt-4">
                    <h3 className="font-medium text-sm mb-2">Fichiers à analyser ({multipleFiles.length})</h3>
                    <div className="max-h-40 overflow-y-auto border rounded-md">
                      {multipleFiles.map((file, index) => (
                        <div key={index} className="flex items-center justify-between px-3 py-2 border-b last:border-b-0">
                          <div className="flex items-center">
                            <div className="bg-gray-100 p-2 rounded mr-2">
                              <svg className="w-4 h-4 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M4 4a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V8.342a2 2 0 00-.602-1.43l-4.44-4.342A2 2 0 0012.56 2H4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                              </svg>
                            </div>
                            <span className="text-sm truncate max-w-xs">{file.name}</span>
                          </div>
                          <Button variant="ghost" size="sm" onClick={() => removeFile(index)} disabled={isBatchProcessing}>
                            <Trash2 className="h-4 w-4 text-gray-500" />
                          </Button>
                        </div>
                      ))}
                    </div>
                    <div className="mt-2 flex justify-between">
                      <div className="text-xs text-gray-500 flex items-center">
                        <AlertCircle className="h-3 w-3 mr-1" />
                        Crédits nécessaires: {multipleFiles.length}
                      </div>
                      <Button 
                        variant="default" 
                        size="sm"
                        onClick={handleBatchAnalysis}
                        disabled={multipleFiles.length === 0 || availableCredits < multipleFiles.length || isBatchProcessing}
                        className="flex items-center"
                      >
                        <FileCheck className="h-4 w-4 mr-1" />
                        Analyser tous les fichiers
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <UploadZone 
            type="devis" 
            isUploaded={documents.devis.uploaded}
            onFileUpload={onFileUpload}
          />
          <UploadZone 
            type="facture" 
            isUploaded={documents.facture.uploaded}
            onFileUpload={onFileUpload}
          />
          <UploadZone 
            type="attestation" 
            isUploaded={documents.attestation.uploaded}
            onFileUpload={onFileUpload}
          />
        </div>
      )}
      
      <AnalysisControls
        documents={documents}
        isAnalyzing={isAnalyzing}
        processingStep={processingStep}
        onStartAnalysis={onStartAnalysis}
        onReset={onReset}
        hasResults={hasResults}
        singleFileMode={singleFileMode}
      />
    </div>
  );
};

export default DocumentUploadSection;
