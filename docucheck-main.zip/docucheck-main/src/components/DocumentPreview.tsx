
import { DocumentStatus, DocumentType } from "@/types/document";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileText, AlertTriangle } from "lucide-react";
import PDFPreview from "./PDFPreview";

interface DocumentPreviewProps {
  documents: Record<DocumentType, DocumentStatus>;
  singlePdfFile: File | null;
}

const DocumentPreview = ({ documents, singlePdfFile }: DocumentPreviewProps) => {
  const hasAnyDocument = Object.values(documents).some(doc => doc.uploaded) || singlePdfFile !== null;
  
  if (!hasAnyDocument) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6 h-[500px] flex flex-col items-center justify-center">
        <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
          <FileText className="h-8 w-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-700 mb-2">Aucun document</h3>
        <p className="text-sm text-gray-500 text-center">
          Téléversez des documents pour les prévisualiser ici
        </p>
      </div>
    );
  }
  
  // Si on est en mode fichier unique et qu'un PDF a été téléversé
  if (singlePdfFile) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold mb-4">Prévisualisation du dossier</h2>
        <div className="h-[500px] w-full overflow-hidden">
          <PDFPreview file={singlePdfFile} />
        </div>
      </div>
    );
  }

  // Mode documents séparés
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Prévisualisation</h2>
      <Tabs defaultValue={Object.entries(documents).find(([_, doc]) => doc.uploaded)?.[0] || "devis"}>
        <TabsList className="grid grid-cols-3">
          <TabsTrigger value="devis" disabled={!documents.devis.uploaded}>Devis</TabsTrigger>
          <TabsTrigger value="facture" disabled={!documents.facture.uploaded}>Facture</TabsTrigger>
          <TabsTrigger value="attestation" disabled={!documents.attestation.uploaded}>Attestation</TabsTrigger>
        </TabsList>
        
        <TabsContent value="devis" className="h-[450px] overflow-hidden">
          {documents.devis.uploaded && documents.devis.file ? (
            <PDFPreview file={documents.devis.file} />
          ) : (
            <DocumentPlaceholder type="devis" />
          )}
        </TabsContent>
        
        <TabsContent value="facture" className="h-[450px] overflow-hidden">
          {documents.facture.uploaded && documents.facture.file ? (
            <PDFPreview file={documents.facture.file} />
          ) : (
            <DocumentPlaceholder type="facture" />
          )}
        </TabsContent>
        
        <TabsContent value="attestation" className="h-[450px] overflow-hidden">
          {documents.attestation.uploaded && documents.attestation.file ? (
            <PDFPreview file={documents.attestation.file} />
          ) : (
            <DocumentPlaceholder type="attestation" />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

const DocumentPlaceholder = ({ type }: { type: DocumentType }) => {
  return (
    <div className="h-full w-full flex flex-col items-center justify-center border-2 border-dashed border-gray-200 rounded-md p-6">
      <AlertTriangle className="h-12 w-12 text-amber-500 mb-4" />
      <h3 className="text-lg font-medium mb-2">{type} non téléversé</h3>
      <p className="text-sm text-gray-500 text-center">
        Veuillez téléverser le document pour le prévisualiser
      </p>
    </div>
  );
};

export default DocumentPreview;
