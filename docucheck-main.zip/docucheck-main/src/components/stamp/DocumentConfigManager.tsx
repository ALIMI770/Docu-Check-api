
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Plus, Save, Trash2, Settings, Check, Cog } from "lucide-react";
import { DocumentConfig } from "@/hooks/use-pdf-processor";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

interface DocumentConfigManagerProps {
  configs: DocumentConfig[];
  activeConfig: string | null;
  saveConfig: (name: string, description: string) => string;
  deleteConfig: (id: string) => void;
  applyConfig: (id: string) => void;
  setDefaultConfig: (id: string | null) => void;
  defaultConfig: string | null;
}

const DocumentConfigManager = ({
  configs,
  activeConfig,
  saveConfig,
  deleteConfig,
  applyConfig,
  setDefaultConfig,
  defaultConfig
}: DocumentConfigManagerProps) => {
  const [isCreating, setIsCreating] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [newConfigName, setNewConfigName] = useState("");
  const [newConfigDescription, setNewConfigDescription] = useState("");
  const [isDefaultConfig, setIsDefaultConfig] = useState(false);
  
  const handleSaveConfig = () => {
    if (newConfigName.trim()) {
      const configId = saveConfig(newConfigName.trim(), newConfigDescription.trim());
      
      // Set as default if requested
      if (isDefaultConfig) {
        setDefaultConfig(configId);
      }
      
      setNewConfigName("");
      setNewConfigDescription("");
      setIsDefaultConfig(false);
      setIsCreating(false);
    }
  };

  const handleSetDefaultConfig = (configId: string) => {
    const isDefault = defaultConfig === configId;
    setDefaultConfig(isDefault ? null : configId);
  };
  
  return (
    <div className="bg-white p-4 rounded-lg border shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold flex items-center">
          <Cog className="h-5 w-5 mr-2 text-blue-600" />
          Configurations de liasses
        </h3>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => setShowSettings(!showSettings)}
          className="h-8"
        >
          <Settings className="h-4 w-4 mr-2" />
          {showSettings ? "Masquer réglages" : "Afficher réglages"}
        </Button>
      </div>
      
      <Button 
        className="w-full mb-4"
        onClick={() => setIsCreating(true)}
        variant="outline"
      >
        <Plus className="h-4 w-4 mr-2" />
        Nouvelle configuration
      </Button>
      
      {configs.length > 0 ? (
        <div className="grid gap-3">
          {configs.map(config => (
            <div 
              key={config.id}
              className={`flex justify-between items-center p-3 rounded border ${
                activeConfig === config.id ? 'bg-blue-50 border-blue-200' : 
                defaultConfig === config.id ? 'bg-green-50 border-green-200' : 'bg-white'
              }`}
            >
              <div className="flex-1">
                <div className="flex items-center">
                  <FileText className="h-4 w-4 text-blue-500 mr-2" />
                  <h4 className="font-medium">{config.name}</h4>
                  {defaultConfig === config.id && (
                    <span className="ml-2 text-xs px-2 py-0.5 bg-green-100 text-green-800 rounded-full">Par défaut</span>
                  )}
                </div>
                {config.description && (
                  <p className="text-sm text-gray-500 mt-1 ml-6">{config.description}</p>
                )}
              </div>
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => applyConfig(config.id)}
                  className="h-8"
                >
                  Appliquer
                </Button>
                {showSettings && (
                  <>
                    <Button 
                      size="sm" 
                      variant={defaultConfig === config.id ? "default" : "outline"} 
                      onClick={() => handleSetDefaultConfig(config.id)}
                      className="h-8"
                    >
                      {defaultConfig === config.id ? (
                        <><Check className="h-4 w-4 mr-1" /> Par défaut</>
                      ) : "Définir par défaut"}
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => deleteConfig(config.id)}
                      className="h-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center p-4 border rounded bg-gray-50 text-gray-500">
          Aucune configuration enregistrée
        </div>
      )}
      
      <Dialog open={isCreating} onOpenChange={setIsCreating}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle>Nouvelle configuration de liasse</DialogTitle>
            <DialogDescription>
              Enregistrez la position actuelle du tampon et les pages sélectionnées comme une configuration pour une liasse de documents spécifique.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="config-name" className="text-sm font-medium">
                Nom de la configuration
              </label>
              <Input
                id="config-name"
                value={newConfigName}
                onChange={(e) => setNewConfigName(e.target.value)}
                placeholder="Ex: Factures fournisseurs"
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="config-description" className="text-sm font-medium">
                Description (optionnelle)
              </label>
              <Input
                id="config-description" 
                value={newConfigDescription}
                onChange={(e) => setNewConfigDescription(e.target.value)}
                placeholder="Ex: Tampon en haut à droite sur la première page"
              />
            </div>
            
            <div className="flex items-center space-x-2 pt-2">
              <Switch 
                id="default-config" 
                checked={isDefaultConfig}
                onCheckedChange={setIsDefaultConfig}
              />
              <Label htmlFor="default-config">Définir comme configuration par défaut</Label>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreating(false)}>
              Annuler
            </Button>
            <Button 
              onClick={handleSaveConfig}
              disabled={!newConfigName.trim()}
            >
              <Save className="h-4 w-4 mr-2" />
              Enregistrer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DocumentConfigManager;
