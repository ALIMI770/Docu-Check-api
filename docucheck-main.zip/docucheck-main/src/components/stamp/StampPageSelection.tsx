
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { CheckSquare, Square } from "lucide-react";

interface StampPageSelectionProps {
  currentPage: number;
  totalPages: number;
  selectedPages: Record<number, boolean>;
  togglePageSelection: (page: number) => void;
  selectAllPages: (selected: boolean) => void;
}

const StampPageSelection = ({
  currentPage,
  totalPages,
  selectedPages,
  togglePageSelection,
  selectAllPages
}: StampPageSelectionProps) => {
  // Calculate if all pages are selected
  const allSelected = totalPages > 0 && 
    Object.values(selectedPages).filter(Boolean).length === totalPages;
  
  // Calculate if any pages are selected
  const anySelected = Object.values(selectedPages).some(Boolean);
  
  // Group pages into rows for better display
  const pagesPerRow = 5;
  const pageRows: number[][] = [];
  for (let i = 0; i < totalPages; i += pagesPerRow) {
    pageRows.push(Array.from({ length: Math.min(pagesPerRow, totalPages - i) }, (_, j) => i + j));
  }
  
  return (
    <div className="bg-white p-4 rounded-lg border shadow-sm">
      <div className="flex justify-between items-center mb-3">
        <p className="text-sm font-medium text-gray-700">Pages à tamponner</p>
        <div className="flex gap-2">
          <Button 
            size="sm" 
            variant="outline" 
            onClick={() => selectAllPages(true)}
            disabled={allSelected}
            className="text-xs h-7 px-2"
          >
            <CheckSquare className="h-3 w-3 mr-1" />
            Tout
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            onClick={() => selectAllPages(false)}
            disabled={!anySelected}
            className="text-xs h-7 px-2"
          >
            <Square className="h-3 w-3 mr-1" />
            Aucune
          </Button>
        </div>
      </div>
      
      <div className="max-h-24 overflow-y-auto border rounded bg-gray-50 p-2">
        {pageRows.map((row, rowIndex) => (
          <div key={`row-${rowIndex}`} className="flex flex-wrap gap-1 mb-1">
            {row.map(pageIndex => (
              <div 
                key={`page-${pageIndex}`} 
                className={`flex items-center gap-1 p-1 rounded ${pageIndex === currentPage ? 'bg-blue-50 border border-blue-200' : ''}`}
              >
                <Checkbox 
                  id={`page-${pageIndex}`}
                  checked={selectedPages[pageIndex] ?? false}
                  onCheckedChange={() => togglePageSelection(pageIndex)}
                />
                <label 
                  htmlFor={`page-${pageIndex}`} 
                  className="text-xs cursor-pointer select-none"
                >
                  {pageIndex + 1}
                </label>
              </div>
            ))}
          </div>
        ))}
      </div>
      
      <div className="mt-2 text-xs text-gray-500 text-center">
        {Object.values(selectedPages).filter(Boolean).length} page(s) sur {totalPages} sélectionnée(s)
      </div>
    </div>
  );
};

export default StampPageSelection;
