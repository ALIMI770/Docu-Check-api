
import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Upload, Image as ImageIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { STAMP_DIMENSIONS } from '@/hooks/use-pdf-processor';

interface StampImporterProps {
  onStampImage: (image: string) => void;
}

const StampImporter = ({ onStampImage }: StampImporterProps) => {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [width, setWidth] = useState<number>(Math.round(STAMP_DIMENSIONS.width / (72/25.4))); // Convert from points to mm
  const [height, setHeight] = useState<number>(Math.round(STAMP_DIMENSIONS.height / (72/25.4))); // Convert from points to mm
  const [maintainAspectRatio, setMaintainAspectRatio] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const aspectRatioRef = useRef<number>(width / height);
  const { toast } = useToast();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsLoading(true);
      const file = e.target.files[0];
      
      // Check file type
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Format non supporté",
          description: "Veuillez télécharger une image (PNG, JPG, GIF).",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target && typeof event.target.result === 'string') {
          setUploadedImage(event.target.result);
          
          // Load image to get dimensions
          const img = new Image();
          img.onload = () => {
            aspectRatioRef.current = img.width / img.height;
            setIsLoading(false);
          };
          img.src = event.target.result;
        }
      };
      reader.onerror = () => {
        toast({
          title: "Erreur de lecture",
          description: "Impossible de lire le fichier téléchargé.",
          variant: "destructive",
        });
        setIsLoading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleWidthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newWidth = parseInt(e.target.value);
    setWidth(newWidth);
    
    if (maintainAspectRatio && !isNaN(newWidth) && aspectRatioRef.current) {
      const newHeight = Math.round(newWidth / aspectRatioRef.current);
      setHeight(newHeight);
    }
  };

  const handleHeightChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newHeight = parseInt(e.target.value);
    setHeight(newHeight);
    
    if (maintainAspectRatio && !isNaN(newHeight) && aspectRatioRef.current) {
      const newWidth = Math.round(newHeight * aspectRatioRef.current);
      setWidth(newWidth);
    }
  };

  const handleMaintainAspectRatioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMaintainAspectRatio(e.target.checked);
    
    // Update aspect ratio
    if (e.target.checked && uploadedImage) {
      aspectRatioRef.current = width / height;
    }
  };

  const handleUseImage = () => {
    if (uploadedImage) {
      try {
        setIsLoading(true);
        
        // Convert mm to points (72 points per inch, 25.4 mm per inch)
        const widthInPoints = Math.round(width * (72/25.4));
        const heightInPoints = Math.round(height * (72/25.4));
        
        // Create canvas with correct dimensions
        const canvas = document.createElement('canvas');
        canvas.width = widthInPoints;
        canvas.height = heightInPoints;
        
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          throw new Error('Could not get canvas context');
        }
        
        // Draw image to canvas with proper dimensions
        const img = new Image();
        img.onload = () => {
          ctx.drawImage(img, 0, 0, widthInPoints, heightInPoints);
          
          // Convert to PNG
          const resizedImage = canvas.toDataURL('image/png');
          onStampImage(resizedImage);
          
          toast({
            title: "Tampon importé",
            description: `Le tampon a été redimensionné à ${width} × ${height} mm.`,
          });
          
          setIsLoading(false);
        };
        img.onerror = () => {
          throw new Error('Failed to load image');
        };
        img.src = uploadedImage;
      } catch (error) {
        console.error('Error processing image:', error);
        toast({
          title: "Erreur",
          description: "Une erreur est survenue lors du traitement de l'image.",
          variant: "destructive",
        });
        setIsLoading(false);
      }
    }
  };

  const resetForm = () => {
    setUploadedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    setWidth(Math.round(STAMP_DIMENSIONS.width / (72/25.4))); // Reset to default width in mm
    setHeight(Math.round(STAMP_DIMENSIONS.height / (72/25.4))); // Reset to default height in mm
    setMaintainAspectRatio(true);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Importer un tampon existant</CardTitle>
        <CardDescription>
          Téléchargez une image existante de votre tampon et ajustez sa taille
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="grid w-full items-center gap-1.5">
            <Label htmlFor="image-upload">Image du tampon</Label>
            <div className="flex items-center gap-2">
              <Input
                id="image-upload"
                type="file"
                accept="image/*"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="flex-1"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="h-4 w-4 mr-2" />
                Parcourir
              </Button>
            </div>
            <p className="text-sm text-gray-500">
              Formats acceptés: PNG, JPG, JPEG, GIF
            </p>
          </div>
          
          {uploadedImage ? (
            <div className="space-y-4">
              <div className="flex justify-center p-4 bg-gray-50 rounded-md border">
                <div className="relative" style={{ width: `${Math.min(300, width)}px` }}>
                  <img
                    src={uploadedImage}
                    alt="Aperçu du tampon"
                    className="object-contain max-w-full max-h-[200px] rounded shadow-sm"
                  />
                  <div className="absolute bottom-0 right-0 bg-black bg-opacity-70 text-white px-2 py-1 text-xs rounded">
                    {width} × {height} mm
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="maintainAspectRatio"
                    checked={maintainAspectRatio}
                    onChange={handleMaintainAspectRatioChange}
                    className="rounded"
                  />
                  <Label htmlFor="maintainAspectRatio">Conserver les proportions</Label>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="width">Largeur (mm)</Label>
                    <Input
                      id="width"
                      type="number"
                      min="10"
                      max="500"
                      value={width}
                      onChange={handleWidthChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="height">Hauteur (mm)</Label>
                    <Input
                      id="height"
                      type="number"
                      min="10"
                      max="500"
                      value={height}
                      onChange={handleHeightChange}
                    />
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={resetForm} disabled={isLoading}>
                  Annuler
                </Button>
                <Button onClick={handleUseImage} disabled={isLoading || !uploadedImage}>
                  {isLoading ? (
                    <>Traitement...</>
                  ) : (
                    <>Utiliser ce tampon</>
                  )}
                </Button>
              </div>
            </div>
          ) : isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-40 w-full" />
              <div className="grid grid-cols-2 gap-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center p-12 border-2 border-dashed border-gray-300 rounded-md">
              <ImageIcon className="h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-500 text-center mb-2">
                Aucune image sélectionnée
              </p>
              <p className="text-sm text-gray-400 text-center">
                Téléchargez une image de votre tampon existant
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default StampImporter;
