import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Download, Loader2, Info, FileText, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import StampPdfCanvas from "./StampPdfCanvas";
import StampPdfUploadZone from "./StampPdfUploadZone";
import StampPreviewControls from "./StampPreviewControls";
import StampProcessingProgress from "./StampProcessingProgress";
import { usePdfProcessor, DEFAULT_POSITION, STAMP_DIMENSIONS } from "@/hooks/use-pdf-processor";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

interface StampPdfUploaderProps {
  stampImage: string | null;
}

const StampPdfUploader = ({ stampImage }: StampPdfUploaderProps) => {
  const { toast } = useToast();
  const [showPreview, setShowPreview] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isMountedRef = useRef(true);
  
  useEffect(() => {
    isMountedRef.current = true;
    console.log("StampPdfUploader mounted, stampImage:", stampImage ? "present" : "missing");
    
    return () => {
      console.log("StampPdfUploader unmounting");
      isMountedRef.current = false;
    };
  }, [stampImage]);
  
  const {
    state,
    pdfDocRef,
    handleFileChange,
    resetUpload,
    loadPdfPreview,
    changePage,
    changeZoom,
    moveStamp,
    rotateStamp,
    resetToDefaultPosition,
    togglePageSelection,
    selectAllPages,
    saveTemplate,
    deleteTemplate,
    applyTemplate,
    saveDocumentConfig,
    deleteDocumentConfig,
    applyDocumentConfig,
    setDefaultDocumentConfig,
    applyStampToPdf,
    togglePageSpecificMode,
    setExactPosition
  } = usePdfProcessor(stampImage);

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (!isMountedRef.current) return;
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type === 'application/pdf') {
        handleFileChange(file);
      } else {
        if (isMountedRef.current) {
          toast({
            title: "Format non supporté",
            description: "Seuls les fichiers PDF sont acceptés",
            variant: "destructive",
          });
        }
      }
    }
  };

  const handleShowPreview = async () => {
    if (!isMountedRef.current) return false;
    
    if (!stampImage) {
      console.error("No stamp image available for preview");
      toast({
        title: "Tampon manquant",
        description: "Veuillez d'abord générer un tampon",
        variant: "destructive",
      });
      return false;
    }
    
    console.log("Starting preview load...");
    
    try {
      const success = await loadPdfPreview();
      console.log("Preview load result:", success);
      
      if (success && isMountedRef.current) {
        setShowPreview(true);
        return true;
      }
      return false;
    } catch (error) {
      console.error("Error loading preview:", error);
      if (isMountedRef.current) {
        toast({
          title: "Erreur de prévisualisation",
          description: "Impossible de charger la prévisualisation du PDF",
          variant: "destructive",
        });
      }
      return false;
    }
  };

  const handleApplyStamp = async () => {
    if (!isMountedRef.current) {
      console.log("Component unmounted, cannot apply stamp");
      return false;
    }
    
    if (!stampImage) {
      console.error("No stamp image available for stamping");
      toast({
        title: "Tampon manquant",
        description: "Veuillez d'abord générer un tampon",
        variant: "destructive",
      });
      return false;
    }
    
    console.log("Starting stamp application...");
    
    try {
      console.log("Calling applyStampToPdf...");
      
      const success = await applyStampToPdf();
      console.log("Stamp application result:", success);
      
      if (success && isMountedRef.current) {
        toast({
          title: "Tampon appliqué",
          description: "Le PDF a été tamponné et téléchargé avec succès.",
        });
        
        setShowPreview(false);
        return true;
      }
      return false;
    } catch (error) {
      console.error("Erreur lors de l'application du tampon:", error);
      if (isMountedRef.current) {
        toast({
          title: "Erreur",
          description: "Une erreur est survenue lors de l'application du tampon.",
          variant: "destructive",
        });
      }
      return false;
    }
  };

  const handleDirectApply = async () => {
    if (!isMountedRef.current) return;
    
    if (!stampImage) {
      console.error("No stamp image available for direct application");
      toast({
        title: "Tampon manquant",
        description: "Veuillez d'abord générer un tampon",
        variant: "destructive",
      });
      return;
    }
    
    if (!state.pdfFile) {
      console.error("No PDF file available for direct application");
      toast({
        title: "PDF manquant",
        description: "Veuillez d'abord télécharger un PDF",
        variant: "destructive",
      });
      return;
    }
    
    console.log("Starting direct application...");
    console.log("Default config:", state.defaultConfig);
    
    try {
      if (state.defaultConfig) {
        console.log("Applying default config:", state.defaultConfig);
        applyDocumentConfig(state.defaultConfig);
        
        try {
          const success = await applyStampToPdf();
          console.log("Direct stamp application result:", success);
          
          if (isMountedRef.current && success) {
            toast({
              title: "Configuration par défaut appliquée",
              description: "Le tampon a été appliqué selon la configuration par défaut et le PDF a été téléchargé.",
            });
          }
        } catch (error) {
          console.error("Erreur lors de l'application automatique:", error);
          if (isMountedRef.current) {
            toast({
              title: "Erreur",
              description: "Une erreur est survenue lors de l'application automatique du tampon.",
              variant: "destructive",
            });
          }
        }
      } else {
        console.log("No default config, showing preview");
        const previewLoaded = await handleShowPreview();
        if (!previewLoaded) {
          console.error("Failed to load preview, cannot proceed");
          if (isMountedRef.current) {
            toast({
              title: "Erreur",
              description: "Impossible de charger la prévisualisation du PDF",
              variant: "destructive",
            });
          }
        }
      }
    } catch (error) {
      console.error("Error in direct apply workflow:", error);
      if (isMountedRef.current) {
        toast({
          title: "Erreur",
          description: "Une erreur est survenue lors du traitement de votre PDF.",
          variant: "destructive",
        });
      }
    }
  };

  const displayDimensions = () => {
    const widthInMm = Math.round(STAMP_DIMENSIONS.width / (72/25.4));
    const heightInMm = Math.round(STAMP_DIMENSIONS.height / (72/25.4));
    return `${widthInMm} × ${heightInMm} mm`;
  };

  const handleOpenChange = (open: boolean) => {
    if (!open && isMountedRef.current) {
      console.log("Dialog closing...");
      setShowPreview(false);
    }
  };

  const isActionButtonDisabled = () => {
    return !stampImage || !state.isUploaded || state.isProcessing;
  };

  const getButtonAction = () => {
    if (showPreview) {
      return handleApplyStamp;
    } else if (state.defaultConfig) {
      return handleDirectApply;
    } else {
      return handleShowPreview;
    }
  };

  const getButtonText = () => {
    if (state.isProcessing) {
      return (
        <>
          <span className="mr-2">
            <Loader2 className="h-4 w-4 inline animate-spin" />
          </span>
          Traitement en cours...
        </>
      );
    } else if (showPreview) {
      return (
        <>
          <Download className="h-4 w-4 mr-2" />
          Télécharger le PDF tamponné
        </>
      );
    } else if (state.defaultConfig) {
      return (
        <>
          <Download className="h-4 w-4 mr-2" />
          Appliquer avec config par défaut
        </>
      );
    } else {
      return (
        <>
          <Settings className="h-4 w-4 mr-2" />
          Configurer le tampon
        </>
      );
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Appliquer le tampon sur un PDF</CardTitle>
        <CardDescription>
          Téléchargez un PDF puis positionnez et enregistrez le tampon manuellement selon vos besoins.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!stampImage ? (
          <div className="p-4 mb-4 border border-amber-200 bg-amber-50 rounded text-amber-700">
            <p>Vous devez d'abord générer un tampon dans l'onglet "Créer un tampon"</p>
          </div>
        ) : (
          <>
            <div className="flex items-start space-x-3 p-4 border border-blue-100 bg-blue-50 rounded-md mb-4">
              <Info className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-medium text-blue-800 text-sm">Informations sur le tampon</h3>
                <p className="text-sm text-blue-700">
                  Dimension du tampon: {displayDimensions()}<br />
                  Position configurable manuellement selon vos besoins.
                </p>
              </div>
            </div>
            
            <StampPdfUploadZone 
              pdfFile={state.pdfFile}
              isUploaded={state.isUploaded}
              fileInputRef={fileInputRef}
              onFileChange={handleFileChange}
              onDrop={handleDrop}
              onReset={resetUpload}
              onPreview={handleShowPreview}
              isProcessing={state.isProcessing}
            />
            
            {state.documentConfigs.length > 0 && state.isUploaded && !state.isProcessing && (
              <div className="mt-4 p-4 border rounded-md bg-white">
                <div className="flex justify-between items-center mb-2">
                  <p className="text-sm font-medium">Appliquer une configuration de liasse</p>
                  
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Settings className="h-4 w-4 mr-2" />
                        Gérer
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-80 bg-white">
                      <div className="space-y-2">
                        <h4 className="font-medium">Gestion des configurations</h4>
                        <p className="text-sm text-gray-500">
                          Choisissez une configuration par défaut pour l'appliquer automatiquement
                        </p>
                        <div className="space-y-2 mt-2">
                          {state.documentConfigs.map((config) => (
                            <div key={config.id} className="flex items-center justify-between">
                              <span className="text-sm">{config.name}</span>
                              <Button 
                                size="sm" 
                                variant={state.defaultConfig === config.id ? "default" : "outline"}
                                onClick={() => setDefaultDocumentConfig(
                                  state.defaultConfig === config.id ? null : config.id
                                )}
                              >
                                {state.defaultConfig === config.id ? "Par défaut" : "Définir par défaut"}
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="mb-3">
                  <Select
                    onValueChange={(value) => applyDocumentConfig(value)}
                    value={state.activeConfig || undefined}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Sélectionner une configuration" />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      {state.documentConfigs.map(config => (
                        <SelectItem key={config.id} value={config.id}>
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 text-blue-500 mr-2" />
                            {config.name}
                            {state.defaultConfig === config.id && (
                              <span className="ml-2 text-xs px-1.5 py-0.5 bg-green-100 text-green-800 rounded-full">
                                Par défaut
                              </span>
                            )}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-xs text-gray-500">
                  Les configurations appliquent automatiquement des positions personnalisées pour chaque page du document
                </p>
              </div>
            )}
          </>
        )}
        
        <StampProcessingProgress progress={state.processingProgress} />
      </CardContent>
      <CardFooter>
        <Button
          className="w-full"
          disabled={isActionButtonDisabled()}
          onClick={getButtonAction()}
        >
          {getButtonText()}
        </Button>
      </CardFooter>

      <Dialog 
        open={showPreview} 
        onOpenChange={handleOpenChange}
      >
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-auto bg-white">
          <DialogHeader>
            <DialogTitle>Positionnement du tampon</DialogTitle>
            <DialogDescription>
              Utilisez les contrôles ci-dessous pour ajuster la position du tampon sur chaque page individuellement.
            </DialogDescription>
          </DialogHeader>
          
          {showPreview && pdfDocRef.current && (
            <div className="grid grid-cols-1 gap-4">
              <StampPdfCanvas 
                pdfDoc={pdfDocRef.current}
                currentPage={state.currentPage}
                scale={state.scale}
                pageWidth={state.pageWidth}
                pageHeight={state.pageHeight}
                stampPosition={state.stampPosition}
                rotation={state.rotation}
                stampWidth={state.stampWidth}
                stampHeight={state.stampHeight}
                stampImage={stampImage}
                canvasRef={canvasRef}
                key={`stamp-pdf-canvas-${state.currentPage}-${state.scale}-${Math.round(state.stampPosition.x)}-${Math.round(state.stampPosition.y)}-${state.rotation}`}
              />
              
              <StampPreviewControls 
                currentPage={state.currentPage}
                totalPages={state.totalPages}
                changePage={changePage}
                scale={state.scale}
                changeZoom={changeZoom}
                moveStamp={moveStamp}
                rotateStamp={rotateStamp}
                rotation={state.rotation}
                stampPosition={state.stampPosition}
                onConfirm={handleApplyStamp}
                selectedPages={state.selectedPages}
                togglePageSelection={togglePageSelection}
                selectAllPages={selectAllPages}
                templates={state.templates}
                activeTemplate={state.activeTemplate}
                saveTemplate={saveTemplate}
                deleteTemplate={deleteTemplate}
                applyTemplate={applyTemplate}
                resetToDefaultPosition={resetToDefaultPosition}
                documentConfigs={state.documentConfigs}
                activeConfig={state.activeConfig}
                defaultConfig={state.defaultConfig}
                saveDocumentConfig={saveDocumentConfig}
                deleteDocumentConfig={deleteDocumentConfig}
                applyDocumentConfig={applyDocumentConfig}
                setDefaultDocumentConfig={setDefaultDocumentConfig}
                pageSpecificMode={state.pageSpecificMode}
                togglePageSpecificMode={togglePageSpecificMode}
                setExactPosition={setExactPosition}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default StampPdfUploader;
