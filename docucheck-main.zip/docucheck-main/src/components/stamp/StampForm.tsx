
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Loader2, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { fetchCompanyBySiret, formatCompanyAddress } from "@/services/papersAPI";

const formSchema = z.object({
  name: z.string().min(2, {
    message: "Le nom de l'entreprise doit comporter au moins 2 caractères.",
  }),
  address: z.string().min(5, {
    message: "L'adresse doit comporter au moins 5 caractères.",
  }),
  siret: z.string().regex(/^\d{14}$/, {
    message: "Le SIRET doit comporter exactement 14 chiffres.",
  }),
  vatNumber: z.string().regex(/^FR\d{11}$/, {
    message: "Le numéro de TVA doit être au format FR suivi de 11 chiffres.",
  }),
  rcsNumber: z.string().optional(),
});

export type StampFormValues = z.infer<typeof formSchema>;

interface StampFormProps {
  onCompanyInfo: (info: StampFormValues) => void;
  useCredits: (amount: number) => boolean;
  setIsLoading: (isLoading: boolean) => void;
}

const StampForm = ({ onCompanyInfo, useCredits, setIsLoading }: StampFormProps) => {
  const { toast } = useToast();
  const [isFetchingSiret, setIsFetchingSiret] = useState(false);
  const [siretSearchValue, setSiretSearchValue] = useState("");
  
  const form = useForm<StampFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      address: "",
      siret: "",
      vatNumber: "",
      rcsNumber: "",
    },
  });

  const handleSiretSearch = async () => {
    if (!siretSearchValue || siretSearchValue.length !== 14) {
      toast({
        title: "Format SIRET invalide",
        description: "Le SIRET doit comporter exactement 14 chiffres",
        variant: "destructive",
      });
      return;
    }
    
    setIsFetchingSiret(true);
    
    try {
      const companyData = await fetchCompanyBySiret(siretSearchValue);
      
      if (!companyData) {
        toast({
          title: "Entreprise non trouvée",
          description: "Aucune entreprise trouvée avec ce SIRET",
          variant: "destructive",
        });
        return;
      }
      
      // Formatage de l'adresse
      const address = formatCompanyAddress(companyData.address);
      
      // Construction du numéro de TVA s'il est manquant
      let vatNumber = companyData.vat_number || "";
      if (!vatNumber && companyData.siret) {
        const tvaKey = (12 + 3 * (parseInt(companyData.siret.substring(0, 9)) % 97)) % 97;
        vatNumber = `FR${tvaKey.toString().padStart(2, '0')}${companyData.siret.substring(0, 9)}`;
      }
      
      // Mise à jour du formulaire
      form.setValue("name", companyData.name);
      form.setValue("address", address);
      form.setValue("siret", companyData.siret);
      form.setValue("vatNumber", vatNumber);
      form.setValue("rcsNumber", companyData.registration_number || "");
      
      toast({
        title: "Entreprise trouvée",
        description: `Les informations de ${companyData.name} ont été récupérées`,
      });
    } catch (error) {
      console.error("Erreur lors de la recherche SIRET:", error);
      toast({
        title: "Erreur",
        description: "Impossible de récupérer les informations de l'entreprise",
        variant: "destructive",
      });
    } finally {
      setIsFetchingSiret(false);
    }
  };

  const onSubmit = async (values: StampFormValues) => {
    const canUseCredits = useCredits(1);
    
    if (!canUseCredits) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Validation et nettoyage des données
      const cleanedValues = {
        ...values,
        siret: values.siret.trim(),
        vatNumber: values.vatNumber.trim().toUpperCase(),
      };
      
      onCompanyInfo(cleanedValues);
      
      toast({
        title: "Informations validées",
        description: "Les informations de l'entreprise ont été validées pour la création du tampon.",
      });
    } catch (error) {
      console.error("Erreur lors de la soumission:", error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de la validation des informations",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Informations de l'entreprise</CardTitle>
        <CardDescription>
          Entrez les informations de votre entreprise pour générer un tampon
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <FormField
                  control={form.control}
                  name="siret"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SIRET</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="12345678901234" 
                          {...field} 
                          onBlur={(e) => {
                            field.onBlur();
                            setSiretSearchValue(e.target.value);
                          }}
                          onChange={(e) => {
                            field.onChange(e);
                            setSiretSearchValue(e.target.value);
                          }}
                        />
                      </FormControl>
                      <FormDescription>
                        Numéro SIRET de l'entreprise (14 chiffres)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <Button
                type="button"
                variant="secondary"
                onClick={handleSiretSearch}
                disabled={isFetchingSiret || siretSearchValue.length !== 14}
              >
                {isFetchingSiret ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Search className="h-4 w-4 mr-2" />
                )}
                Rechercher
              </Button>
            </div>
            
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nom de l'entreprise</FormLabel>
                  <FormControl>
                    <Input placeholder="Entreprise SARL" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Adresse</FormLabel>
                  <FormControl>
                    <Input placeholder="12 rue de l'exemple, 75000 Paris" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="vatNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Numéro de TVA</FormLabel>
                  <FormControl>
                    <Input placeholder="FR12345678901" {...field} />
                  </FormControl>
                  <FormDescription>
                    Numéro de TVA intracommunautaire
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="rcsNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Numéro RCS (optionnel)</FormLabel>
                  <FormControl>
                    <Input placeholder="RCS Paris B 123 456 789" {...field} />
                  </FormControl>
                  <FormDescription>
                    Numéro d'immatriculation au Registre du Commerce et des Sociétés
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="h-0 overflow-hidden">
              <button type="submit" id="submit-button"></button>
            </div>
          </form>
        </Form>
      </CardContent>
      <CardFooter>
        <Button 
          className="w-full" 
          onClick={() => document.getElementById('submit-button')?.click()}
        >
          Générer le tampon
        </Button>
      </CardFooter>
    </Card>
  );
};

export default StampForm;
