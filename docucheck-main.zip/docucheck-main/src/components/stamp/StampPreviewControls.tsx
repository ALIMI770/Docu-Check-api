
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, ZoomIn, ZoomOut, RotateCw, RotateCcw, Home, Settings, Cog, Download } from "lucide-react";
import { DEFAULT_POSITION } from "@/hooks/use-pdf-processor";
import StampPageSelection from "./StampPageSelection";
import StampTemplateManager from "./StampTemplateManager";
import DocumentConfigManager from "./DocumentConfigManager";
import StampPositionControls from "./StampPositionControls";
import { StampTemplate, DocumentConfig } from "@/hooks/use-pdf-processor";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";

interface StampPreviewControlsProps {
  currentPage: number;
  totalPages: number;
  changePage: (page: number) => void;
  scale: number;
  changeZoom: (scale: number) => void;
  moveStamp: (direction: 'up' | 'down' | 'left' | 'right', amount?: number) => void;
  rotateStamp: (clockwise: boolean) => void;
  rotation: number;
  stampPosition: { x: number; y: number };
  onConfirm: () => void;
  selectedPages: Record<number, boolean>;
  togglePageSelection: (page: number) => void;
  selectAllPages: (selected: boolean) => void;
  templates: StampTemplate[];
  activeTemplate: string | null;
  saveTemplate: (name: string) => string;
  deleteTemplate: (id: string) => void;
  applyTemplate: (id: string) => void;
  resetToDefaultPosition: () => void;
  documentConfigs: DocumentConfig[];
  activeConfig: string | null;
  defaultConfig: string | null;
  saveDocumentConfig: (name: string, description: string) => string;
  deleteDocumentConfig: (id: string) => void;
  applyDocumentConfig: (id: string) => void;
  setDefaultDocumentConfig: (id: string | null) => void;
  updateCurrentPageSettings?: () => void;
  savePageSettings?: (pageNum: number, position: { x: number; y: number }, rotation: number) => void;
  pageSpecificMode?: boolean;
  togglePageSpecificMode?: () => void;
  setExactPosition?: (x: number, y: number) => void;
}

const StampPreviewControls = ({
  currentPage,
  totalPages,
  changePage,
  scale,
  changeZoom,
  moveStamp,
  rotateStamp,
  rotation,
  stampPosition,
  onConfirm,
  selectedPages,
  togglePageSelection,
  selectAllPages,
  templates,
  activeTemplate,
  saveTemplate,
  deleteTemplate,
  applyTemplate,
  resetToDefaultPosition,
  documentConfigs,
  activeConfig,
  defaultConfig,
  saveDocumentConfig,
  deleteDocumentConfig,
  applyDocumentConfig,
  setDefaultDocumentConfig,
  updateCurrentPageSettings,
  savePageSettings,
  pageSpecificMode = false,
  togglePageSpecificMode,
  setExactPosition
}: StampPreviewControlsProps) => {
  const [activeTab, setActiveTab] = useState("position");
  
  const handleSaveTemplate = (name: string) => {
    return saveTemplate(name);
  };

  return (
    <div className="flex flex-col space-y-6 mt-4">
      {totalPages > 1 && (
        <div className="flex justify-between items-center mb-2 bg-white rounded-lg p-3 border shadow-sm">
          <Button 
            variant="outline" 
            size="sm"
            disabled={currentPage === 0}
            onClick={() => changePage(currentPage - 1)}
          >
            Page précédente
          </Button>
          <span className="font-medium">
            Page {currentPage + 1} sur {totalPages}
          </span>
          <Button 
            variant="outline" 
            size="sm"
            disabled={currentPage === totalPages - 1}
            onClick={() => changePage(currentPage + 1)}
          >
            Page suivante
          </Button>
        </div>
      )}
      
      <Tabs defaultValue="position" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3">
          <TabsTrigger value="position">Position</TabsTrigger>
          <TabsTrigger value="pages">Pages</TabsTrigger>
          <TabsTrigger value="templates">Configuration</TabsTrigger>
        </TabsList>
        
        <TabsContent value="position" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <StampPositionControls
              onMove={moveStamp}
              onRotate={rotateStamp}
              onSavePosition={handleSaveTemplate}
              position={stampPosition}
              rotation={rotation}
              currentPage={currentPage}
              forCurrentPageOnly={pageSpecificMode}
              onToggleForCurrentPageOnly={togglePageSpecificMode}
              onSetExactPosition={setExactPosition}
            />
            
            <div className="bg-white p-4 rounded-lg border shadow-sm">
              <div className="space-y-4">
                <div className="flex flex-col space-y-2">
                  <label className="text-sm font-medium text-gray-700">Zoom</label>
                  <Slider
                    value={[scale]}
                    min={0.5}
                    max={2.5}
                    step={0.1}
                    onValueChange={(value) => changeZoom(value[0])}
                  />
                  <div className="flex justify-between text-sm text-gray-500">
                    <span>50%</span>
                    <span>{Math.round(scale * 100)}%</span>
                    <span>250%</span>
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full mt-2" 
                  onClick={resetToDefaultPosition}
                >
                  <Home className="h-4 w-4 mr-2" />
                  Position par défaut
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="pages">
          <StampPageSelection 
            currentPage={currentPage}
            totalPages={totalPages}
            selectedPages={selectedPages}
            togglePageSelection={togglePageSelection}
            selectAllPages={selectAllPages}
          />
        </TabsContent>
        
        <TabsContent value="templates">
          <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
            <DocumentConfigManager 
              configs={documentConfigs}
              activeConfig={activeConfig}
              saveConfig={saveDocumentConfig}
              deleteConfig={deleteDocumentConfig}
              applyConfig={applyDocumentConfig}
              setDefaultConfig={setDefaultDocumentConfig}
              defaultConfig={defaultConfig}
            />
          </div>
        </TabsContent>
      </Tabs>
      
      <Button 
        onClick={onConfirm}
        className="w-full"
      >
        <Download className="h-4 w-4 mr-2" />
        Appliquer le tampon et télécharger
      </Button>
    </div>
  );
};

export default StampPreviewControls;
