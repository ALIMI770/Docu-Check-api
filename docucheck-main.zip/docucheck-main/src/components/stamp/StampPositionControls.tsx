
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, RotateCw, RotateCcw, Save, Move } from "lucide-react";
import { useState, useEffect } from "react";

interface StampPositionControlsProps {
  onMove: (direction: 'up' | 'down' | 'left' | 'right', amount?: number) => void;
  onRotate: (clockwise: boolean) => void;
  onSavePosition: (name: string) => void;
  position: { x: number; y: number };
  rotation: number;
  currentPage: number;
  forCurrentPageOnly?: boolean;
  onToggleForCurrentPageOnly?: () => void;
  onSetExactPosition?: (x: number, y: number) => void;
}

const StampPositionControls = ({
  onMove,
  onRotate,
  onSavePosition,
  position,
  rotation,
  currentPage,
  forCurrentPageOnly = false,
  onToggleForCurrentPageOnly,
  onSetExactPosition
}: StampPositionControlsProps) => {
  const [customAmount, setCustomAmount] = useState("5");
  const [templateName, setTemplateName] = useState("");
  const [showSave, setShowSave] = useState(false);
  const [posX, setPosX] = useState<string>(Math.round(position.x).toString());
  const [posY, setPosY] = useState<string>(Math.round(position.y).toString());

  // Mettre à jour les champs X/Y lorsque la position change
  useEffect(() => {
    setPosX(Math.round(position.x).toString());
    setPosY(Math.round(position.y).toString());
  }, [position.x, position.y]);

  const handleCustomMove = (direction: 'up' | 'down' | 'left' | 'right') => {
    const amount = parseInt(customAmount);
    if (!isNaN(amount)) {
      onMove(direction, amount);
    }
  };

  const handleSetExactPosition = () => {
    if (onSetExactPosition) {
      const x = parseInt(posX);
      const y = parseInt(posY);
      if (!isNaN(x) && !isNaN(y)) {
        onSetExactPosition(x, y);
      }
    }
  };

  return (
    <div className="bg-white p-4 rounded-lg border shadow-sm space-y-4">
      <div className="space-y-4">
        <div className="grid grid-cols-3 gap-2">
          <div />
          <Button variant="outline" size="sm" onClick={() => handleCustomMove('up')}>
            <ArrowUp className="h-4 w-4" />
          </Button>
          <div />
          <Button variant="outline" size="sm" onClick={() => handleCustomMove('left')}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleCustomMove('down')}>
            <ArrowDown className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleCustomMove('right')}>
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex items-center space-x-2">
          <Input
            type="number"
            value={customAmount}
            onChange={(e) => setCustomAmount(e.target.value)}
            className="w-20"
            min="1"
            max="100"
          />
          <span className="text-sm text-gray-500">pixels par déplacement</span>
        </div>

        <div className="flex justify-between items-center">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onRotate(false)}
            className="w-24"
          >
            <RotateCcw className="h-4 w-4 mr-1" /> -5°
          </Button>
          <span className="text-sm font-medium">{rotation}°</span>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onRotate(true)}
            className="w-24"
          >
            <RotateCw className="h-4 w-4 mr-1" /> +5°
          </Button>
        </div>

        <div className="border-t pt-4">
          <div className="grid grid-cols-2 gap-2 text-sm mb-3">
            <div className="flex items-center space-x-2">
              <span className="font-medium w-8">X:</span>
              <Input
                type="number"
                value={posX}
                onChange={(e) => setPosX(e.target.value)}
                onBlur={handleSetExactPosition}
                className="w-full"
              />
            </div>
            <div className="flex items-center space-x-2">
              <span className="font-medium w-8">Y:</span>
              <Input
                type="number"
                value={posY}
                onChange={(e) => setPosY(e.target.value)}
                onBlur={handleSetExactPosition}
                className="w-full"
              />
            </div>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full"
            onClick={handleSetExactPosition}
          >
            Appliquer les coordonnées exactes
          </Button>
        </div>
        
        {onToggleForCurrentPageOnly && (
          <div className="flex items-center justify-between border-t pt-4">
            <div className="flex items-center">
              <Move className="h-4 w-4 mr-2 text-blue-500" />
              <span className="text-sm font-medium">Position page {currentPage + 1}</span>
            </div>
            <Button
              variant={forCurrentPageOnly ? "default" : "outline"}
              size="sm"
              onClick={onToggleForCurrentPageOnly}
            >
              {forCurrentPageOnly ? "Page unique" : "Toutes les pages"}
            </Button>
          </div>
        )}

        {showSave ? (
          <div className="flex items-center space-x-2">
            <Input
              placeholder="Nom du modèle"
              value={templateName}
              onChange={(e) => setTemplateName(e.target.value)}
              className="flex-1"
            />
            <Button
              size="sm"
              onClick={() => {
                if (templateName.trim()) {
                  onSavePosition(templateName.trim());
                  setTemplateName("");
                  setShowSave(false);
                }
              }}
              disabled={!templateName.trim()}
            >
              <Save className="h-4 w-4 mr-1" />
              Enregistrer
            </Button>
          </div>
        ) : (
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => setShowSave(true)}
          >
            <Save className="h-4 w-4 mr-1" />
            Enregistrer la position
          </Button>
        )}
      </div>
    </div>
  );
};

export default StampPositionControls;
