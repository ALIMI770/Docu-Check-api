
import { useEffect, useRef, useState, useCallback } from "react";
import * as pdfjsLib from 'pdfjs-dist';
import { STAMP_DIMENSIONS } from "@/hooks/use-pdf-processor";

interface StampPdfCanvasProps {
  pdfDoc: pdfjsLib.PDFDocumentProxy | null;
  currentPage: number;
  scale: number;
  pageWidth: number;
  pageHeight: number;
  stampPosition: { x: number; y: number };
  rotation: number;
  stampWidth: number;
  stampHeight: number;
  stampImage: string | null;
  canvasRef?: React.RefObject<HTMLCanvasElement>;
}

const StampPdfCanvas = ({
  pdfDoc,
  currentPage,
  scale,
  pageWidth,
  pageHeight,
  stampPosition,
  rotation,
  stampWidth,
  stampHeight,
  stampImage,
  canvasRef: externalCanvasRef
}: StampPdfCanvasProps) => {
  const internalCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isRendering, setIsRendering] = useState(false);
  const isMountedRef = useRef(true);
  const renderTaskRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const stampImageObjRef = useRef<HTMLImageElement | null>(null);
  
  // Use either the external canvas ref or the internal one
  const canvasRefToUse = externalCanvasRef || internalCanvasRef;

  // Preload stamp image to avoid flickering
  useEffect(() => {
    if (!stampImage) return;
    
    const img = new Image();
    img.onload = () => {
      stampImageObjRef.current = img;
    };
    
    if (stampImage.startsWith('data:')) {
      img.crossOrigin = '';
    } else {
      img.crossOrigin = "anonymous";
    }
    
    img.src = stampImage;
    
    return () => {
      stampImageObjRef.current = null;
    };
  }, [stampImage]);

  // Set up mount/unmount tracking
  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
      // Cancel any pending render task
      if (renderTaskRef.current) {
        renderTaskRef.current.cancel();
        renderTaskRef.current = null;
      }
    };
  }, []);

  // Effect to ensure A4 proportional display
  useEffect(() => {
    const adjustCanvasSize = () => {
      if (!containerRef.current || !canvasRefToUse.current) return;
      
      const containerWidth = containerRef.current.clientWidth;
      const A4_RATIO = 297 / 210; // A4 ratio (mm)
      const MAX_HEIGHT = window.innerHeight * 0.7; // 70% of viewport height
      
      let displayWidth = containerWidth;
      let displayHeight = containerWidth * A4_RATIO;
      
      // If height exceeds max, scale down proportionally
      if (displayHeight > MAX_HEIGHT) {
        displayHeight = MAX_HEIGHT;
        displayWidth = MAX_HEIGHT / A4_RATIO;
      }
      
      // Set display size (CSS pixels) - this controls the size on screen
      canvasRefToUse.current.style.width = `${displayWidth}px`;
      canvasRefToUse.current.style.height = `${displayHeight}px`;
    };

    adjustCanvasSize();
    window.addEventListener('resize', adjustCanvasSize);
    return () => window.removeEventListener('resize', adjustCanvasSize);
  }, [canvasRefToUse]);

  // Render the PDF page and stamp with proper debouncing to avoid flickering
  const renderPreview = useCallback(async () => {
    if (!canvasRefToUse.current || !pdfDoc || !isMountedRef.current) return;
    
    try {
      if (isMountedRef.current) setIsRendering(true);
      
      // Cancel any ongoing rendering task
      if (renderTaskRef.current) {
        renderTaskRef.current.cancel();
        renderTaskRef.current = null;
      }
      
      const page = await pdfDoc.getPage(currentPage + 1);
      
      if (!isMountedRef.current) return;
      
      const canvas = canvasRefToUse.current;
      const context = canvas?.getContext('2d');
      if (!canvas || !context) {
        if (isMountedRef.current) setIsRendering(false);
        return;
      }
      
      // Calculate viewport to fit A4 proportions with high resolution
      const viewport = page.getViewport({ scale: scale * 2 }); // Increase resolution for sharper rendering
      
      // Set canvas size for high resolution (actual pixels for rendering)
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      
      // Clear previous content
      context.clearRect(0, 0, canvas.width, canvas.height);
      
      // Render PDF page
      const renderTask = page.render({
        canvasContext: context,
        viewport: viewport
      });
      
      renderTaskRef.current = renderTask;
      
      await renderTask.promise;
      
      if (!isMountedRef.current) return;
      renderTaskRef.current = null;
      
      // Draw stamp if available
      if (stampImage) {
        let img = stampImageObjRef.current;
        
        if (!img) {
          img = new Image();
          if (stampImage.startsWith('data:')) {
            img.crossOrigin = '';
          } else {
            img.crossOrigin = "anonymous";
          }
          
          await new Promise((resolve, reject) => {
            img.onload = resolve;
            img.onerror = reject;
            img.src = stampImage;
          });
        }
        
        if (!isMountedRef.current) return;
        
        const scaleX = viewport.width / pageWidth;
        const scaleY = viewport.height / pageHeight;
        
        const x = stampPosition.x * scaleX;
        const y = stampPosition.y * scaleY;
        const width = STAMP_DIMENSIONS.width * scaleX;
        const height = STAMP_DIMENSIONS.height * scaleY;
        
        // Draw stamp with anti-aliasing
        context.save();
        context.translate(x + width/2, y + height/2);
        context.rotate(rotation * Math.PI / 180);
        context.imageSmoothingEnabled = true;
        context.imageSmoothingQuality = 'high';
        context.globalAlpha = 0.9;
        context.drawImage(img, -width/2, -height/2, width, height);
        context.restore();
      }
      
      if (isMountedRef.current) {
        setIsRendering(false);
      }
    } catch (error) {
      console.error("Error rendering preview:", error);
      if (isMountedRef.current) {
        setIsRendering(false);
      }
    }
  }, [pdfDoc, currentPage, scale, pageWidth, pageHeight, stampPosition, rotation, stampWidth, stampHeight, stampImage, canvasRefToUse]);

  // Effect to trigger rendering when dependencies change
  useEffect(() => {
    const renderTimer = setTimeout(renderPreview, 50); // Small delay to avoid rapid sequential renders
    return () => clearTimeout(renderTimer);
  }, [renderPreview]);

  return (
    <div 
      ref={containerRef}
      className="relative p-4 bg-white border rounded-lg shadow-sm"
    >
      <div className="flex justify-center items-center min-h-[500px] bg-gray-50 rounded">
        <canvas 
          ref={canvasRefToUse} 
          className="max-w-full h-auto object-contain rounded shadow-md bg-white"
        />
        
        {isRendering && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/30 pointer-events-none">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StampPdfCanvas;
