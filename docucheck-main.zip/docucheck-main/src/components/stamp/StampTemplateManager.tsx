
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Save, Trash2, Check, BookmarkPlus } from "lucide-react";
import { StampTemplate } from "@/hooks/use-pdf-processor";

interface StampTemplateManagerProps {
  templates: StampTemplate[];
  activeTemplate: string | null;
  saveTemplate: (name: string) => string;
  deleteTemplate: (id: string) => void;
  applyTemplate: (id: string) => void;
}

const StampTemplateManager = ({
  templates,
  activeTemplate,
  saveTemplate,
  deleteTemplate,
  applyTemplate
}: StampTemplateManagerProps) => {
  const [newTemplateName, setNewTemplateName] = useState("");
  const [isCreating, setIsCreating] = useState(false);
  
  const handleSaveTemplate = () => {
    if (newTemplateName.trim()) {
      saveTemplate(newTemplateName.trim());
      setNewTemplateName("");
      setIsCreating(false);
    }
  };
  
  return (
    <div className="bg-white p-4 rounded-lg border shadow-sm">
      <p className="text-sm font-medium text-gray-700 mb-3">Modèles de positionnement</p>
      
      {isCreating ? (
        <div className="flex gap-2 mb-3">
          <Input 
            size={1}
            placeholder="Nom du modèle"
            value={newTemplateName}
            onChange={(e) => setNewTemplateName(e.target.value)}
            className="text-sm"
          />
          <Button size="sm" onClick={handleSaveTemplate} disabled={!newTemplateName.trim()}>
            <Save className="h-4 w-4 mr-1" />
            Enregistrer
          </Button>
          <Button size="sm" variant="outline" onClick={() => setIsCreating(false)}>
            Annuler
          </Button>
        </div>
      ) : (
        <Button 
          size="sm" 
          variant="outline" 
          className="mb-3 w-full"
          onClick={() => setIsCreating(true)}
        >
          <BookmarkPlus className="h-4 w-4 mr-1" />
          Enregistrer la position actuelle
        </Button>
      )}
      
      {templates.length > 0 ? (
        <div className="space-y-2 max-h-40 overflow-y-auto border rounded bg-gray-50 p-2">
          {templates.map(template => (
            <div 
              key={template.id}
              className={`flex justify-between items-center p-2 rounded ${activeTemplate === template.id ? 'bg-blue-50 border border-blue-200' : 'border bg-white'}`}
            >
              <div className="flex items-center">
                {activeTemplate === template.id && (
                  <Check className="h-4 w-4 text-blue-500 mr-1" />
                )}
                <span className="text-sm">{template.name}</span>
              </div>
              <div className="flex gap-1">
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={() => applyTemplate(template.id)}
                  className="h-7 px-2"
                  disabled={activeTemplate === template.id}
                >
                  Appliquer
                </Button>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={() => deleteTemplate(template.id)}
                  className="h-7 px-2 text-red-500 hover:text-red-700 hover:bg-red-50"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-sm text-gray-500 text-center border rounded p-3 bg-gray-50">
          Aucun modèle enregistré
        </div>
      )}
    </div>
  );
};

export default StampTemplateManager;
