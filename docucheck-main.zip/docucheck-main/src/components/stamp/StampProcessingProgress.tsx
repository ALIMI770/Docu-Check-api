
interface StampProcessingProgressProps {
  progress: number;
}

const StampProcessingProgress = ({ progress }: StampProcessingProgressProps) => {
  if (progress <= 0) {
    return null;
  }

  return (
    <div className="mt-4">
      <div className="flex justify-between items-center mb-1">
        <span className="text-sm text-gray-500">Traitement en cours...</span>
        <span className="text-sm font-medium">{progress}%</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2.5">
        <div 
          className="bg-blue-600 h-2.5 rounded-full" 
          style={{ width: `${progress}%` }}
        ></div>
      </div>
    </div>
  );
};

export default StampProcessingProgress;
