
import { useEffect, useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CompanyInfo {
  name: string;
  address: string;
  siret: string;
  vatNumber: string;
  rcsNumber?: string;
}

interface StampPreviewProps {
  companyInfo: CompanyInfo;
  onStampImage: (image: string) => void;
}

const StampPreview = ({ companyInfo, onStampImage }: StampPreviewProps) => {
  const { toast } = useToast();
  const [stampImage, setStampImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isMounted = useRef(true);
  const downloadLinkRef = useRef<HTMLAnchorElement | null>(null);

  // Dimensions du tampon en mm et conversion en pixels (1mm = ~3.8 pixels à 96 DPI)
  const stampWidth = 75 * 3.8; // 75mm en pixels
  const stampHeight = 38 * 3.8; // 38mm en pixels

  useEffect(() => {
    // Set the mounted ref
    isMounted.current = true;
    
    // Create hidden download link
    const downloadLink = document.createElement('a');
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLinkRef.current = downloadLink;
    
    // Clean up function
    return () => {
      isMounted.current = false;
      
      // Remove download link
      if (downloadLinkRef.current && document.body.contains(downloadLinkRef.current)) {
        try {
          document.body.removeChild(downloadLinkRef.current);
        } catch (e) {
          console.error("Error removing download link:", e);
        }
      }
    };
  }, []);

  // Generate stamp when component mounts or company info changes
  useEffect(() => {
    if (companyInfo && isMounted.current) {
      generateStamp();
    }
  }, [companyInfo]);

  // Function to split address into two lines
  const splitAddress = (address: string): [string, string] => {
    // Try to split at a common delimiter that might separate street address from city info
    const commonDelimiters = [', ', ' - '];
    
    for (const delimiter of commonDelimiters) {
      if (address.includes(delimiter)) {
        const parts = address.split(delimiter);
        // Get the last part as the city part
        const cityPart = parts.pop() || '';
        // Join the rest as the street part
        const streetPart = parts.join(delimiter);
        return [streetPart, cityPart];
      }
    }
    
    // If no common delimiter found, try to find postal code pattern
    const postalCodeMatch = address.match(/\b\d{5}\b/);
    if (postalCodeMatch) {
      // Find the position of the postal code
      const index = address.indexOf(postalCodeMatch[0]);
      // Split the address at a point before the postal code
      // Look for space or comma before the postal code
      let splitIndex = index;
      for (let i = index - 1; i >= 0; i--) {
        if (address[i] === ' ' || address[i] === ',') {
          splitIndex = i;
          break;
        }
      }
      
      const streetPart = address.substring(0, splitIndex).trim();
      const cityPart = address.substring(splitIndex).trim();
      return [streetPart, cityPart];
    }
    
    // If no pattern is found, just return the full address and an empty second line
    return [address, ''];
  };

  // Fonction pour générer le tampon
  const generateStamp = () => {
    if (!isMounted.current) return;
    
    try {
      setIsGenerating(true);
      
      // Create canvas element dynamically
      if (!canvasRef.current) {
        canvasRef.current = document.createElement("canvas");
      }
      
      const canvas = canvasRef.current;
      canvas.width = stampWidth;
      canvas.height = stampHeight;
      const ctx = canvas.getContext("2d");
      
      if (ctx) {
        // Effacer le canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Fond transparent (pas de fond ni cercle comme demandé)
        
        // Configuration du texte
        ctx.textAlign = "center";
        ctx.fillStyle = "#000000"; // Couleur noire pour le texte
        
        // Positionnement vertical des éléments
        const maxLines = 8; // 8 lignes maximum comme demandé
        const lineHeight = stampHeight / maxLines;
        
        // Nom de l'entreprise (plus grand)
        ctx.font = "bold 16px Arial";
        ctx.fillText(companyInfo.name.toUpperCase(), stampWidth/2, lineHeight);
        
        // Adresse divisée en deux lignes
        const [addressLine1, addressLine2] = splitAddress(companyInfo.address);
        ctx.font = "12px Arial";
        ctx.fillText(addressLine1, stampWidth/2, lineHeight * 2);
        
        // Deuxième ligne d'adresse (code postal et ville)
        if (addressLine2) {
          ctx.fillText(addressLine2, stampWidth/2, lineHeight * 3);
          
          // Décaler les lignes suivantes
          ctx.font = "11px Arial";
          ctx.fillText(`SIRET: ${companyInfo.siret}`, stampWidth/2, lineHeight * 4);
          ctx.fillText(`TVA: ${companyInfo.vatNumber}`, stampWidth/2, lineHeight * 5);
          
          // Numéro RCS si disponible
          if (companyInfo.rcsNumber) {
            ctx.fillText(`RCS: ${companyInfo.rcsNumber}`, stampWidth/2, lineHeight * 6);
          }
        } else {
          // Si pas de deuxième ligne d'adresse, ne pas décaler
          ctx.font = "11px Arial";
          ctx.fillText(`SIRET: ${companyInfo.siret}`, stampWidth/2, lineHeight * 3);
          ctx.fillText(`TVA: ${companyInfo.vatNumber}`, stampWidth/2, lineHeight * 4);
          
          // Numéro RCS si disponible
          if (companyInfo.rcsNumber) {
            ctx.fillText(`RCS: ${companyInfo.rcsNumber}`, stampWidth/2, lineHeight * 5);
          }
        }
        
        // Check if component is still mounted before updating state
        if (isMounted.current) {
          // Conversion du canvas en URL de données
          const dataUrl = canvas.toDataURL("image/png");
          setStampImage(dataUrl);
          onStampImage(dataUrl);
          
          toast({
            title: "Tampon généré",
            description: "Le tampon a été généré avec succès",
          });
        }
      }
    } catch (error) {
      console.error("Erreur lors de la génération du tampon:", error);
      if (isMounted.current) {
        toast({
          title: "Erreur",
          description: "Impossible de générer le tampon",
          variant: "destructive",
        });
      }
    } finally {
      if (isMounted.current) {
        setIsGenerating(false);
      }
    }
  };

  // Fonction de téléchargement du tampon
  const downloadStamp = () => {
    if (!stampImage || !isMounted.current) return;
    
    try {
      // Use our persistent downloadLinkRef instead of creating temp links
      if (downloadLinkRef.current) {
        downloadLinkRef.current.href = stampImage;
        downloadLinkRef.current.download = `tampon-${companyInfo.name.replace(/\s+/g, '-').toLowerCase()}.png`;
        downloadLinkRef.current.click();
        
        toast({
          title: "Téléchargement",
          description: "Téléchargement du tampon en cours",
        });
      }
    } catch (error) {
      console.error("Erreur lors du téléchargement:", error);
      if (isMounted.current) {
        toast({
          title: "Erreur",
          description: "Impossible de télécharger le tampon",
          variant: "destructive",
        });
      }
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Tampon généré</CardTitle>
        <CardDescription>
          Téléchargez votre tampon au format PNG (75x38mm)
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col items-center">
        {isGenerating ? (
          <div className="flex items-center justify-center h-40 w-full">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : stampImage ? (
          <div className="bg-white p-4 rounded border mb-4">
            <img 
              src={stampImage} 
              alt="Tampon d'entreprise" 
              className="max-w-full h-auto"
            />
          </div>
        ) : null}
        
        <div className="w-full bg-gray-50 p-4 rounded text-sm mb-4">
          <h3 className="font-semibold mb-2">Informations de l'entreprise</h3>
          <p><span className="font-medium">Nom:</span> {companyInfo.name}</p>
          <p><span className="font-medium">Adresse:</span> {companyInfo.address}</p>
          <p><span className="font-medium">SIRET:</span> {companyInfo.siret}</p>
          <p><span className="font-medium">TVA:</span> {companyInfo.vatNumber}</p>
          {companyInfo.rcsNumber && (
            <p><span className="font-medium">RCS:</span> {companyInfo.rcsNumber}</p>
          )}
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          variant="outline" 
          className="w-full" 
          onClick={downloadStamp}
          disabled={!stampImage || isGenerating}
        >
          <Download className="h-4 w-4 mr-2" />
          Télécharger
        </Button>
      </CardFooter>
    </Card>
  );
};

export default StampPreview;
