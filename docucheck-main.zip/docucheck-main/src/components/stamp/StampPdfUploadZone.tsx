
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { FileUp, Upload } from "lucide-react";
import { DEFAULT_POSITION } from "@/hooks/use-pdf-processor";

interface StampPdfUploadZoneProps {
  pdfFile: File | null;
  isUploaded: boolean;
  fileInputRef: React.RefObject<HTMLInputElement>;
  onFileChange: (file: File | null) => void;
  onDrop: (e: React.DragEvent<HTMLDivElement>) => void;
  onReset: () => void;
  onPreview: () => void;
  isProcessing: boolean;
}

const StampPdfUploadZone = ({
  pdfFile,
  isUploaded,
  fileInputRef,
  onFileChange,
  onDrop,
  onReset,
  onPreview,
  isProcessing
}: StampPdfUploadZoneProps) => {
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onDrop(e);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileChange(e.target.files[0]);
    }
  };

  if (!isUploaded) {
    return (
      <div
        className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:bg-gray-50 transition cursor-pointer"
        onClick={() => fileInputRef.current?.click()}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
      >
        <FileUp className="h-10 w-10 text-gray-400 mx-auto mb-3" />
        <p className="text-sm text-gray-600 mb-1">Glissez-déposez un fichier PDF ici</p>
        <p className="text-xs text-gray-500 mb-4">ou cliquez pour sélectionner un fichier</p>
        <Button variant="outline" size="sm">
          <Upload className="h-4 w-4 mr-2" />
          Télécharger un PDF
        </Button>
        <input
          type="file"
          accept="application/pdf"
          className="hidden"
          ref={fileInputRef}
          onChange={handleFileChange}
        />
      </div>
    );
  }

  return (
    <div className="p-4 border rounded bg-gray-50">
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="font-medium">{pdfFile?.name}</p>
          <p className="text-sm text-gray-500">
            {pdfFile?.size ? `${(pdfFile.size / 1024 / 1024).toFixed(2)} MB` : ""}
          </p>
        </div>
        <Button variant="ghost" size="sm" onClick={onReset}>
          Changer
        </Button>
      </div>
      
      <Alert className="mb-4">
        <AlertTitle>Position manuelle du tampon</AlertTitle>
        <AlertDescription>
          Le tampon sera positionné selon vos réglages. Cliquez sur le bouton ci-dessous pour prévisualiser et ajuster sa position.
        </AlertDescription>
      </Alert>
      
      <Button 
        variant="outline" 
        className="w-full" 
        onClick={onPreview}
        disabled={isProcessing}
      >
        Prévisualiser et ajuster le tampon
      </Button>
    </div>
  );
};

export default StampPdfUploadZone;
