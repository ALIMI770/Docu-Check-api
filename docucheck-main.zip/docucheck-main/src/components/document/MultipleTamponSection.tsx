/* eslint-disable @typescript-eslint/no-explicit-any */

import React from 'react';

interface MultipleTamponSectionProps {
  tampons: any[];
}

/**
 * Composant pour afficher plusieurs tampons détectés (incitation financière)
 */
export const MultipleTamponSection: React.FC<MultipleTamponSectionProps> = ({ tampons }) => {
  if (!tampons || tampons.length === 0) return null;

  return (
    <div className="mb-4">
      <h5 className="font-medium mb-2">Tampons détectés</h5>
      <div className="space-y-3">
        {tampons.map((tampon: any, idx: number) => (
          <div key={idx} className="border rounded p-3 bg-gray-50">
            <div className="text-sm font-medium mb-1">Tampon {idx + 1}</div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
              {tampon.nom && (
                <div>
                  <span className="text-gray-500">Nom:</span> {tampon.nom}
                </div>
              )}
              {tampon.adresse && (
                <div>
                  <span className="text-gray-500">Adresse:</span> {tampon.adresse}
                </div>
              )}
              {tampon.siret && (
                <div>
                  <span className="text-gray-500">SIRET:</span> {tampon.siret}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MultipleTamponSection;
