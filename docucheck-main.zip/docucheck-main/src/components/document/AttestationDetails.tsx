import { Separator } from "@/components/ui/separator";
import { DocumentAnalysis, DocumentData } from "@/types/attestation";

interface ManuscritItemProps {
  label: string;
  present: boolean;
  score?: number;
  textPresent: string;
  textAbsent: string;
}

const ManuscritItem = ({ label, present, score, textPresent, textAbsent }: ManuscritItemProps) => (
  <div>
    <span className="font-medium">{label}</span>{" "}
    <span className={present ? "text-green-600" : "text-red-600"}>
      {present ? textPresent : textAbsent}
    </span>
    {score !== undefined && (
      <span className="text-xs text-gray-500 ml-1">
        ({score.toFixed(0)}% confiance)
      </span>
    )}
  </div>
);

interface AttestationDetailsProps {
  data: DocumentAnalysis;
  documents: DocumentData[];
}

const AttestationDetails = ({ data, documents }: AttestationDetailsProps) => (
  <>
    {data.is_attestation_cee && (
      <>
        <Separator className="my-4" />
        <div className="bg-blue-50 p-4 rounded-md">
          <h5 className="font-medium text-blue-800 mb-2">Certificat d'Économies d'Énergie / Attestation sur l'honneur</h5>
          {data.amount_ttc && Number(data.amount_ttc) > 0 && (
            <div className="mb-3 p-2 bg-white rounded border border-blue-200">
              <span className="font-medium text-sm">Montant de la prime CEE : </span>
              <span className="text-blue-700 font-semibold">{data.amount_ttc} €</span>
            </div>
          )}
          <div className="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-3 gap-4">
            {/* PARTIE A */}
            <div className={`p-3 border rounded-md ${data.attestation_parts?.part_a_present ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
              <h6 className="font-medium mb-3">Partie A - Informations générales et engagement {data.attestation_parts?.part_a_present ? '✓' : '✗'}</h6>
              {data.attestation_parts?.part_a_present && data.attestation_parts?.part_a_dates && 
                Object.values(data.attestation_parts.part_a_dates).some(v => !!v) ? (
                  <div className="text-sm">
                    <p className="text-gray-600">Dates identifiées :</p>
                    <ul className="list-disc pl-4">
                      {Object.entries(data.attestation_parts.part_a_dates)
                        .filter(([_, value]) => !!value)
                        .map(([label, value], i) => (
                          <li key={i}>
                            <span className="font-medium capitalize">{label} : </span>{String(value)}
                          </li>
                        ))}
                    </ul>
                  </div>
                ) : (
                  <p className="text-sm text-gray-500">Aucune information détectée</p>
              )}
            </div>
            
            {/* PARTIE B */}
            <div className={`p-3 border rounded-md ${data.attestation_parts?.part_b_present ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
              <h6 className="font-medium mb-3">Partie B - Bénéficiaire de l'opération {data.attestation_parts?.part_b_present ? '✓' : '✗'}</h6>
              {data.attestation_parts?.part_b_present ? (
                <div className="text-sm space-y-2">
                  {(() => {
                    // Cherche le document courant dans la liste des documents
                    const doc = documents.find(d =>
                      d.pages.some(p => p.analysis.is_attestation_cee)
                    );
                    if (!doc) return null;
                    // Cherche toutes les pages avec part_b_present
                    const pagesB = doc.pages.filter(p => p.analysis.attestation_parts?.part_b_present);
                    
                    const pageWithStamp = pagesB.find(p => p.analysis.tampon_present);
                    const pageWithSignature = pagesB.find(p => p.analysis.attestation_parts?.part_b_signature_manuscrite);
                    const infos = pageWithStamp?.analysis.infos_tampon;
                    return (
                      <>
                        <div>
                          <ManuscritItem 
                            label="Signature :" 
                            present={data.attestation_parts?.part_b_signature_manuscrite || false}
                            score={pageWithSignature?.analysis.fiabilite_manuscrits?.signature || undefined}
                            textPresent='Présente'
                            textAbsent='Non détectée'
                          />
                        </div>
                        {/* Date manuscrite Partie B */}
                        {data.attestation_parts?.part_b_date_manuscrite && (
                          <div>
                            <span className="font-medium">Date manuscrite :</span>{" "}
                            {data.attestation_parts.part_b_date_manuscrite}
                          </div>
                        )}
                        <div className="mt-2">
                          <div>
                            <ManuscritItem 
                              label="Tampon :" 
                              present={pageWithStamp?.analysis.tampon_present || false}
                              score={pageWithStamp?.analysis.fiabilite_manuscrits.tampon || undefined}
                              textPresent='Présent'
                              textAbsent='Non détecté'
                            />
                          </div>
                          {pageWithStamp?.analysis.tampon_present && infos && (
                            <div className="ml-4 text-xs text-gray-700 space-y-1">
                              {infos.nom && <div><span className="font-medium">Nom :</span> {infos.nom}</div>}
                              {infos.adresse && <div><span className="font-medium">Adresse :</span> {infos.adresse}</div>}
                              {infos.siret && <div><span className="font-medium">SIRET :</span> {infos.siret}</div>}
                            </div>
                          )}
                        </div>
                      </>
                    );
                  })()}
                  {data.attestation_parts?.part_b_company_info && (
                    <div className="mt-2">
                      <div>
                        <span className="font-medium">Nom signataire :</span>{" "}
                        {data.attestation_parts.part_b_company_info.nom_signataire ? (
                          data.attestation_parts.part_b_company_info.nom_signataire
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                      <div>
                        <span className="font-medium">Prénom signataire :</span>{" "}
                        {data.attestation_parts.part_b_company_info.prenom_signataire ? (
                          data.attestation_parts.part_b_company_info.prenom_signataire
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                      <div>
                        <span className="font-medium">Fonction :</span>{" "}
                        {data.attestation_parts.part_b_company_info.fonction_signataire ? (
                          data.attestation_parts.part_b_company_info.fonction_signataire
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                      <div>
                        <span className="font-medium">Raison sociale :</span>{" "}
                        {data.attestation_parts.part_b_company_info.raison_sociale ? (
                          data.attestation_parts.part_b_company_info.raison_sociale
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                      <div>
                        <span className="font-medium">SIREN :</span>{" "}
                        {data.attestation_parts.part_b_company_info.siren ? (
                          data.attestation_parts.part_b_company_info.siren
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                      <div>
                        <span className="font-medium">Adresse :</span>{" "}
                        {data.attestation_parts.part_b_company_info.adresse ? (
                          data.attestation_parts.part_b_company_info.adresse
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-sm text-gray-500">Aucune information détectée</p>
              )}
            </div>

            {/* PARTIE C */}
            <div className={`p-3 border rounded-md ${data.attestation_parts?.part_c_present ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
              <h6 className="font-medium mb-3">Partie C - Professionnel {data.attestation_parts?.part_c_present ? '✓' : '✗'}</h6>
              {data.attestation_parts?.part_c_present ? (
                <div className="text-sm space-y-2">
                  {(() => {
                    const doc = documents.find(d =>
                      d.pages.some(p => p.analysis.is_attestation_cee)
                    );
                    if (!doc) return null;
                    const pagesC = doc.pages.filter(p => p.analysis.attestation_parts?.part_c_present);
                    const pageWithStamp = pagesC.find(p => p.analysis.tampon_present);
                    const pageWithSignature = pagesC.find(p => p.analysis.attestation_parts?.part_c_signature_manuscrite);
                    const infos = pageWithStamp?.analysis.infos_tampon;
                    return (
                      <>
                        <div>
                          <ManuscritItem 
                            label="Signature :" 
                            present={data.attestation_parts?.part_c_signature_manuscrite || false}
                            score={pageWithSignature?.analysis.fiabilite_manuscrits?.signature || undefined}
                            textPresent='Présente'
                            textAbsent='Non détectée'
                          />
                        </div>
                        {/* Date manuscrite Partie C */}
                        {data.attestation_parts?.part_c_date_manuscrite && (
                          <div>
                            <span className="font-medium">Date manuscrite :</span>{" "}
                            {data.attestation_parts.part_c_date_manuscrite}
                          </div>
                        )}
                        <div className="mt-2">
                          <div>
                            <ManuscritItem 
                              label="Tampon :" 
                              present={pageWithStamp?.analysis.tampon_present || false}
                              score={pageWithStamp?.analysis.fiabilite_manuscrits.tampon || undefined}
                              textPresent='Présent'
                              textAbsent='Non détecté'
                            />
                          </div>
                          {pageWithStamp?.analysis.tampon_present && infos && (
                            <div className="ml-4 text-xs text-gray-700 space-y-1">
                              {infos.nom && <div><span className="font-medium">Nom :</span> {infos.nom}</div>}
                              {infos.adresse && <div><span className="font-medium">Adresse :</span> {infos.adresse}</div>}
                              {infos.siret && <div><span className="font-medium">SIRET :</span> {infos.siret}</div>}
                            </div>
                          )}
                        </div>
                      </>
                    );
                  })()}
                  {data.attestation_parts?.part_c_company_info && (
                    <div className="mt-2">
                      <div>
                        <span className="font-medium">Nom signataire :</span>{" "}
                        {data.attestation_parts.part_c_company_info.nom_signataire ? (
                          data.attestation_parts.part_c_company_info.nom_signataire
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                      <div>
                        <span className="font-medium">Prénom signataire :</span>{" "}
                        {data.attestation_parts.part_c_company_info.prenom_signataire ? (
                          data.attestation_parts.part_c_company_info.prenom_signataire
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                      <div>
                        <span className="font-medium">Fonction :</span>{" "}
                        {data.attestation_parts.part_c_company_info.fonction_signataire ? (
                          data.attestation_parts.part_c_company_info.fonction_signataire
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                      <div>
                        <span className="font-medium">Raison sociale :</span>{" "}
                        {data.attestation_parts.part_c_company_info.raison_sociale ? (
                          data.attestation_parts.part_c_company_info.raison_sociale
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                      <div>
                        <span className="font-medium">SIRET :</span>{" "}
                        {data.attestation_parts.part_c_company_info.siret ? (
                          data.attestation_parts.part_c_company_info.siret
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                      <div>
                        <span className="font-medium">Adresse :</span>{" "}
                        {data.attestation_parts.part_c_company_info.adresse ? (
                          data.attestation_parts.part_c_company_info.adresse
                        ) : (
                          <span className="text-red-600">Non détecté</span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-sm text-gray-500">Aucune information détectée</p>
              )}
            </div>
          </div>
        </div>
      </>
    )}
  </>
);

export default AttestationDetails;
