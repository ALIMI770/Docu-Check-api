/* eslint-disable @typescript-eslint/no-explicit-any */

import React from 'react';
import { DocumentField } from '@/config/documentFieldsConfig';
import { InfoItem } from '@/components/ui/InfoItem';

interface ManuscriptFieldsSectionProps {
  fields: DocumentField[];
  data: any;
}

/**
 * Composant pour afficher les éléments manuscrits d'un document
 */
export const ManuscriptFieldsSection: React.FC<ManuscriptFieldsSectionProps> = ({
  fields,
  data
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {fields.map((field) => {
        const rawValue = data[field.key];
        
        // Déterminer si c'est un champ booléen ou texte
        const isBoolean = typeof rawValue === 'boolean';
        const isPresent = isBoolean ? rawValue : !!rawValue;

        // Formater la valeur d'affichage
        let displayValue: string;
        if (isBoolean) {
          // Pour les booléens (tampon, signature, bon pour accord, etc.)
          if (field.key === 'tampon_present') {
            displayValue = isPresent ? 'Présent' : 'Non détecté';
          } else if (field.key === 'signature_manuscrite') {
            displayValue = isPresent ? 'Présente' : 'Non détectée';
          } else if (field.key === 'bon_pour_accord' || field.key === 'lu_et_approuve') {
            displayValue = isPresent ? 'Présent' : 'Non détecté';
          } else {
            displayValue = isPresent ? 'Présent' : 'Non détecté';
          }
        } else {
          // Pour les valeurs textuelles
          if (field.key === 'date_manuscrite' || field.key === 'fonction_manuscrite') {
            displayValue = rawValue || 'Non détectée';
          } else {
            displayValue = rawValue || 'Non détecté';
          }
        }

        // Déterminer le variant selon la présence
        const variant = isPresent ? 'default' : 'destructive';

        return (
          <InfoItem
            key={field.key}
            label={field.label}
            value={displayValue}
            variant={variant}
          />
        );
      })}
    </div>
  );
};

export default ManuscriptFieldsSection;
