/* eslint-disable @typescript-eslint/no-explicit-any */

import React from 'react';
import { Separator } from '@/components/ui/separator';
import { getFieldsConfigByDocumentType } from '@/config/documentFieldsConfig';
import GeneralFieldsSection from '@/components/document/GeneralFieldsSection';
import ManuscriptFieldsSection from '@/components/document/ManuscriptFieldsSection';
import MultipleTamponSection from '@/components/document/MultipleTamponSection';
import AttestationDetails from '@/components/document/AttestationDetails';

interface DocumentSectionProps {
  title: string;
  data: any;
  icon: string;
  documents: any;
}

/**
 * Composant principal pour afficher les détails d'un document
 * Gère automatiquement l'affichage selon le type de document
 */
export const DocumentSection: React.FC<DocumentSectionProps> = ({
  title,
  data,
  icon,
  documents
}) => {
  if (!data) return null;

  const isAttestation = data.is_attestation_cee;

  // Pour les attestations CEE, afficher uniquement les détails spécifiques
  if (isAttestation) {
    return (
      <div className="border rounded-lg p-4">
        <div className="flex items-center mb-4">
          <span className="text-2xl mr-2">{icon}</span>
          <h4 className="text-lg font-medium">{title}</h4>
        </div>
        <AttestationDetails data={data} documents={documents} />
      </div>
    );
  }

  // Récupérer la configuration des champs selon le type de document
  const fieldsConfig = getFieldsConfigByDocumentType(title);

  // Si aucune configuration n'est trouvée, ne rien afficher
  if (!fieldsConfig) {
    return (
      <div className="border rounded-lg p-4">
        <div className="flex items-center mb-4">
          <span className="text-2xl mr-2">{icon}</span>
          <h4 className="text-lg font-medium">{title}</h4>
        </div>
        <p className="text-gray-500 text-sm">Type de document non reconnu</p>
      </div>
    );
  }

  // Vérifier si c'est un document d'incitation avec des tampons multiples
  const isIncitation = title.toLowerCase().includes('incitation') || 
                       title.toLowerCase().includes('financière');
  const hasMultipleTampons = isIncitation && data.infos_tampons && data.infos_tampons.length > 0;

  return (
    <div className="border rounded-lg p-4">
      {/* En-tête du document */}
      <div className="flex items-center mb-4">
        <span className="text-2xl mr-2">{icon}</span>
        <h4 className="text-lg font-medium">{title}</h4>
      </div>

      {/* Informations générales */}
      <GeneralFieldsSection 
        fields={fieldsConfig.generalFields} 
        data={data} 
        fallbackTitle={title}
      />

      <Separator className="my-4" />

      {/* Section des tampons multiples (pour incitation financière) */}
      {hasMultipleTampons && (
        <>
          <MultipleTamponSection tampons={data.infos_tampons} />
          <Separator className="my-4" />
        </>
      )}

      {/* Éléments manuscrits */}
      <ManuscriptFieldsSection 
        fields={fieldsConfig.manuscriptFields}
        data={data}
      />
    </div>
  );
};

export default DocumentSection;
