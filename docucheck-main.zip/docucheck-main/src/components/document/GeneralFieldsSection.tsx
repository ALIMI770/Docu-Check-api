/* eslint-disable @typescript-eslint/no-explicit-any */

import React from 'react';
import { DocumentField } from '@/config/documentFieldsConfig';
import { InfoItem } from '@/components/ui/InfoItem';

interface GeneralFieldsSectionProps {
  fields: DocumentField[];
  data: any;
  fallbackTitle: string;
}

/**
 * Composant pour afficher les champs généraux d'un document
 */
export const GeneralFieldsSection: React.FC<GeneralFieldsSectionProps> = ({
  fields,
  data,
  fallbackTitle
}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {fields.map((field) => {
        const rawValue = data[field.key];
        let displayValue: string;

        // Appliquer le formateur personnalisé si présent
        if (field.format) {
          displayValue = field.format(rawValue);
        } else {
          // Fallback pour le type de document
          if (field.key === 'document_type' && !rawValue) {
            displayValue = fallbackTitle;
          } else {
            displayValue = rawValue || 'Non détecté';
          }
        }

        return (
          <InfoItem
            key={field.key}
            label={field.label}
            value={displayValue}
          />
        );
      })}
    </div>
  );
};

export default GeneralFieldsSection;
