import { Badge } from "@/components/ui/badge";
import { normalizeAddress, areAddressesEquivalent } from "@/config/coherenceConfig";

interface AddressCoherenceSectionProps {
  title: string;
  addresses: {
    devisAdresseEntreprise?: string;
    devisAdresseTravaux?: string;
    factureAdresseEntreprise?: string;
    factureAdresseTravaux?: string;
  };
}

const AddressCoherenceSection = ({ title, addresses }: AddressCoherenceSectionProps) => {
  const {
    devisAdresseEntreprise,
    devisAdresseTravaux,
    factureAdresseEntreprise,
    factureAdresseTravaux
  } = addresses;

  const devisNormEntreprise = normalizeAddress(devisAdresseEntreprise);
  const devisNormTravaux = normalizeAddress(devisAdresseTravaux);
  const factureNormEntreprise = normalizeAddress(factureAdresseEntreprise);
  const factureNormTravaux = normalizeAddress(factureAdresseTravaux);

  // Vérifier si les adresses sont différentes
  const devisDifferent = devisNormEntreprise && devisNormTravaux && 
    !areAddressesEquivalent(devisAdresseEntreprise, devisAdresseTravaux);
  const factureDifferent = factureNormEntreprise && factureNormTravaux && 
    !areAddressesEquivalent(factureAdresseEntreprise, factureAdresseTravaux);
  
  const needsJustification = devisDifferent || factureDifferent;

  return (
    <div className="border rounded-md p-4">
      <div className="flex justify-between items-center mb-3">
        <h4 className="font-medium">{title}</h4>
        <Badge
          variant={needsJustification ? "destructive" : "outline"}
          className={!needsJustification ? "bg-green-100 text-green-800 hover:bg-green-100" : ""}
        >
          {needsJustification ? "⚠️ Justificatif requis" : "Cohérent"}
        </Badge>
      </div>
      
      <div className="space-y-4">
        {/* Devis */}
        {(devisAdresseEntreprise || devisAdresseTravaux) && (
          <div className={`p-3 rounded-md ${devisDifferent ? 'bg-orange-50 border border-orange-200' : 'bg-gray-50'}`}>
            <div className="font-medium text-sm mb-2">Devis</div>
            <div className="space-y-2 text-sm">
              <div>
                <span className="text-gray-600">Adresse entreprise :</span>{" "}
                <span className="font-medium">{devisAdresseEntreprise || "Non détectée"}</span>
              </div>
              <div>
                <span className="text-gray-600">Adresse travaux :</span>{" "}
                <span className="font-medium">{devisAdresseTravaux || "Non détectée"}</span>
              </div>
              {devisDifferent && (
                <div className="mt-2 p-2 bg-orange-100 rounded text-xs text-orange-900 flex items-start gap-2">
                  <span className="text-base">⚠️</span>
                  <span>
                    <strong>Attention :</strong> L'adresse des travaux diffère de l'adresse de l'entreprise. 
                    Un justificatif de propriété ou d'autorisation est requis.
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Facture */}
        {(factureAdresseEntreprise || factureAdresseTravaux) && (
          <div className={`p-3 rounded-md ${factureDifferent ? 'bg-orange-50 border border-orange-200' : 'bg-gray-50'}`}>
            <div className="font-medium text-sm mb-2">Facture</div>
            <div className="space-y-2 text-sm">
              <div>
                <span className="text-gray-600">Adresse entreprise :</span>{" "}
                <span className="font-medium">{factureAdresseEntreprise || "Non détectée"}</span>
              </div>
              <div>
                <span className="text-gray-600">Adresse travaux :</span>{" "}
                <span className="font-medium">{factureAdresseTravaux || "Non détectée"}</span>
              </div>
              {factureDifferent && (
                <div className="mt-2 p-2 bg-orange-100 rounded text-xs text-orange-900 flex items-start gap-2">
                  <span className="text-base">⚠️</span>
                  <span>
                    <strong>Attention :</strong> L'adresse des travaux diffère de l'adresse de l'entreprise. 
                    Un justificatif de propriété ou d'autorisation est requis.
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
        
        {!devisAdresseEntreprise && !devisAdresseTravaux && !factureAdresseEntreprise && !factureAdresseTravaux && (
          <div className="text-sm text-gray-500 text-center py-4">
            Aucune adresse détectée dans les documents
          </div>
        )}
      </div>
    </div>
  );
};

export default AddressCoherenceSection;
