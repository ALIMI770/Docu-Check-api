import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle2 } from "lucide-react";

interface AmountCoherenceSectionProps {
  title: string;
  documents: Array<{
    type: string;
    amount_ht?: number;
    taux_tva?: number;
    amount_ttc?: number;
  }>;
}

const AmountCoherenceSection = ({ title, documents }: AmountCoherenceSectionProps) => {
  // Filtrer les documents qui ont au moins un montant TTC
  const docsWithAmount = documents.filter(doc => doc.amount_ttc && doc.amount_ttc > 0);

  // Si aucun document avec montant, afficher un message informatif au lieu de ne rien afficher
  if (docsWithAmount.length === 0) {
    return (
      <div className="border rounded-md p-4">
        <div className="flex justify-between items-center mb-3">
          <h4 className="font-medium">{title}</h4>
        </div>
        <p className="text-sm text-gray-500">Aucun devis ou facture avec montant TTC détecté.</p>
      </div>
    );
  }

  // Vérifier la cohérence mathématique pour chaque document
  const coherenceResults = docsWithAmount.map(doc => {
    const hasHT = doc.amount_ht && doc.amount_ht > 0;
    const hasTVA = doc.taux_tva && doc.taux_tva > 0;
    const hasTTC = doc.amount_ttc && doc.amount_ttc > 0;

    let isCoherent = true;
    let calculatedTTC = 0;
    let message = "";

    if (hasHT && hasTVA && hasTTC) {
      // Calculer le TTC attendu : HT × (1 + TVA/100)
      calculatedTTC = doc.amount_ht! * (1 + doc.taux_tva! / 100);
      // Tolérance de ±1€ pour les arrondis
      const difference = Math.abs(calculatedTTC - doc.amount_ttc!);
      isCoherent = difference <= 1;
      
      if (isCoherent) {
        message = `Calcul correct : ${doc.amount_ht} € × (1 + ${doc.taux_tva}%) = ${doc.amount_ttc} €`;
      } else {
        message = `Incohérence détectée : ${doc.amount_ht} € × (1 + ${doc.taux_tva}%) = ${calculatedTTC.toFixed(2)} € ≠ ${doc.amount_ttc} €`;
      }
    } else if (!hasHT || !hasTVA) {
      isCoherent = false;
      const missing = [];
      if (!hasHT) missing.push("Montant HT");
      if (!hasTVA) missing.push("Taux TVA");
      message = `${missing.join(" et ")} manquant${missing.length > 1 ? 's' : ''}`;
    }

    return {
      type: doc.type,
      isCoherent,
      message,
      amount_ht: doc.amount_ht,
      taux_tva: doc.taux_tva,
      amount_ttc: doc.amount_ttc
    };
  });

  // Déterminer la cohérence globale
  const allCoherent = coherenceResults.every(r => r.isCoherent);

  return (
    <div className="border rounded-md p-4">
      <div className="flex justify-between items-center mb-3">
        <h4 className="font-medium">{title}</h4>
        <Badge
          variant={allCoherent ? "outline" : "destructive"}
          className={allCoherent ? "bg-green-100 text-green-800 hover:bg-green-100" : ""}
        >
          {allCoherent ? "Cohérent" : "Incohérent"}
        </Badge>
      </div>

      <div className="space-y-4">
        {coherenceResults.map((result, index) => (
          <div key={index} className="border-l-4 pl-4 py-2" style={{ borderColor: result.isCoherent ? '#22c55e' : '#ef4444' }}>
            <div className="flex items-start gap-2">
              {result.isCoherent ? (
                <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
              )}
              <div className="flex-1">
                <div className="font-medium text-sm mb-1">{result.type}</div>
                <div className="text-sm text-gray-600 mb-2">{result.message}</div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <span className="text-gray-500">HT: </span>
                    <span className="font-medium">{result.amount_ht ? `${result.amount_ht} €` : "—"}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">TVA: </span>
                    <span className="font-medium">{result.taux_tva ? `${result.taux_tva}%` : "—"}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">TTC: </span>
                    <span className="font-medium">{result.amount_ttc ? `${result.amount_ttc} €` : "—"}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AmountCoherenceSection;
