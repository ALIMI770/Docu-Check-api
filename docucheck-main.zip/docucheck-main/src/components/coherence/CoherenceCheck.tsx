import { CheckCircle2, XCircle } from "lucide-react";

interface CoherenceCheckProps {
  title: string;
  isConsistent: boolean;
  details: string;
}

const CoherenceCheck = ({
  title,
  isConsistent,
  details
}: CoherenceCheckProps) => {
  return (
    <div className={`p-3 rounded-md border ${isConsistent ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
      <div className="flex items-start">
        {isConsistent ? (
          <CheckCircle2 className="h-5 w-5 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
        ) : (
          <XCircle className="h-5 w-5 text-red-600 mr-2 mt-0.5 flex-shrink-0" />
        )}
        <div>
          <h6 className={`font-medium ${isConsistent ? 'text-green-800' : 'text-red-800'}`}>{title}</h6>
          <p className="text-sm mt-1">{details}</p>
        </div>
      </div>
    </div>
  );
};

export default CoherenceCheck;
