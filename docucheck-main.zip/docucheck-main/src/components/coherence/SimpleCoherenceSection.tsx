import { Badge } from "@/components/ui/badge";
import { 
  CoherenceItem, 
  validateSimpleCoherence, 
  getSimpleItemColor,
  validateSiretCoherence,
  getSiretItemColor
} from "@/config/coherenceConfig";

interface SimpleCoherenceSectionProps {
  title: string;
  items: CoherenceItem[];
  type?: "siret" | "default";
}

const SimpleCoherenceSection = ({ title, items, type = "default" }: SimpleCoherenceSectionProps) => {
  // Déterminer la cohérence
  let isConsistent: boolean;
  
  if (type === "siret" && items.length === 3) {
    const devisSiret = items[0].value;
    const factureSiret = items[1].value;
    const attestationSiren = items[2].value;
    isConsistent = validateSiretCoherence(devisSiret, factureSiret, attestationSiren);
  } else {
    isConsistent = validateSimpleCoherence(items);
  }

  // Fonction pour déterminer la couleur d'un item
  const getItemColor = (item: CoherenceItem, index: number): string => {
    if (type === "siret" && items.length === 3) {
      return getSiretItemColor(index, items);
    } else {
      return getSimpleItemColor(item, items, isConsistent);
    }
  };

  const nonEmptyValues = items
    .map(item => item.value)
    .filter(value => value !== "Non détecté" && value !== "Non détectée");

  return (
    <div className="border rounded-md p-4">
      <div className="flex justify-between items-center mb-3">
        <h4 className="font-medium">{title}</h4>
        {nonEmptyValues.length > 0 && (
          <Badge
            variant={isConsistent ? "outline" : "destructive"}
            className={isConsistent ? "bg-green-100 text-green-800 hover:bg-green-100" : ""}
          >
            {isConsistent ? "Cohérent" : "Incohérent"}
          </Badge>
        )}
      </div>
      <div className="space-y-2">
        {items.map((item, index) => (
          <div key={index} className="flex justify-between items-center">
            <span className="text-sm text-gray-600">{item.label}</span>
            <span className={`text-sm font-medium ${getItemColor(item, index)}`}>{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SimpleCoherenceSection;
