import { Badge } from "@/components/ui/badge";
import { validateDateCoherence, parseDate } from "@/config/coherenceConfig";

interface DateCoherenceSectionProps {
  title: string;
  dates: {
    devisDate?: string;
    devisSignatureDate?: string;
    factureDate?: string;
    attestationEngagementDate?: string;
    attestationRealisationDate?: string;
    attestationPartBSignatureDates?: string[];
    attestationPartCSignatureDates?: string[];
  };
}

const DateCoherenceSection = ({ title, dates }: DateCoherenceSectionProps) => {
  const {
    devisDate,
    devisSignatureDate,
    factureDate,
    attestationEngagementDate,
    attestationRealisationDate,
    attestationPartBSignatureDates = [],
    attestationPartCSignatureDates = []
  } = dates;

  // Dédupliquer les dates pour éviter les affichages multiples
  const uniquePartBDates = [...new Set(attestationPartBSignatureDates.filter(d => d))];
  const uniquePartCDates = [...new Set(attestationPartCSignatureDates.filter(d => d))];

  const { isConsistent, errors, success } = validateDateCoherence(dates);

  const dDevis = parseDate(devisDate);
  const dSignature = parseDate(devisSignatureDate);
  const dFacture = parseDate(factureDate);
  const dEngagement = parseDate(attestationEngagementDate);
  const dRealisation = parseDate(attestationRealisationDate);

  return (
    <div className="border rounded-md p-4">
      <div className="flex justify-between items-center mb-3">
        <h4 className="font-medium">{title}</h4>
        <Badge
          variant={isConsistent ? "outline" : "destructive"}
          className={isConsistent ? "bg-green-100 text-green-800 hover:bg-green-100" : ""}
        >
          {isConsistent ? "Cohérent" : "Incohérent"}
        </Badge>
      </div>
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Date devis</span>
          <span className={`text-sm font-medium ${!devisDate || (dSignature && dDevis && dDevis > dSignature) ? "text-red-600" : ""}`}>
            {devisDate || "Non détectée"}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Date signature devis</span>
          <span className={`text-sm font-medium ${!devisSignatureDate || (dDevis && dSignature && dDevis > dSignature) || (dFacture && dSignature && dSignature > dFacture) || (dEngagement && dSignature && dEngagement.getTime() !== dSignature.getTime()) ? "text-red-600" : ""}`}>
            {devisSignatureDate || "Non détectée"}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Date facture</span>
          <span className={`text-sm font-medium ${!factureDate || (dSignature && dFacture && dSignature > dFacture) || (dRealisation && dFacture && dRealisation.getTime() !== dFacture.getTime()) ? "text-red-600" : ""}`}>
            {factureDate || "Non détectée"}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Date engagement attestation (Partie A)</span>
          <span className={`text-sm font-medium ${!attestationEngagementDate || (dEngagement && dSignature && dEngagement.getTime() !== dSignature.getTime()) ? "text-red-600" : ""}`}>
            {attestationEngagementDate || "Non détectée"}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Date réalisation attestation (Partie A)</span>
          <span className={`text-sm font-medium ${!attestationRealisationDate || (dRealisation && dFacture && dRealisation.getTime() !== dFacture.getTime()) ? "text-red-600" : ""}`}>
            {attestationRealisationDate || "Non détectée"}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Date de signature Partie B</span>
          <span className={`text-sm font-medium ${uniquePartBDates.length === 0 || uniquePartBDates.some(date => {
            const d = parseDate(date);
            return d && dFacture && d.getTime() !== dFacture.getTime();
          }) ? "text-red-600" : ""}`}>
            {uniquePartBDates.join(", ") || "Non détectée"}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Date de signature Partie C</span>
          <span className={`text-sm font-medium ${uniquePartCDates.length === 0 || uniquePartCDates.some(date => {
            const d = parseDate(date);
            return d && dFacture && d.getTime() !== dFacture.getTime();
          }) ? "text-red-600" : ""}`}>
            {uniquePartCDates.join(", ") || "Non détectée"}
          </span>
        </div>
      </div>
      {/* Messages d'erreur et de succès */}
      {errors.length > 0 && (
        <div className="mt-3 text-sm text-red-700">
          {errors.map((err, i) => (
            <div key={i}>• {err}</div>
          ))}
        </div>
      )}
      {success.length > 0 && (
        <div className="mt-3 text-sm text-green-700">
          {success.map((msg, i) => (
            <div key={i}>• {msg}</div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DateCoherenceSection;
