import React from 'react';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import { ManuscriptElement } from '@/config/manuscriptConfig';

interface ManuscriptSummaryProps {
  elements: ManuscriptElement[];
  partName?: string;
}

/**
 * Composant de synthèse rapide pour l'onglet Éléments manuscrits
 * Affiche un indicateur de statut global et le score de complétude
 */
const ManuscriptSummary: React.FC<ManuscriptSummaryProps> = ({ elements, partName }) => {
  // Calculer les statistiques
  const totalElements = elements.length;
  const presentElements = elements.filter(e => e.present).length;
  const criticalElements = elements.filter(e => 
    e.key === 'signature' || e.key === 'tampon' || e.key === 'part_b_signature' || e.key === 'part_c_signature'
  );
  const criticalPresent = criticalElements.filter(e => e.present).length;
  const criticalTotal = criticalElements.length;
  
  // Déterminer le statut global
  let status: 'success' | 'warning' | 'error';
  let statusIcon: React.ReactNode;
  let statusText: string;
  let statusBgColor: string;
  
  if (presentElements === totalElements) {
    status = 'success';
    statusIcon = <CheckCircle2 className="h-6 w-6 text-green-600" />;
    statusText = "Tous les éléments requis sont présents";
    statusBgColor = "bg-green-50 border-green-200";
  } else if (criticalPresent === criticalTotal && criticalTotal > 0) {
    status = 'warning';
    statusIcon = <AlertTriangle className="h-6 w-6 text-yellow-600" />;
    statusText = "Éléments critiques présents, mais certains éléments manquants";
    statusBgColor = "bg-yellow-50 border-yellow-200";
  } else {
    status = 'error';
    statusIcon = <XCircle className="h-6 w-6 text-red-600" />;
    statusText = "Éléments critiques manquants";
    statusBgColor = "bg-red-50 border-red-200";
  }
  
  const completionPercentage = totalElements > 0 ? Math.round((presentElements / totalElements) * 100) : 0;

  return (
    <div className={`border rounded-lg p-4 mb-6 ${statusBgColor}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          {statusIcon}
          <div>
            <h4 className="font-semibold text-lg">
              Synthèse {partName ? `- ${partName}` : ''}
            </h4>
            <p className="text-sm text-gray-600">{statusText}</p>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-3xl font-bold text-gray-800">
            {presentElements}/{totalElements}
          </div>
          <div className="text-sm text-gray-500">éléments détectés</div>
        </div>
      </div>
      
      {/* Barre de progression */}
      <div className="mb-3">
        <div className="flex justify-between text-xs text-gray-600 mb-1">
          <span>Score de complétude</span>
          <span className="font-semibold">{completionPercentage}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
          <div 
            className={`h-full transition-all duration-500 ${
              status === 'success' ? 'bg-green-500' : 
              status === 'warning' ? 'bg-yellow-500' : 
              'bg-red-500'
            }`}
            style={{ width: `${completionPercentage}%` }}
          />
        </div>
      </div>
      
      {/* Détails rapides */}
      <div className="flex gap-3 flex-wrap">
        {criticalTotal > 0 && (
          <Badge variant="outline" className="bg-white">
            🔒 Critiques: {criticalPresent}/{criticalTotal}
          </Badge>
        )}
        <Badge variant="outline" className="bg-white">
          ✅ Présents: {presentElements}
        </Badge>
        <Badge variant="outline" className="bg-white">
          ❌ Manquants: {totalElements - presentElements}
        </Badge>
      </div>
    </div>
  );
};

export default ManuscriptSummary;
