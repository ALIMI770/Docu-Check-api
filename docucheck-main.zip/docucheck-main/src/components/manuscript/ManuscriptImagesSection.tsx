/* eslint-disable @typescript-eslint/no-explicit-any */

import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch';
import { ZoomIn, Maximize2 } from 'lucide-react';
import { cropImageFromBase64 } from '@/services/imageProcessing';
import { hasManuscriptElements, ManuscriptExtractionOptions } from '@/config/manuscriptConfig';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface ManuscriptImagesSectionProps {
  pages: any[];
  partName?: string;
  options?: ManuscriptExtractionOptions;
  highlightedElement?: string | null;
}

/**
 * Composant pour afficher l'image d'une zone manuscrite recadrée avec zoom et modal
 */
const CroppedManuscriptImage: React.FC<{ doc: any; isHighlighted?: boolean }> = ({ doc, isHighlighted = false }) => {
  const [croppedImg, setCroppedImg] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const coordinates = doc.coordinates_img;

  React.useEffect(() => {
    let isMounted = true;
    setError(null);
    setCroppedImg(null);

    if (!doc.imageDataUrl.dataUrl || !coordinates) {
      setError("Image ou coordonnées manquantes.");
      return;
    }
    setLoading(true);
    cropImageFromBase64(doc.imageDataUrl.dataUrl, coordinates)
      .then((cropped) => {
        if (isMounted) setCroppedImg(cropped);
      })
      .catch(() => {
        if (isMounted) setError("Erreur lors du découpage de l'image.");
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });
    return () => { isMounted = false; };
  }, [doc.imageDataUrl.dataUrl, coordinates]);

  return (
    <>
      <div 
        className={`border rounded-md p-3 transition-all duration-200 flex flex-col items-center mb-2 cursor-pointer ${
          isHighlighted 
            ? 'bg-blue-50 border-blue-400 shadow-lg' 
            : 'bg-gray-50 border-gray-200 hover:border-gray-300 hover:shadow-md'
        }`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={() => setIsModalOpen(true)}
      >
        <div className="flex items-center justify-between w-full mb-2">
          <div className="font-medium text-xs text-gray-600">Aperçu de la zone détectée</div>
          <div className="flex gap-1">
            {isHovered && <ZoomIn className="h-4 w-4 text-gray-500" />}
            <Maximize2 className="h-4 w-4 text-gray-500" />
          </div>
        </div>
        {loading && (
          <div className="text-gray-400 text-sm py-8">Chargement...</div>
        )}
        {error && (
          <div className="text-red-500 text-xs py-4">{error}</div>
        )}
        {!loading && !error && croppedImg && (
          <div className="w-full flex justify-center relative group">
            <img
              src={croppedImg}
              alt="Zone manuscrite détectée"
              className={`rounded shadow max-h-48 max-w-full border transition-transform duration-200 ${
                isHovered ? 'scale-105' : 'scale-100'
              }`}
              style={{ background: "#fff" }}
            />
          </div>
        )}
        <div className="mt-2 text-xs text-gray-400 break-all">
          📍 Coordonnées : <span className="font-mono text-[10px]">{coordinates}</span>
        </div>
      </div>

      {/* Modal pour affichage agrandi avec zoom */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Zone manuscrite - Vue détaillée</DialogTitle>
          </DialogHeader>
          <div className="flex justify-center items-center p-4 bg-gray-100 rounded">
            {croppedImg && (
              <TransformWrapper
                initialScale={1}
                minScale={1}
                maxScale={5}
                wheel={{ step: 0.1 }}
              >
                <TransformComponent>
                  <img
                    src={croppedImg}
                    alt="Zone manuscrite en grand"
                    className="max-h-[70vh] rounded shadow-lg"
                    style={{ background: "#fff" }}
                  />
                </TransformComponent>
              </TransformWrapper>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

/**
 * Composant pour afficher toutes les zones manuscrites détectées dans les pages
 * Gère deux cas : pages avec coordonnées (zones recadrées) et pages sans coordonnées (image complète)
 */
const ManuscriptImagesSection: React.FC<ManuscriptImagesSectionProps> = ({
  pages,
  partName,
  options = {},
  highlightedElement
}) => {
  // Filtrer les pages avec coordonnées manuscrites
  const pagesWithCoordinates = pages.filter(p => {
    // Vérifier si la page a des coordonnées manuscrites
    if (!p.analysis.coordinates_manuscrits) return false;
    
    // Si usePartBSignature ou usePartCSignature, vérifier que la page contient bien ces éléments
    if (options.usePartBSignature) {
      return p.analysis.attestation_parts?.part_b_signature_manuscrite || 
             p.analysis.attestation_parts?.part_b_date_manuscrite;
    }
    if (options.usePartCSignature) {
      return p.analysis.attestation_parts?.part_c_signature_manuscrite || 
             p.analysis.attestation_parts?.part_c_date_manuscrite;
    }
    
    // Sinon, retourner true si des éléments manuscrits génériques existent
    return true;
  });
  
  const pagesWithElementsNoCoords = pages.filter(
    p => hasManuscriptElements(p, options) && !p.analysis.coordinates_manuscrits
  );

  // Si aucune image à afficher
  if (pagesWithCoordinates.length === 0 && pagesWithElementsNoCoords.length === 0) {
    return (
      <div className="border rounded-lg p-8 bg-gray-50 text-center">
        <div className="text-gray-400 mb-2">📷</div>
        <p className="text-sm text-gray-500">Aucune image disponible</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h5 className="font-semibold text-lg flex items-center gap-2 sticky top-0 bg-white py-2 z-10">
        <span>📸</span>
        Zones manuscrites
        {partName && <span className="text-sm text-gray-500 font-normal">({partName})</span>}
      </h5>
      
      <div className="space-y-3">
        {/* Pages avec coordonnées - afficher zones recadrées */}
        {pagesWithCoordinates.map((page, idx) => (
          <div key={`coord-${idx}`} className="border rounded-lg p-3 bg-white">
            <div className="text-xs text-gray-500 mb-2 flex items-center justify-between">
              <span className="font-medium">📄 Page {page.page}</span>
              <Badge variant="outline" className="text-xs bg-blue-50">
                Zone détectée
              </Badge>
            </div>
            <CroppedManuscriptImage
              doc={{
                ...page.analysis,
                imageDataUrl: page.image,
                coordinates_img: page.analysis.coordinates_manuscrits
              }}
              isHighlighted={!!highlightedElement}
            />
          </div>
        ))}
        
        {/* Pages avec éléments manuscrits MAIS sans coordonnées - afficher image complète */}
        {pagesWithElementsNoCoords.map((page, idx) => (
          <div key={`full-${idx}`} className="border rounded-lg p-3 bg-white">
            <div className="text-xs text-gray-500 mb-2 flex items-center justify-between">
              <span className="font-medium">📄 Page {page.page}</span>
              <Badge variant="outline" className="text-xs bg-yellow-50 text-yellow-800">
                Image complète
              </Badge>
            </div>
            {page.image?.dataUrl ? (
              <div className="cursor-pointer hover:opacity-90 transition-opacity">
                <img 
                  src={page.image.dataUrl} 
                  alt={`Page ${page.page} - Image complète`}
                  className="w-full h-auto rounded border shadow-sm hover:shadow-md transition-shadow"
                />
              </div>
            ) : (
              <div className="text-center py-8 text-gray-400 bg-gray-50 rounded">
                <span className="text-2xl mb-2 block">🖼️</span>
                Image non disponible
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ManuscriptImagesSection;
