/* eslint-disable @typescript-eslint/no-explicit-any */

import React, { useState } from 'react';
import { extractManuscriptElements, ManuscriptExtractionOptions } from '@/config/manuscriptConfig';
import ManuscriptElementCard from './ManuscriptElementCard';
import ManuscriptImagesSection from './ManuscriptImagesSection';
import ManuscriptSummary from './ManuscriptSummary';
import { Button } from '@/components/ui/button';
import { LayoutGrid, LayoutList } from 'lucide-react';

interface ManuscritSectionProps {
  pages: any[];
  partName?: string;
  usePartBSignature?: boolean;
  usePartCSignature?: boolean;
}

/**
 * Composant principal pour afficher les éléments manuscrits d'un document ou d'une partie
 * Layout côte à côte : grille d'éléments à gauche, images à droite sur desktop
 * Mode comparaison : chaque élément avec son image correspondante
 */
const ManuscritSection: React.FC<ManuscritSectionProps> = ({
  pages,
  partName,
  usePartBSignature = false,
  usePartCSignature = false
}) => {
  const [highlightedElement, setHighlightedElement] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'split' | 'comparison'>('split');
  
  const options: ManuscriptExtractionOptions = {
    usePartBSignature,
    usePartCSignature
  };

  // Extraire les éléments manuscrits depuis les pages
  const manuscriptElements = extractManuscriptElements(pages, options);

  // Si aucun élément manuscrit détecté
  if (manuscriptElements.length === 0) {
    return (
      <div className="text-center py-8">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg">
          <span className="text-2xl">📄</span>
          <span className="text-gray-600">Aucun élément manuscrit détecté{partName ? ` dans ${partName}` : ''}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Synthèse rapide en haut */}
      <ManuscriptSummary elements={manuscriptElements} partName={partName} />
      
      {/* Toggle entre vue liste et vue comparaison */}
      <div className="flex justify-end gap-2">
        <Button
          variant={viewMode === 'split' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setViewMode('split')}
          className="gap-2"
        >
          <LayoutGrid className="h-4 w-4" />
          Vue côte à côte
        </Button>
        <Button
          variant={viewMode === 'comparison' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setViewMode('comparison')}
          className="gap-2"
        >
          <LayoutList className="h-4 w-4" />
          Vue comparaison
        </Button>
      </div>

      {viewMode === 'split' ? (
        /* Vue côte à côte : grille à gauche, images à droite */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Gauche : Grille des éléments manuscrits */}
          <div className="space-y-4">
            <h5 className="font-semibold text-lg flex items-center gap-2">
              <span>📝</span>
              Éléments détectés
            </h5>
            <div className="grid grid-cols-1 gap-3">
              {manuscriptElements.map(element => (
                <ManuscriptElementCard 
                  key={element.key} 
                  element={element}
                  isHighlighted={highlightedElement === element.key}
                  onClick={() => setHighlightedElement(element.key)}
                />
              ))}
            </div>
          </div>

          {/* Droite : Images des zones manuscrites */}
          <div className="space-y-4">
            <ManuscriptImagesSection 
              pages={pages} 
              partName={partName}
              options={options}
              highlightedElement={highlightedElement}
            />
          </div>
        </div>
      ) : (
        /* Vue comparaison : chaque élément avec son image */
        <div className="space-y-4">
          <h5 className="font-semibold text-lg flex items-center gap-2 mb-4">
            <span>🔍</span>
            Vue comparaison détaillée
          </h5>
          {manuscriptElements.map(element => (
            <div key={element.key} className="border rounded-lg p-4 bg-white">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Gauche : Carte de l'élément */}
                <ManuscriptElementCard 
                  element={element}
                  onClick={() => {}}
                />
                
                {/* Droite : Image correspondante si disponible */}
                <div className="flex items-center justify-center border rounded bg-gray-50 p-4">
                  {element.present ? (
                    <ManuscriptImagesSection 
                      pages={pages.filter(p => {
                        // Filtrer pour afficher uniquement l'image pertinente pour cet élément
                        const analysis = p.analysis;
                        if (element.key === 'signature') return analysis.signature_manuscrite;
                        if (element.key === 'tampon') return analysis.tampon_present;
                        if (element.key === 'bon_pour_accord') return analysis.bon_pour_accord;
                        if (element.key === 'lu_et_approuve') return analysis.lu_et_approuve;
                        if (element.key === 'nom_manuscrit') return analysis.nom_manuscrit;
                        if (element.key === 'fonction_manuscrite') return analysis.fonction_manuscrite;
                        if (element.key === 'date_manuscrite') return analysis.date_manuscrite;
                        if (element.key === 'part_b_signature') return analysis.attestation_parts?.part_b_signature_manuscrite;
                        if (element.key === 'part_b_date') return analysis.attestation_parts?.part_b_date_manuscrite;
                        if (element.key === 'part_c_signature') return analysis.attestation_parts?.part_c_signature_manuscrite;
                        if (element.key === 'part_c_date') return analysis.attestation_parts?.part_c_date_manuscrite;
                        return false;
                      })}
                      options={options}
                      highlightedElement={element.key}
                    />
                  ) : (
                    <div className="text-center text-gray-400 py-8">
                      <span className="text-4xl mb-2 block">🔍</span>
                      <p className="text-sm">Élément non détecté</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ManuscritSection;
