import React from 'react';
import { Badge } from '@/components/ui/badge';
import { ManuscriptElement, getScoreBadgeColor } from '@/config/manuscriptConfig';

interface ManuscriptElementCardProps {
  element: ManuscriptElement;
  isHighlighted?: boolean;
  onClick?: () => void;
}

/**
 * Composant pour afficher une carte d'élément manuscrit avec barre de progression
 * Affiche l'icône, le label, le score de confiance visuel et les détails éventuels
 */
const ManuscriptElementCard: React.FC<ManuscriptElementCardProps> = ({ 
  element,
  isHighlighted = false,
  onClick
}) => {
  // Déterminer la couleur de la barre selon le score
  const getProgressColor = (score?: number) => {
    if (!score) return 'bg-gray-400';
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-orange-500';
  };

  const getBackgroundColor = () => {
    if (isHighlighted) return 'bg-blue-100 border-blue-400 shadow-lg';
    if (element.present) {
      if ((element.score ?? 0) >= 80) return 'bg-green-50 border-green-300';
      if ((element.score ?? 0) >= 60) return 'bg-yellow-50 border-yellow-300';
      return 'bg-orange-50 border-orange-300';
    }
    return 'bg-gray-50 border-gray-200';
  };

  return (
    <div 
      className={`border rounded-lg p-4 transition-all duration-200 cursor-pointer hover:shadow-md ${getBackgroundColor()}`}
      onClick={onClick}
    >
      {/* En-tête avec icône, label et badge */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-3xl">{element.icon}</span>
          <div>
            <span className="font-semibold text-base">{element.label}</span>
            {/* {element.present && element.score && (
              <div className="text-xs text-gray-600 mt-0.5">
                Confiance: {element.score}%
              </div>
            )} */}
          </div>
        </div>
        <Badge 
          className={`${getScoreBadgeColor(element.score)} hover:${getScoreBadgeColor(element.score)} text-xs`}
        >
          {element.present 
            ? `Confiance : ${element.score ?? 'N/A'}%`
            : 'Non détecté'}
        </Badge>
      </div>
      
      {/* Barre de progression pour le score de confiance */}
      {element.present && element.score && (
        <div className="mb-3">
          <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
            <div 
              className={`h-full transition-all duration-500 ${getProgressColor(element.score)}`}
              style={{ width: `${element.score}%` }}
            />
          </div>
        </div>
      )}
      
      {/* Valeur textuelle (nom, fonction, date) */}
      {element.value && (
        <div className="mt-2 p-2 bg-white rounded border border-gray-200">
          <div className="text-xs text-gray-500 mb-1">Valeur détectée</div>
          <div className="text-sm text-gray-800 font-semibold">
            {element.value}
          </div>
        </div>
      )}
      
      {/* Détails du tampon (nom, adresse, SIRET) */}
      {element.detailsData && (
        <div className="mt-2 p-3 bg-white rounded border border-gray-200 text-xs space-y-2">
          <div className="text-xs text-gray-500 font-semibold mb-2">📋 Détails extraits</div>
          {element.detailsData.nom && (
            <div className="flex gap-2">
              <span className="text-gray-500 min-w-[60px]">Nom:</span>
              <span className="font-medium text-gray-800">{element.detailsData.nom}</span>
            </div>
          )}
          {element.detailsData.adresse && (
            <div className="flex gap-2">
              <span className="text-gray-500 min-w-[60px]">Adresse:</span>
              <span className="font-medium text-gray-800">{element.detailsData.adresse}</span>
            </div>
          )}
          {element.detailsData.siret && (
            <div className="flex gap-2">
              <span className="text-gray-500 min-w-[60px]">SIRET:</span>
              <span className="font-medium text-gray-800">{element.detailsData.siret}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ManuscriptElementCard;
