﻿import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AnalysisResult } from '@/types/document';
import { Badge } from './ui/badge';
import {
  AlertTriangle,
  FileText,
  FileCheck
} from "lucide-react";
import 'react-image-crop/dist/ReactCrop.css';
import { getDocumentIcon } from '@/utils/documentUtils';
import { useDocumentAnalysis } from '@/hooks/useDocumentAnalysis';
import DocumentSection from '@/components/document/DocumentSection';
import ManuscritSection from '@/components/manuscript/ManuscritSection';
import AddressCoherenceSection from '@/components/coherence/AddressCoherenceSection';
import DateCoherenceSection from '@/components/coherence/DateCoherenceSection';
import SimpleCoherenceSection from '@/components/coherence/SimpleCoherenceSection';
import AmountCoherenceSection from '@/components/coherence/AmountCoherenceSection';
import CoherenceCheck from '@/components/coherence/CoherenceCheck';
import { InfoItem } from '@/components/ui/InfoItem';
import ManuscritItem from '@/components/ui/ManuscritItem';
import AttestationDetails from '@/components/document/AttestationDetails';

interface PromptDetailsTableProps {
  result: AnalysisResult | null;
}

const PromptDetailsTable = ({ result }: PromptDetailsTableProps) => {
  // Utilisation du hook personnalisé pour traiter les données
  const processedData = useDocumentAnalysis(result);

  // État de chargement ou données manquantes
  if (!processedData) {
    return (
      <div className="p-6 bg-white rounded-lg shadow-md min-h-[400px] flex items-center justify-center">
        <p className="text-gray-500">Aucune donnée d'analyse détaillée disponible.</p>
      </div>
    );
  }

  // Déstructuration des données traitées
  const {
    documentsSynthese,
    devis,
    facture,
    attestation,
    groupedPages,
    attestationPartBSignatureDates,
    attestationPartCSignatureDates,
    originalDocuments: documents
  } = processedData;
  return (
    <div className="bg-white rounded-lg shadow-md min-h-[400px]">
      <div className="p-6 border-b">
        <h2 className="text-xl font-semibold">Détails de l'analyse</h2>
        <p className="text-sm text-gray-500 mt-1">
          Vérifications et cohérence des documents par catégorie
        </p>
      </div>

      <div className="p-6">
        <Tabs defaultValue="documents">
          <TabsList className="w-full mb-6 grid grid-cols-4">
            <TabsTrigger value="documents">Documents</TabsTrigger>
            <TabsTrigger value="pages">Pages</TabsTrigger>
            <TabsTrigger value="manuscrit">Éléments manuscrits</TabsTrigger>
            <TabsTrigger value="coherence">Cohérence</TabsTrigger>
            {/* <TabsTrigger value="attestation-cee">Attestation CEE</TabsTrigger> */}
          </TabsList>

          <TabsContent value="documents" className="space-y-6">
            <h3 className="text-lg font-medium">Informations extraites par document</h3>
            
            {documentsSynthese.map((doc, index) => (
              <DocumentSection 
                key={index}
                title={doc.type}
                data={doc.pages[0].analysis} 
                icon={getDocumentIcon(doc.type)}
                documents={documents}
              />
            ))}
            
            {documents.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <p>Aucun document n'a pu être correctement identifié.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="pages" className="space-y-6">
            <h3 className="text-lg font-medium">Analyse par page</h3>
            {groupedPages.length > 0 ? (
              <div className="space-y-4">
                <Tabs defaultValue={`doc-0`} className="w-full">
                  <TabsList className="mb-4 flex flex-wrap">
                    {groupedPages.map((doc, index) => (
                      <TabsTrigger 
                        key={index} 
                        value={`doc-${index}`} 
                        className="flex-grow"
                      >
                        <div className="flex items-center">
                          <span>Page {doc.startPage}-{doc.endPage} {doc.type}</span>
                          {doc.pages[0].analysis.is_attestation_cee && (
                            <Badge variant="outline" className="ml-2 text-xs">
                              {doc.pages.some(p => p.analysis.is_attestation_cee && p.analysis.attestation_parts?.part_a_present) && " (A)"}
                              {doc.pages.some(p => p.analysis.is_attestation_cee && p.analysis.attestation_parts?.part_b_present) && " (B)"}
                              {doc.pages.some(p => p.analysis.is_attestation_cee && p.analysis.attestation_parts?.part_c_present) && " (C)"}
                            </Badge>
                          )}
                        </div>
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  
                  {groupedPages.map((doc, docIndex) => (
                    <TabsContent key={docIndex} value={`doc-${docIndex}`}>
                      <div className="border rounded-md p-4">
                        <div className="flex justify-between items-center mb-4">
                          <h4 className="text-lg font-medium">{doc.type}</h4>
                          <Badge variant="outline">Pages {doc.startPage}-{doc.endPage}</Badge>
                        </div>
                        
                        
                        <div className="space-y-6">
                          {/* uniquement si ce n'est pas une attestation CEE */}
                          {!doc.pages.some(p => p.analysis.is_attestation_cee) && (
                            <>
                              {/* Informations générales - adapter selon le type */}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <InfoItem 
                                  label="Type de document" 
                                  value={doc.pages[0].analysis.document_type || doc.type} 
                                />
                                
                                {/* DEVIS ou FACTURE */}
                                {(doc.type.toLowerCase().includes('devis') || doc.type.toLowerCase().includes('facture')) && (
                                  <>
                                    <InfoItem 
                                      label="Nom du client" 
                                      value={doc.pages.find(p => p.analysis.nom_client)?.analysis.nom_client || "Non détecté"} 
                                    />
                                    <InfoItem 
                                      label="SIRET client" 
                                      value={doc.pages.find(p => p.analysis.siret_client)?.analysis.siret_client || "Non détecté"} 
                                    />
                                    <InfoItem 
                                      label="Adresse entreprise client" 
                                      value={doc.pages.find(p => p.analysis.adresse_entreprise_client)?.analysis.adresse_entreprise_client || "Non détectée"} 
                                    />
                                    <InfoItem 
                                      label="Adresse des travaux" 
                                      value={doc.pages.find(p => p.analysis.adresse_travaux)?.analysis.adresse_travaux || "Non détectée"} 
                                    />
                                    <InfoItem 
                                      label="Date d'émission" 
                                      value={doc.pages.find(p => p.analysis.date_emission)?.analysis.date_emission || "Non détectée"} 
                                    />
                                  </>
                                )}
                                
                                {/* CONTRAT DE PARTENARIAT */}
                                {doc.type.toLowerCase().includes('contrat') && (
                                  <>
                                    <InfoItem 
                                      label="Date du contrat" 
                                      value={doc.pages.find(p => p.analysis.date_contrat)?.analysis.date_contrat || "Non détectée"} 
                                    />
                                    <InfoItem 
                                      label="Nom bénéficiaire" 
                                      value={doc.pages.find(p => p.analysis.nom_beneficiaire_contrat)?.analysis.nom_beneficiaire_contrat || "Non détecté"} 
                                    />
                                    <InfoItem 
                                      label="Adresse bénéficiaire" 
                                      value={doc.pages.find(p => p.analysis.adresse_beneficiaire_contrat)?.analysis.adresse_beneficiaire_contrat || "Non détectée"} 
                                    />
                                    <InfoItem 
                                      label="Nom entreprise prestataire" 
                                      value={doc.pages.find(p => p.analysis.nom_entreprise_prestataire)?.analysis.nom_entreprise_prestataire || "Non détecté"} 
                                    />
                                    <InfoItem 
                                      label="SIRET prestataire" 
                                      value={doc.pages.find(p => p.analysis.siret_prestataire)?.analysis.siret_prestataire || "Non détecté"} 
                                    />
                                    <InfoItem 
                                      label="Date de signature" 
                                      value={doc.pages.find(p => p.analysis.date_signature)?.analysis.date_signature || "Non détectée"} 
                                    />
                                  </>
                                )}
                                
                                {/* INCITATION FINANCIERE */}
                                {doc.type.toLowerCase().includes('incitation') && (
                                  <>
                                    <InfoItem 
                                      label="Nom bénéficiaire" 
                                      value={doc.pages.find(p => p.analysis.nom_beneficiaire)?.analysis.nom_beneficiaire || "Non détecté"} 
                                    />
                                    <InfoItem 
                                      label="SIREN bénéficiaire" 
                                      value={doc.pages.find(p => p.analysis.siren_beneficiaire)?.analysis.siren_beneficiaire || "Non détecté"} 
                                    />
                                    <InfoItem 
                                      label="Adresse bénéficiaire" 
                                      value={doc.pages.find(p => p.analysis.adresse_beneficiaire)?.analysis.adresse_beneficiaire || "Non détectée"} 
                                    />
                                    <InfoItem 
                                      label="Nom entreprise obligé" 
                                      value={doc.pages.find(p => p.analysis.nom_entreprise_oblige)?.analysis.nom_entreprise_oblige || "Non détecté"} 
                                    />
                                    <InfoItem 
                                      label="SIRET obligé" 
                                      value={doc.pages.find(p => p.analysis.siret_oblige)?.analysis.siret_oblige || "Non détecté"} 
                                    />
                                  </>
                                )}
                                
                                {/* Montants - afficher HT et TVA seulement pour devis et facture */}
                                {(doc.type.toLowerCase().includes('devis') || doc.type.toLowerCase().includes('facture')) && (
                                  <>
                                    <InfoItem 
                                      label="Montant HT" 
                                      value={doc.pages.find(p => p.analysis.amount_ht)?.analysis.amount_ht ? 
                                        `${doc.pages.find(p => p.analysis.amount_ht)?.analysis.amount_ht} €` : 
                                        "Non détecté"
                                      } 
                                    />
                                    <InfoItem 
                                      label="Taux de TVA" 
                                      value={doc.pages.find(p => p.analysis.taux_tva)?.analysis.taux_tva ? 
                                        `${doc.pages.find(p => p.analysis.taux_tva)?.analysis.taux_tva} %` : 
                                        "Non détecté"
                                      } 
                                    />
                                  </>
                                )}
                                
                                <InfoItem 
                                  label="Montant TTC" 
                                  value={doc.pages.find(p => p.analysis.amount_ttc)?.analysis.amount_ttc ? 
                                    `${doc.pages.find(p => p.analysis.amount_ttc)?.analysis.amount_ttc} €` : 
                                    "Non détecté"
                                  } 
                                />
                              </div>
                            
                              {/* Éléments manuscrits */}
                              <div className="border-t pt-4">
                                <h5 className="font-medium mb-3">Éléments manuscrits détectés (pourcentage de fiabilité)</h5>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <ManuscritItem 
                                    label="Tampon entreprise" 
                                    present={doc.pages.some(p => p.analysis.tampon_present)}
                                    score={doc.pages.map(p => p.analysis.fiabilite_manuscrits?.tampon).filter(s => s !== undefined && s !== null && s !== '' && s !== 0)[0]}
                                  />
                                  <ManuscritItem 
                                    label="Signature" 
                                    present={doc.pages.some(p => p.analysis.signature_manuscrite)}
                                    score={doc.pages.map(p => p.analysis.fiabilite_manuscrits?.signature).filter(s => s !== undefined && s !== null && s !== '' && s !== 0)[0]}
                                    textPresent='Présente'
                                    textAbsent='Non détectée'
                                    
                                  />
                                  <ManuscritItem 
                                    label="Bon pour accord" 
                                    present={doc.pages.some(p => p.analysis.bon_pour_accord)}
                                    score={doc.pages.map(p => p.analysis.fiabilite_manuscrits?.bon_pour_accord).filter(s => s !== undefined && s !== null && s !== '' && s !== 0)[0]}
                                  />
                                  <ManuscritItem
                                    label="Lu et apé"
                                    present={doc.pages.some(p => p.analysis.lu_et_approuve)}
                                    score={doc.pages.map(p => p.analysis.fiabilite_manuscrits?.lu_et_approuve).filter(s => s !== undefined && s !== null && s !== '' && s !== 0)[0]}
                                  />
                                  {/* {doc.pages.some(p => p.analysis.nom_manuscrit) && ( */}
                                    <ManuscritItem 
                                      label="Nom manuscrit" 
                                      present={doc.pages.some(p => p.analysis.nom_manuscrit)}
                                      score={doc.pages.map(p => p.analysis.fiabilite_manuscrits?.nom_manuscrit).filter(s => s !== undefined && s !== null && s !== '' && s !== 0)[0]}
                                      value={doc.pages.find(p => p.analysis.nom_manuscrit)?.analysis.nom_manuscrit}
                                    />
                                  {/* )} */}
                                  {/* {doc.pages.some(p => p.analysis.fonction_manuscrite) && ( */}
                                    <ManuscritItem 
                                      label="Fonction manuscrite" 
                                      present={doc.pages.some(p => p.analysis.fonction_manuscrite)}
                                      score={doc.pages.map(p => p.analysis.fiabilite_manuscrits?.fonction_manuscrite).filter(s => s !== undefined && s !== null && s !== '' && s !== 0)[0]}
                                      value={doc.pages.find(p => p.analysis.fonction_manuscrite)?.analysis.fonction_manuscrite}
                                    />
                                  {/* )} */}
                                  {/* {doc.pages.some(p => p.analysis.date_manuscrite) && ( */}
                                    <ManuscritItem
                                      label="Date manuscrite"
                                      present={doc.pages.some(p => p.analysis.date_manuscrite)}
                                      score={doc.pages.map(p => p.analysis.fiabilite_manuscrits?.date_manuscrite).filter(s => s !== undefined && s !== null && s !== '' && s !== 0)[0]}
                                      value={doc.pages.find(p => p.analysis.date_manuscrite)?.analysis.date_manuscrite}
                                      textPresent='Présente'
                                      textAbsent='Non détectée'
                                    />
                                  {/* )} */}
                                </div>
                              </div>
                            </>
                          )}

                          {/* Informations spécifiques aux attestations CEE */}
                          {doc.pages.some(p => p.analysis.is_attestation_cee) && (                          
                            <AttestationDetails data={documentsSynthese.find(doc => doc.pages[0]?.analysis?.is_attestation_cee)?.pages[0]?.analysis} documents={documents} />
                          )}
                        </div>
                      </div>
                    </TabsContent>
                  ))}
                </Tabs>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <p>Aucune page n'a pu être analysée.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="manuscrit" className="space-y-6">
            <h3 className="text-lg font-medium mb-4">Éléments manuscrits détectés</h3>
            
            {documents.map((doc, docIndex) => {
              const isAttestation = doc.pages.some(p => p.analysis.is_attestation_cee);
              
              return (
                <div key={docIndex} className="border rounded-lg overflow-hidden">
                  {/* En-tête du document */}
                  <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 border-b">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{getDocumentIcon(doc.type)}</span>
                        <div>
                          <h4 className="font-semibold text-lg">{doc.type}</h4>
                          <p className="text-sm text-gray-600">
                            {doc.pages.length} page{doc.pages.length > 1 ? 's' : ''} analysée{doc.pages.length > 1 ? 's' : ''}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    {isAttestation ? (
                      /* ATTESTATION CEE - Affichage par parties A, B, C */
                      <Tabs defaultValue="overview" className="w-full">
                        <TabsList className="w-full grid grid-cols-4 mb-6">
                          <TabsTrigger value="overview">Vue d'ensemble</TabsTrigger>
                          <TabsTrigger value="part-a">Partie A</TabsTrigger>
                          <TabsTrigger value="part-b">Partie B</TabsTrigger>
                          <TabsTrigger value="part-c">Partie C</TabsTrigger>
                        </TabsList>

                        {/* Vue d'ensemble */}
                        <TabsContent value="overview" className="space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {[
                              { key: 'part_a', label: 'Partie A', pages: doc.pages.filter(p => p.analysis.attestation_parts?.part_a_present) },
                              { key: 'part_b', label: 'Partie B', pages: doc.pages.filter(p => p.analysis.attestation_parts?.part_b_present || p.analysis.attestation_parts?.part_b_signature_manuscrite || p.analysis.attestation_parts?.part_b_date_manuscrite) },
                              { key: 'part_c', label: 'Partie C', pages: doc.pages.filter(p => p.analysis.attestation_parts?.part_c_present || p.analysis.attestation_parts?.part_c_signature_manuscrite || p.analysis.attestation_parts?.part_c_date_manuscrite) }
                            ].map(part => {
                              const hasManuscrit = part.pages.some(p => 
                                p.analysis.signature_manuscrite || 
                                p.analysis.tampon_present || 
                                p.analysis.bon_pour_accord ||
                                p.analysis.lu_et_approuve ||
                                p.analysis.nom_manuscrit ||
                                p.analysis.fonction_manuscrite ||
                                p.analysis.date_manuscrite ||
                                p.analysis.attestation_parts?.part_b_signature_manuscrite ||
                                p.analysis.attestation_parts?.part_b_date_manuscrite ||
                                p.analysis.attestation_parts?.part_c_signature_manuscrite ||
                                p.analysis.attestation_parts?.part_c_date_manuscrite
                              );
                              
                              return (
                                <div key={part.key} className="border rounded-lg p-4 bg-gray-50">
                                  <h5 className="font-medium mb-2">{part.label}</h5>
                                  {part.pages.length > 0 ? (
                                    <div className="space-y-2 text-sm">
                                      <div className="flex items-center gap-2">
                                        <Badge variant={hasManuscrit ? "default" : "secondary"} className={hasManuscrit ? "bg-green-100 text-green-800" : ""}>
                                          {hasManuscrit ? `${part.pages.filter(p => {
                                            const hasElem = p.analysis.signature_manuscrite || 
                                              p.analysis.tampon_present || 
                                              p.analysis.bon_pour_accord ||
                                              p.analysis.lu_et_approuve ||
                                              p.analysis.nom_manuscrit ||
                                              p.analysis.fonction_manuscrite ||
                                              p.analysis.date_manuscrite ||
                                              p.analysis.attestation_parts?.part_b_signature_manuscrite ||
                                              p.analysis.attestation_parts?.part_b_date_manuscrite ||
                                              p.analysis.attestation_parts?.part_c_signature_manuscrite ||
                                              p.analysis.attestation_parts?.part_c_date_manuscrite;
                                            return hasElem;
                                          }).length} Élément(s) manuscrit(s)` : "Aucun élément"}
                                        </Badge>
                                      </div>
                                      {part.pages.some(p => p.analysis.coordinates_manuscrits) && (
                                        <div className="text-xs text-gray-500">
                                          ?? {part.pages.filter(p => p.analysis.coordinates_manuscrits).length} zone(s) détectése(s)
                                        </div>
                                      )}
                                    </div>
                                  ) : (
                                    <p className="text-sm text-gray-500">Non présente</p>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </TabsContent>

                        {/* Partie A */}
                        <TabsContent value="part-a">
                          {(() => {
                            const pagesA = doc.pages.filter(p => p.analysis.attestation_parts?.part_a_present);
                            if (pagesA.length === 0) {
                              return <div className="text-center py-8 text-gray-500">Partie A non trouvée</div>;
                            }
                            
                            // Filtrer uniquement les pages avec éléments manuscrits génériques
                            const pagesWithManuscript = pagesA.filter(p => 
                              p.analysis.signature_manuscrite || p.analysis.tampon_present || 
                              p.analysis.bon_pour_accord || p.analysis.lu_et_approuve ||
                              p.analysis.nom_manuscrit || p.analysis.fonction_manuscrite || p.analysis.date_manuscrite
                            );
                            
                            if (pagesWithManuscript.length === 0) {
                              return (
                                <div className="text-center py-8">
                                  <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg">
                                    <span className="text-2xl">📄</span>
                                    <span className="text-gray-600">Aucun élément manuscrit détecté dans la Partie A</span>
                                  </div>
                                </div>
                              );
                            }
                            
                            return <ManuscritSection pages={pagesWithManuscript} partName="Partie A" />;
                          })()}
                        </TabsContent>

                        {/* Partie B */}
                        <TabsContent value="part-b">
                          {(() => {
                            const pagesB = doc.pages.filter(p => 
                              p.analysis.attestation_parts?.part_b_present ||
                              p.analysis.attestation_parts?.part_b_signature_manuscrite ||
                              p.analysis.attestation_parts?.part_b_date_manuscrite
                            );
                            if (pagesB.length === 0) {
                              return <div className="text-center py-8 text-gray-500">Partie B non trouvée</div>;
                            }
                            
                            // Filtrer uniquement les pages avec éléments manuscrits spécifiques à la partie B
                            const pagesWithManuscript = pagesB.filter(p => 
                              p.analysis.attestation_parts?.part_b_signature_manuscrite ||
                              p.analysis.attestation_parts?.part_b_date_manuscrite
                            );
                            
                            if (pagesWithManuscript.length === 0) {
                              return (
                                <div className="text-center py-8">
                                  <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg">
                                    <span className="text-2xl">📄</span>
                                    <span className="text-gray-600">Aucun élément manuscrit détecté dans la Partie B</span>
                                  </div>
                                </div>
                              );
                            }
                            
                            return <ManuscritSection pages={pagesWithManuscript} partName="Partie B" usePartBSignature={true} />;
                          })()}
                        </TabsContent>

                        {/* Partie C */}
                        <TabsContent value="part-c">
                          {(() => {
                            const pagesC = doc.pages.filter(p => 
                              p.analysis.attestation_parts?.part_c_present ||
                              p.analysis.attestation_parts?.part_c_signature_manuscrite ||
                              p.analysis.attestation_parts?.part_c_date_manuscrite
                            );
                            if (pagesC.length === 0) {
                              return <div className="text-center py-8 text-gray-500">Partie C non trouvée</div>;
                            }
                            
                            // Filtrer uniquement les pages avec éléments manuscrits spécifiques à la partie C
                            const pagesWithManuscript = pagesC.filter(p => 
                              p.analysis.attestation_parts?.part_c_signature_manuscrite ||
                              p.analysis.attestation_parts?.part_c_date_manuscrite
                            );
                            
                            if (pagesWithManuscript.length === 0) {
                              return (
                                <div className="text-center py-8">
                                  <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg">
                                    <span className="text-2xl">📄</span>
                                    <span className="text-gray-600">Aucun élément manuscrit détecté dans la Partie C</span>
                                  </div>
                                </div>
                              );
                            }
                            
                            return <ManuscritSection pages={pagesC} partName="Partie C" usePartCSignature={true} />;
                          })()}
                        </TabsContent>
                      </Tabs>
                    ) : (
                      /* DOCUMENT NORMAL (devis, facture, etc.) */
                      <ManuscritSection pages={doc.pages} />
                    )}
                  </div>
                </div>
              );
            })}

            {documents.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                <p className="text-lg">Aucun document à analyser</p>
              </div>
            )}
          
          </TabsContent>

          <TabsContent value="coherence" className="space-y-6">
            <h3 className="text-lg font-medium">Vérifications de cohérence</h3>
            
            <div className="space-y-6">
              {/* Cohérence SIRET */}
              <SimpleCoherenceSection
                type="siret"
                title="Cohérence des SIRET"
                items={[
                  { label: "Devis", value: devis?.siret_client || "Non détecté" },
                  { label: "Facture", value: facture?.siret_client || "Non détecté" },
                  { label: "Attestation Partie B (SIREN)", value: attestation?.attestation_parts?.part_b_company_info?.siren || "Non détecté" }
                ]}
              />
              
              {/* Cohérence dates */}
              <DateCoherenceSection
                title="Cohérence des dates"
                dates={{
                  devisDate: devis?.date_emission,
                  devisSignatureDate: devis?.date_manuscrite,
                  factureDate: facture?.date_emission,
                  attestationEngagementDate: attestation?.attestation_parts?.part_a_dates?.engagement,
                  attestationRealisationDate: attestation?.attestation_parts?.part_a_dates?.realisation,
                  attestationPartBSignatureDates: attestationPartBSignatureDates,
                  attestationPartCSignatureDates: attestationPartCSignatureDates,
                }}
              />
              
              {/* Cohérence montants - Détection automatique de tous les documents avec montant TTC */}
              {(() => {
                // Extraire tous les documents qui ont un amount_ttc
                const documentsAvecMontant = documentsSynthese
                  .map((doc) => {
                    const montant = doc.pages.find((p: { analysis: { amount_ttc?: string } }) => p.analysis.amount_ttc)?.analysis.amount_ttc;
                    return {
                      type: doc.type,
                      montant: montant
                    };
                  })
                  .filter((doc) => doc.montant); // Garder uniquement ceux qui ont un montant

                // Si au moins un document a un montant, afficher la section
                if (documentsAvecMontant.length > 0) {
                  const montantItems = documentsAvecMontant.map((doc) => ({
                    label: doc.type,
                    value: `${doc.montant} €`
                  }));

                  return (
                    <SimpleCoherenceSection
                      title="Cohérence des montants"
                      items={montantItems}
                    />
                  );
                }
                return null;
              })()}

              {/* Vérification cohérence mathématique HT + TVA = TTC */}
              <AmountCoherenceSection
                title="Vérification calcul TVA (HT × (1 + TVA%) = TTC)"
                documents={documentsSynthese
                  .filter((doc) => 
                    doc.type.toLowerCase().includes('devis') || 
                    doc.type.toLowerCase().includes('facture')
                  )
                  .map((doc) => ({
                    type: doc.type,
                    amount_ht: doc.pages.find((p: { analysis: { amount_ht?: number } }) => p.analysis.amount_ht)?.analysis.amount_ht,
                    taux_tva: doc.pages.find((p: { analysis: { taux_tva?: number } }) => p.analysis.taux_tva)?.analysis.taux_tva,
                    amount_ttc: doc.pages.find((p: { analysis: { amount_ttc?: number } }) => p.analysis.amount_ttc)?.analysis.amount_ttc
                  }))
                }
              />
              
              {/* Cohérence entreprise */}
              <SimpleCoherenceSection
                title="Cohérence des noms d'entreprise (client)"
                items={[
                  { label: "Devis", value: devis?.nom_client || "Non détecté" },
                  { label: "Facture", value: facture?.nom_client || "Non détecté" },
                  { label: "Attestation Partie B", value: attestation?.attestation_parts?.part_b_company_info?.raison_sociale || "Non détecté" }
                ]}
              />
              
              {/* Cohérence adresses - Vérification adresse travaux vs adresse entreprise */}
              <AddressCoherenceSection
                title="Vérification de l'adresse des travaux"
                addresses={{
                  devisAdresseEntreprise: devis?.adresse_entreprise_client,
                  devisAdresseTravaux: devis?.adresse_travaux,
                  factureAdresseEntreprise: facture?.adresse_entreprise_client,
                  factureAdresseTravaux: facture?.adresse_travaux,
                }}
              />
            </div>
          </TabsContent>
          
          {/* Onglet Attestation CEE - Commenté mais code conservé pour usage futur */}
          {/* <TabsContent value="attestation-cee" className="space-y-6">
            <h3 className="text-lg font-medium">Analyse de l'attestation CEE</h3>
            
            {attestation && attestation.is_attestation_cee ? (
              <div className="space-y-6">
                <div className="bg-blue-50 p-4 rounded-md">
                  <div className="flex items-center mb-2">
                    <FileCheck className="mr-2 h-5 w-5 text-blue-600" />
                    <h4 className="text-lg font-medium text-blue-800">Certificat d'économies d'énergie</h4>
                  </div>
                  
                  <p className="text-sm text-blue-600 mb-4">
                    Le document a été identifié comme une attestation CEE / attestation sur l'honneur.
                  </p>
                  
                  <div className="grid grid-cols-1 gap-6">
                    <div className="border rounded-md overflow-hidden">
                      <div className={`p-3 ${attestation.attestation_parts?.part_a_present ? 'bg-green-100' : 'bg-gray-100'}`}>
                        <div className="flex justify-between items-center">
                          <h5 className="font-medium">PARTIE A - Informations générales et engagement</h5>
                          {attestation.attestation_parts?.part_a_present ? (
                            <Badge variant="outline" className="bg-green-600 text-white">Détectée</Badge>
                          ) : (
                            <Badge variant="destructive">Non détectée</Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="p-4">
                        {attestation.attestation_parts?.part_a_present ? (
                          <div className="space-y-4">
                            <div className="bg-gray-50 p-3 rounded-md">
                              <h6 className="text-sm font-medium mb-2">Dates importantes</h6>
                              {attestation.attestation_parts?.part_a_dates?.length > 0 ? (
                                <ul className="space-y-1">
                                  {attestation.attestation_parts.part_a_dates.map((date: string, i: number) => (
                                    <li key={i} className="text-sm flex items-center">
                                      <span className="w-2 h-2 rounded-full bg-blue-500 mr-2"></span>
                                      {date}
                                    </li>
                                  ))}
                                </ul>
                              ) : (
                                <p className="text-sm text-gray-500">Aucune date détectése</p>
                              )}
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center py-6 text-gray-500">
                            <AlertTriangle className="h-5 w-5 mr-2" />
                            <p>La partie A n'a pas été détectése dans le document</p>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="border rounded-md overflow-hidden">
                      <div className={`p-3 ${attestation.attestation_parts?.part_b_present ? 'bg-green-100' : 'bg-gray-100'}`}>
                        <div className="flex justify-between items-center">
                          <h5 className="font-medium">PARTIE B - bénéficiaire de l'opération</h5>
                          {attestation.attestation_parts?.part_b_present ? (
                            <Badge variant="outline" className="bg-green-600 text-white">Détectée</Badge>
                          ) : (
                            <Badge variant="destructive">Non détectée</Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="p-4">
                        {attestation.attestation_parts?.part_b_present ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <InfoItem label="Signature client" value={attestation.attestation_parts.part_b_signature_manuscrite ? "Présente" : "Non détectée"} variant={attestation.attestation_parts.part_b_signature_manuscrite ? "default" : "destructive"} />
                            <InfoItem label="Bon pour accord" value={attestation.bon_pour_accord ? "Présent" : "Non détecté"} variant={attestation.bon_pour_accord ? "default" : "destructive"} />
                            <InfoItem label="Lu et approuv" value={attestation.lu_et_approuve ? "Présent" : "Non détecté"} variant={attestation.lu_et_approuve ? "default" : "destructive"} />
                            <InfoItem label="Nom manuscrit" value={attestation.nom_manuscrit || "Non détecté"} />
                            <InfoItem label="Fonction manuscrite" value={attestation.fonction_manuscrite || "Non détectée"} />
                            <InfoItem label="Date manuscrite" value={attestation.date_manuscrite || "Non détectée"} />
                          </div>
                        ) : (
                          <div className="flex items-center justify-center py-6 text-gray-500">
                            <AlertTriangle className="h-5 w-5 mr-2" />
                            <p>La partie B n'a pas été détectése dans le document</p>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="border rounded-md overflow-hidden">
                      <div className={`p-3 ${attestation.attestation_parts?.part_c_present ? 'bg-green-100' : 'bg-gray-100'}`}>
                        <div className="flex justify-between items-center">
                          <h5 className="font-medium">PARTIE C - Professionnel</h5>
                          {attestation.attestation_parts?.part_c_present ? (
                            <Badge variant="outline" className="bg-green-600 text-white">Détectée</Badge>
                          ) : (
                            <Badge variant="destructive">Non détectée</Badge>
                          )}
                        </div>
                      </div>
                      
                      <div className="p-4">
                        {attestation.attestation_parts?.part_c_present ? (
                          <div className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <InfoItem label="Raison sociale" value={attestation.attestation_parts.part_c_company_info?.raison_sociale || "Non détecté"} />
                              <InfoItem label="SIRET" value={attestation.attestation_parts.part_c_company_info?.siret || "Non détecté"} />
                              <InfoItem label="Nom signataire" value={attestation.attestation_parts.part_c_company_info?.nom_signataire || "Non détecté"} />
                              <InfoItem label="Prénom signataire" value={attestation.attestation_parts.part_c_company_info?.prenom_signataire || "Non détecté"} />
                              <InfoItem label="Fonction signataire" value={attestation.attestation_parts.part_c_company_info?.fonction_signataire || "Non détectée"} />
                              <InfoItem label="Adresse" value={attestation.attestation_parts.part_c_company_info?.adresse || "Non détectée"} />
                              <InfoItem label="Signature" value={attestation.attestation_parts.part_c_signature_manuscrite ? "Présente" : "Non détectée"} variant={attestation.attestation_parts.part_c_signature_manuscrite ? "default" : "destructive"} />
                            </div>
                            
                            <CoherenceCheck 
                              title="Cohérence SIRET avec les autres documents"
                              isConsistent={!!attestation.attestation_parts.part_c_company_info?.siret && 
                                attestation.attestation_parts.part_c_company_info?.siret === devis?.siret_client}
                              details={`SIRET dans l'attestation (${attestation.attestation_parts.part_c_company_info?.siret || 'Non détecté'}) ${attestation.attestation_parts.part_c_company_info?.siret === devis?.siret_client ? 'correspond au' : 'diffère du'} SIRET du devis (${devis?.siret_client || 'Non détecté'})`}
                            />
                          </div>
                        ) : (
                          <div className="flex items-center justify-center py-6 text-gray-500">
                            <AlertTriangle className="h-5 w-5 mr-2" />
                            <p>La partie C n'a pas été détectése dans le document</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-md">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h4 className="text-xl font-medium text-gray-600 mb-2">Aucune attestation CEE détectée</h4>
                <p className="text-gray-500">
                  Le système n'a pas identifié de document attestation sur l'honneur ou certificat d'économies d'énergie.
                </p>
              </div>
            )}
          </TabsContent> */}
        </Tabs>
      </div>
    </div>
  );
};

// ManuscritSection a été déplacé vers src/components/manuscript/ManuscritSection.tsx`r`n// ManuscritItem a été déplacé vers src/components/ui/ManuscritItem.tsx
// InfoItem est importé depuis src/components/ui/InfoItem.tsx`r`n// CoherenceSection a été déplacé vers src/components/coherence/ (AddressCoherenceSection, DateCoherenceSection, SimpleCoherenceSection)`r`n// CoherenceCheck a été déplacé vers src/components/coherence/CoherenceCheck.tsx

export default PromptDetailsTable;

