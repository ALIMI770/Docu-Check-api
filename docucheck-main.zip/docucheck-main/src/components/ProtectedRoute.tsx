
import { useState, useEffect, useRef } from "react";
import { Navigate } from "react-router-dom";
import { Loader2 } from "lucide-react";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean | null>(null);
  const isMounted = useRef(true);
  
  useEffect(() => {
    // Set the mounted ref
    isMounted.current = true;
    
    // Safely check auth status with a small delay to avoid layout issues
    const timer = setTimeout(() => {
      try {
        if (isMounted.current) {
          const authStatus = localStorage.getItem("isLoggedIn") === "true";
          setIsLoggedIn(authStatus);
        }
      } catch (error) {
        console.error("Error checking auth status:", error);
        if (isMounted.current) {
          setIsLoggedIn(false);
        }
      }
    }, 300);
    
    // Clean up function
    return () => {
      isMounted.current = false;
      clearTimeout(timer);
    };
  }, []);
  
  // Render a loading state until we know the authentication status
  if (isLoggedIn === null) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-4"></div>
        <p className="text-gray-600">Chargement de l'application...</p>
      </div>
    );
  }
  
  // Redirect to login if not authenticated
  if (!isLoggedIn) {
    return <Navigate to="/login" replace />;
  }
  
  // Render children if authenticated
  return <>{children}</>;
};

export default ProtectedRoute;
