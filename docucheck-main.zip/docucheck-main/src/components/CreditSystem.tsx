
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, CreditCard } from 'lucide-react';
import { getAvailablePackages, StripePackage } from '@/services/stripeService';

interface CreditSystemProps {
  availableCredits: number;
  onPurchaseCredits: (packageId: string) => void;
}

const CreditSystem = ({ availableCredits, onPurchaseCredits }: CreditSystemProps) => {
  const creditPackages = getAvailablePackages();

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Crédits disponibles</h2>
          <Badge variant="default" className="text-md px-3 py-1 bg-blue-500">
            {availableCredits} crédits
          </Badge>
        </div>
        
        <p className="mt-2 text-gray-600">
          Chaque analyse consomme 1 crédit. Achetez des crédits supplémentaires pour analyser plus de dossiers.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {creditPackages.map((pkg) => (
          <Card 
            key={pkg.id} 
            className={`relative overflow-hidden ${pkg.mostPopular ? 'border-blue-500 border-2 shadow-lg' : ''}`}
          >
            {pkg.mostPopular && (
              <div className="absolute -top-2 -right-12 bg-blue-500 text-white py-1 px-10 transform rotate-45">
                Populaire
              </div>
            )}
            <CardHeader>
              <CardTitle>{pkg.name}</CardTitle>
              <CardDescription>{pkg.credits} crédits</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{pkg.price.toFixed(2)} €</p>
              <p className="text-sm text-gray-500 mb-2">
                {(pkg.price / pkg.credits).toFixed(2)} € par crédit
              </p>
              {pkg.description && (
                <p className="text-sm text-gray-600">{pkg.description}</p>
              )}
              
              <ul className="mt-4 space-y-2">
                <li className="flex items-center text-sm">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  Analyse détaillée
                </li>
                <li className="flex items-center text-sm">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  Accès aux résultats
                </li>
                {pkg.credits >= 50 && (
                  <li className="flex items-center text-sm">
                    <Check className="h-4 w-4 text-green-500 mr-2" />
                    Export PDF
                  </li>
                )}
                {pkg.credits >= 200 && (
                  <li className="flex items-center text-sm">
                    <Check className="h-4 w-4 text-green-500 mr-2" />
                    Support prioritaire
                  </li>
                )}
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full" 
                onClick={() => onPurchaseCredits(pkg.id)}
              >
                <CreditCard className="h-4 w-4 mr-2" />
                Acheter
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      
      <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
        <h3 className="text-lg font-semibold text-blue-700 mb-2">Comment fonctionne le système de crédits?</h3>
        <ul className="space-y-2 text-blue-600">
          <li className="flex items-start">
            <span className="bg-blue-100 rounded-full h-5 w-5 flex items-center justify-center text-blue-700 mr-2 mt-0.5">1</span>
            <p>Achetez un pack de crédits qui correspond à vos besoins</p>
          </li>
          <li className="flex items-start">
            <span className="bg-blue-100 rounded-full h-5 w-5 flex items-center justify-center text-blue-700 mr-2 mt-0.5">2</span>
            <p>Chaque analyse de dossier consomme 1 crédit, que ce soit en mode unitaire ou par lot</p>
          </li>
          <li className="flex items-start">
            <span className="bg-blue-100 rounded-full h-5 w-5 flex items-center justify-center text-blue-700 mr-2 mt-0.5">3</span>
            <p>Les crédits n'expirent pas tant que votre compte est actif</p>
          </li>
          <li className="flex items-start">
            <span className="bg-blue-100 rounded-full h-5 w-5 flex items-center justify-center text-blue-700 mr-2 mt-0.5">4</span>
            <p>Les utilisateurs professionnels peuvent demander une facture pour chaque achat</p>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default CreditSystem;
