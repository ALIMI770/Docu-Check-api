
import { CheckResult } from "@/types/document";
import { CheckCircle, AlertTriangle, XCircle, Check, FileText, MapPin, Calendar, AtSign, Users, Building, FileCheck, Stamp, BarChart2, File, Info } from "lucide-react";

interface CheckItemProps {
  check: CheckResult;
  showSection?: boolean;
}

export const StatusIcon = ({ status }: { status: CheckResult['status'] }) => {
  switch (status) {
    case "success":
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    case "warning":
      return <AlertTriangle className="h-5 w-5 text-amber-500" />;
    case "error":
      return <XCircle className="h-5 w-5 text-red-500" />;
    default:
      return null;
  }
};

export const DocumentIcon = ({ docType }: { docType: string }) => {
  const type = docType?.toLowerCase() || "";
  
  if (type.includes("devis")) {
    return <FileText className="h-4 w-4 text-blue-500" />;
  } else if (type.includes("facture")) {
    return <FileCheck className="h-4 w-4 text-green-500" />;
  } else if (type.includes("attestation")) {
    return <File className="h-4 w-4 text-purple-500" />;
  }
  
  return <File className="h-4 w-4 text-gray-500" />;
};

const getDocumentType = (checkName: string, details: string): string | null => {
  const checkNameLower = checkName.toLowerCase();
  const detailsLower = details.toLowerCase();
  
  // Chercher d'abord dans le nom du check
  if (checkNameLower.includes("devis")) return "devis";
  if (checkNameLower.includes("facture")) return "facture";
  if (checkNameLower.includes("attestation")) return "attestation";
  
  // Puis dans les détails
  if (detailsLower.includes("devis")) return "devis";
  if (detailsLower.includes("facture")) return "facture";
  if (detailsLower.includes("attestation")) return "attestation";
  
  return null;
};

// Déterminer la section de l'attestation (A, B, C)
const getAttestationSection = (checkName: string, details: string): string | null => {
  const lowerDetails = details.toLowerCase();
  const lowerName = checkName.toLowerCase();
  
  if (lowerName.includes("identification") || lowerName.includes("siret") || lowerDetails.includes("identification") || lowerDetails.includes("siret")) {
    return "A";
  } else if (lowerName.includes("manuscrit") || lowerName.includes("signature") || lowerDetails.includes("manuscrit") || lowerDetails.includes("signature")) {
    return "C";
  } else if (lowerName.includes("travaux") || lowerName.includes("adresse") || lowerDetails.includes("travaux") || lowerDetails.includes("adresse")) {
    return "B";
  }
  
  return null;
};

// Déterminer le niveau de fiabilité
const getReliabilityLevel = (check: CheckResult): { level: string, score: number } => {
  if (check.status === "success") {
    return { level: "Élevée", score: 90 };
  } else if (check.status === "warning") {
    return { level: "Moyenne", score: 70 };
  } else {
    return { level: "Faible", score: 30 };
  }
};

const CheckItem = ({ check, showSection = false }: CheckItemProps) => {
  const isGptVisionData = check.details?.includes('(GPT Vision)');
  const docType = getDocumentType(check.name, check.details);
  const section = showSection ? getAttestationSection(check.name, check.details) : null;
  const reliability = getReliabilityLevel(check);
  const isManuscript = check.details?.toLowerCase().includes('manuscrit') || check.name?.toLowerCase().includes('manuscrit');
  
  // Extraire des noms ou informations spécifiques du texte
  const extractName = (text: string): string | null => {
    const nameMatch = text.match(/nom\s*(?:\(|:)\s*["']?([^"'\)\]]+)["']?\)?/i);
    return nameMatch ? nameMatch[1].trim() : null;
  };
  
  const extractedName = extractName(check.details);

  return (
    <div 
      className={`p-3 rounded-md ${
        check.status === 'success' ? 'bg-green-50' :
        check.status === 'warning' ? 'bg-amber-50' : 'bg-red-50'
      }`}
    >
      <div className="flex items-start">
        <div className="mt-0.5 mr-3">
          <StatusIcon status={check.status} />
        </div>
        <div className="w-full">
          <div className="font-medium flex items-center flex-wrap gap-1">
            {check.name}
            
            {docType && (
              <span className="ml-2 mr-1 flex items-center text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">
                <DocumentIcon docType={docType} />
                <span className="ml-1 capitalize">{docType}</span>
              </span>
            )}
            
            {section && (
              <span className="ml-1 text-xs bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full">
                Partie {section}
              </span>
            )}
            
            {isManuscript && (
              <span className="ml-1 text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">
                Manuscrit
              </span>
            )}
            
            {isGptVisionData && (
              <span className="ml-1 text-xs bg-purple-100 text-purple-800 px-2 py-0.5 rounded-full">
                GPT Vision
              </span>
            )}
            
            <span className="ml-1 text-xs bg-gray-100 text-gray-800 px-2 py-0.5 rounded-full flex items-center">
              <Info className="h-3 w-3 mr-1" />
              Fiabilité: {reliability.level} ({reliability.score}%)
            </span>
          </div>
          
          <div className="text-sm mt-1 text-gray-600">{check.details}</div>
          
          {/* Informations extraites pour les mentions manuscrites */}
          {check.name.includes("Mentions manuscrites") && check.details.includes("(") && (
            <div className="mt-2">
              <div className="text-xs font-medium text-gray-500 mb-1">Éléments détectés par {isGptVisionData ? 'IA' : 'OCR'}:</div>
              <div className="grid grid-cols-2 gap-2">
                {check.details.includes("nom") && (
                  <div className="flex items-center">
                    <AtSign className="h-3 w-3 text-blue-500 mr-1" />
                    <span className="text-xs break-all">{check.details.match(/nom \(([^)]+)\)/)?.[1] || "Nom détecté"}</span>
                  </div>
                )}
                {check.details.includes("fonction") && (
                  <div className="flex items-center">
                    <Users className="h-3 w-3 text-green-500 mr-1" />
                    <span className="text-xs break-all">{check.details.match(/fonction \(([^)]+)\)/)?.[1] || "Fonction détectée"}</span>
                  </div>
                )}
                {check.details.includes("date") && (
                  <div className="flex items-center">
                    <Calendar className="h-3 w-3 text-amber-500 mr-1" />
                    <span className="text-xs">{check.details.match(/date \(([^)]+)\)/)?.[1] || "Date détectée"}</span>
                  </div>
                )}
                {(check.details.includes("bon pour accord") || check.details.includes("Bon pour accord")) && (
                  <div className="flex items-center">
                    <FileCheck className="h-3 w-3 text-blue-500 mr-1" />
                    <span className="text-xs">Mention "Bon pour accord" validée</span>
                  </div>
                )}
                {check.details.includes("signature") && (
                  <div className="flex items-center">
                    <Check className="h-3 w-3 text-green-500 mr-1" />
                    <span className="text-xs">Signature validée</span>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {/* Informations sur le nom reconnu */}
          {extractedName && (
            <div className="mt-2 bg-blue-50 p-2 rounded text-xs">
              <div className="font-medium">Nom reconnu:</div>
              <span className="ml-2">{extractedName}</span>
            </div>
          )}
          
          {/* Informations sur le tampon */}
          {check.name.includes("Tampon") && (
            <div className="mt-2">
              <div className="flex items-center mb-1">
                <Stamp className="h-4 w-4 text-blue-500 mr-1" />
                <span className="text-xs break-all font-medium">
                  {check.details.includes("'") 
                    ? `Tampon identifié: ${check.details.match(/'([^']+)'/)?.[1] || "Tampon détecté"}`
                    : (check.details.includes(":") 
                      ? check.details.split(":")[1]?.trim() 
                      : "Tampon d'entreprise détecté")
                  }
                </span>
              </div>
              
              {check.details.includes("SIRET") && (
                <div className="flex items-center mt-1">
                  <Building className="h-3 w-3 text-gray-500 mr-1" />
                  <span className="text-xs break-all">
                    {check.details.match(/SIRET[^0-9]*([0-9\s]+)/i)?.[1] || "SIRET détecté"}
                  </span>
                </div>
              )}
            </div>
          )}
          
          {/* Validation SIRENE */}
          {check.name === "Validation SIRENE" && check.status === "success" && (
            <div className="mt-2 bg-blue-50 p-2 rounded-md">
              <div className="text-xs font-medium text-blue-800 mb-1">Données INSEE vérifiées:</div>
              <div className="space-y-1">
                {check.details.includes("Entreprise:") && (
                  <div className="flex items-center">
                    <Building className="h-3 w-3 text-blue-500 mr-1" />
                    <span className="text-xs">
                      {check.details.match(/Entreprise: ([^,]+)/)?.[1] || "Entreprise validée"}
                    </span>
                  </div>
                )}
                {check.details.includes("Adresse:") && (
                  <div className="flex items-center">
                    <MapPin className="h-3 w-3 text-blue-500 mr-1" />
                    <span className="text-xs">
                      {check.details.match(/Adresse: ([^,]+)/)?.[1] || "Adresse validée"}
                    </span>
                  </div>
                )}
                {check.details.includes("Statut:") && (
                  <div className="flex items-center">
                    <BarChart2 className="h-3 w-3 text-blue-500 mr-1" />
                    <span className="text-xs">
                      {check.details.match(/Statut: ([^(]+)/)?.[1] || "Statut validé"}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {/* Informations sur les dates et la cohérence */}
          {check.name.includes("Date") && check.name !== "Validation SIRENE" && (
            <div className="mt-2">
              <div className="text-xs font-medium mb-1">Dates détectées:</div>
              <div className="flex flex-wrap gap-2">
                {check.details.match(/\d{1,2}\/\d{1,2}\/\d{4}/g)?.map((date, idx) => (
                  <span key={idx} className="inline-flex items-center px-2 py-1 rounded-sm text-xs bg-blue-50 text-blue-800">
                    <Calendar className="h-3 w-3 text-blue-500 mr-1" />
                    {date}
                  </span>
                )) || (
                  <span className="text-xs text-gray-500">Aucune date au format JJ/MM/AAAA détectée</span>
                )}
              </div>
              
              {/* Cohérence des dates */}
              {(check.details.includes("cohérent") || check.details.includes("cohérente")) && (
                <div className="mt-1 text-xs text-green-600">
                  <Check className="h-3 w-3 inline mr-1" />
                  Dates cohérentes
                </div>
              )}
            </div>
          )}
          
          {/* Adresse de réalisation */}
          {check.name === "Adresse de réalisation" && check.status === "success" && (
            <div className="mt-2 flex items-center">
              <MapPin className="h-4 w-4 text-red-500 mr-1" />
              <span className="text-xs break-all">
                {check.details.includes("'") 
                  ? `Adresse détectée: ${check.details.match(/'([^']+)'/)?.[1] || "Adresse validée"}`
                  : "Adresse validée"
                }
              </span>
            </div>
          )}
          
          {/* Références de dossier */}
          {check.name === "Références de dossier" && check.status === "success" && (
            <div className="mt-2 flex flex-wrap gap-2">
              {check.details.match(/\d{4}-\d{4}/g)?.map((ref, idx) => (
                <span key={idx} className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-blue-100 text-blue-800">
                  Réf: {ref}
                </span>
              ))}
            </div>
          )}

          {/* Vérification SIRET */}
          {check.name === "Vérification SIRET" && check.status === "success" && (
            <div className="mt-2 flex items-center">
              <Building className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-xs break-all">
                SIRET validé et cohérent avec le tampon
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CheckItem;
