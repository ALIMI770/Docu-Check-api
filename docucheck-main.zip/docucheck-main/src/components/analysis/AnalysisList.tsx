
import { CheckResult } from "@/types/document";
import CheckItem from "./CheckItem";

interface AnalysisListProps {
  checks: CheckResult[];
}

const AnalysisList = ({ checks }: AnalysisListProps) => {
  // Group checks by document type
  const documentGroups: Record<string, CheckResult[]> = {
    devis: [],
    facture: [],
    attestation: [],
    global: []
  };
  
  checks.forEach(check => {
    const name = check.name.toLowerCase();
    const details = check.details.toLowerCase();
    
    if (name.includes('devis') || details.includes('devis')) {
      documentGroups.devis.push(check);
    } else if (name.includes('facture') || details.includes('facture')) {
      documentGroups.facture.push(check);
    } else if (name.includes('attestation') || details.includes('attestation')) {
      documentGroups.attestation.push(check);
    } else {
      documentGroups.global.push(check);
    }
  });
  
  return (
    <div className="space-y-5">
      <h3 className="text-lg font-semibold mb-3">Détails de l'analyse</h3>
      
      {/* Devis */}
      {documentGroups.devis.length > 0 && (
        <div className="mb-5 border rounded-lg p-4 bg-blue-50/30">
          <h4 className="text-md font-medium mb-3 text-blue-700 border-b pb-2">Devis</h4>
          <div className="space-y-3">
            {documentGroups.devis.map((check, index) => (
              <CheckItem key={`devis-${index}`} check={check} />
            ))}
          </div>
        </div>
      )}
      
      {/* Facture */}
      {documentGroups.facture.length > 0 && (
        <div className="mb-5 border rounded-lg p-4 bg-green-50/30">
          <h4 className="text-md font-medium mb-3 text-green-700 border-b pb-2">Facture</h4>
          <div className="space-y-3">
            {documentGroups.facture.map((check, index) => (
              <CheckItem key={`facture-${index}`} check={check} />
            ))}
          </div>
        </div>
      )}
      
      {/* Attestation */}
      {documentGroups.attestation.length > 0 && (
        <div className="mb-5 border rounded-lg p-4 bg-purple-50/30">
          <h4 className="text-md font-medium mb-3 text-purple-700 border-b pb-2">Attestation sur l'honneur</h4>
          <div className="space-y-3">
            {documentGroups.attestation.map((check, index) => (
              <CheckItem key={`attestation-${index}`} check={check} showSection={true} />
            ))}
          </div>
        </div>
      )}
      
      {/* Vérifications globales */}
      {documentGroups.global.length > 0 && (
        <div className="mb-5 border rounded-lg p-4 bg-gray-50/30">
          <h4 className="text-md font-medium mb-3 text-gray-700 border-b pb-2">Cohérence globale du dossier</h4>
          <div className="space-y-3">
            {documentGroups.global.map((check, index) => (
              <CheckItem key={`global-${index}`} check={check} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AnalysisList;
