
import { Progress } from "@/components/ui/progress";

interface ScoreDisplayProps {
  score: number;
}

export const getScoreColor = (score: number) => {
  if (score >= 90) return "text-green-500";
  if (score >= 70) return "text-amber-500";
  return "text-red-500";
};

export const getProgressColor = (score: number) => {
  if (score >= 90) return "bg-green-500";
  if (score >= 70) return "bg-amber-500";
  return "bg-red-500";
};

const ScoreDisplay = ({ score }: ScoreDisplayProps) => {
  return (
    <div className="mt-4 flex items-center">
      <div className="w-24 h-24 rounded-full border-8 border-gray-100 flex items-center justify-center mr-4">
        <span className={`text-3xl font-bold ${getScoreColor(score)}`}>
          {score}%
        </span>
      </div>
      
      <div>
        <h3 className="font-medium text-lg">
          Score de conformité
        </h3>
        <p className="text-sm text-gray-600 mt-1">
          {score >= 90
            ? "Dossier conforme"
            : score >= 70
            ? "Conformité moyenne - corrections mineures requises"
            : "Dossier non conforme - corrections majeures requises"
          }
        </p>
        <div className="mt-2 w-full max-w-xs">
          <Progress 
            value={score} 
            className={`h-2 ${getProgressColor(score)}`} 
          />
        </div>
      </div>
    </div>
  );
};

export default ScoreDisplay;
