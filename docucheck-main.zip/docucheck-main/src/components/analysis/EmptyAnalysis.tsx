
const EmptyAnalysis = () => {
  return (
    <div className="bg-white rounded-lg shadow-md h-full flex flex-col">
      <div className="p-6 border-b">
        <h2 className="text-xl font-semibold">Analyse de documents CEE</h2>
        <p className="text-sm text-gray-500 mt-1">
          Téléchargez vos documents pour commencer l'analyse
        </p>
      </div>
      
      <div className="flex-1 p-6 flex flex-col gap-6">
        <div className="bg-blue-50 p-4 rounded-md border border-blue-200">
          <h3 className="font-medium text-blue-800 mb-2">Analyse intelligente de vos dossiers CEE</h3>
          <p className="text-sm text-blue-700 mb-4">
            Cette application utilise l'intelligence artificielle pour analyser automatiquement vos documents CEE.
            Téléchargez simplement votre PDF complet ou vos documents séparés pour commencer.
          </p>
        </div>
        
        <div>
          <h3 className="font-medium mb-2">Documents à préparer</h3>
          <ul className="list-disc pl-5 space-y-1 text-sm">
            <li>Devis signé avec mentions manuscrites et tampon</li>
            <li>Facture de fin de travaux</li>
            <li>Attestation sur l'honneur remplie et signée</li>
          </ul>
          <p className="text-xs text-gray-500 mt-3">
            Pour obtenir les meilleurs résultats, assurez-vous que vos documents sont lisibles et bien cadrés
          </p>
        </div>
      </div>
    </div>
  );
};

export default EmptyAnalysis;
