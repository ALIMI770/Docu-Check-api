
interface AnalysisRecommendationsProps {
  recommendations: string[];
}

const AnalysisRecommendations = ({ recommendations }: AnalysisRecommendationsProps) => {
  if (recommendations.length === 0) {
    return null;
  }
  
  return (
    <div className="mt-6">
      <h3 className="font-semibold mb-3">Recommandations</h3>
      <ul className="list-disc pl-5 space-y-2">
        {recommendations.map((rec, index) => (
          <li key={index} className="text-sm text-gray-700">{rec}</li>
        ))}
      </ul>
    </div>
  );
};

export default AnalysisRecommendations;
