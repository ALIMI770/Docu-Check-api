
import { Loader2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface AnalysisLoadingProps {
  processingStep: {step: number, message: string} | null;
}

const AnalysisLoading = ({ processingStep }: AnalysisLoadingProps) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 h-full flex flex-col items-center justify-center">
      <Loader2 className="h-8 w-8 text-primary animate-spin mb-4" />
      <h2 className="text-lg font-semibold">Analyse en cours</h2>
      <p className="text-gray-500 text-sm mt-2">
        L'IA analyse les documents avec OCR pour vérifier leur conformité...
      </p>
      <div className="w-full mt-6">
        <Progress value={processingStep ? (processingStep.step / 6) * 100 : 65} className="h-2" />
      </div>
      <div className="text-xs text-gray-400 mt-2">
        {processingStep 
          ? `Étape ${processingStep.step}/6: ${processingStep.message}`
          : "Extraction des éléments manuscrits, dates, signatures et tampons"
        }
      </div>
    </div>
  );
};

export default AnalysisLoading;
