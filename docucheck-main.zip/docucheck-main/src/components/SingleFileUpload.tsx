
import { useState } from "react";
import { Upload, CheckCircle, FileText } from "lucide-react";

interface SingleFileUploadProps {
  onFileUpload: (file: File) => void;
  disabled?: boolean;
}

const SingleFileUpload = ({ onFileUpload, disabled = false }: SingleFileUploadProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploaded, setIsUploaded] = useState(false);
  const [filename, setFilename] = useState<string | null>(null);
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (!disabled) {
      setIsDragging(true);
    }
  };
  
  const handleDragLeave = () => {
    setIsDragging(false);
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (disabled) return;
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type === 'application/pdf') {
        processFile(file);
      } else {
        alert("Seuls les fichiers PDF sont acceptés en mode dossier unique.");
      }
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (disabled) return;
    
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      if (file.type === 'application/pdf') {
        processFile(file);
      } else {
        alert("Seuls les fichiers PDF sont acceptés en mode dossier unique.");
      }
    }
  };
  
  const processFile = (file: File) => {
    setIsUploaded(true);
    setFilename(file.name);
    onFileUpload(file);
  };
  
  return (
    <div 
      className={`border-2 rounded-lg p-6 flex flex-col items-center justify-center transition-all ${
        disabled 
          ? "border-gray-200 bg-gray-100 cursor-not-allowed" 
          : isDragging 
            ? "border-primary border-dashed bg-primary/5" 
            : isUploaded 
              ? "border-green-500 bg-green-50" 
              : "border-dashed border-gray-300 hover:border-primary/60 hover:bg-primary/5 cursor-pointer"
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      style={{ minHeight: "200px" }}
    >
      <label htmlFor="single-file-upload" className={`w-full h-full flex flex-col items-center justify-center ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}>
        {isUploaded ? (
          <>
            <CheckCircle className="h-12 w-12 text-green-500 mb-3" />
            <p className="text-base font-medium text-green-700">Dossier PDF téléversé</p>
            {filename && <p className="text-sm text-green-600 mt-2">{filename}</p>}
            <p className="text-xs text-green-600 mt-4">
              Le dossier sera automatiquement analysé et séparé en documents individuels
            </p>
          </>
        ) : (
          <>
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <FileText className={`h-8 w-8 ${disabled ? 'text-gray-400' : 'text-primary'}`} />
            </div>
            
            <p className={`text-base font-medium mb-2 ${disabled ? 'text-gray-500' : ''}`}>
              Téléverser un dossier CEE complet (PDF)
            </p>
            
            <div className="flex flex-col items-center mt-2">
              <div className="flex items-center">
                <Upload className={`h-4 w-4 mr-1 ${disabled ? 'text-gray-400' : 'text-gray-500'}`} />
                <span className={`text-sm ${disabled ? 'text-gray-400' : 'text-gray-500'}`}>
                  {disabled ? 'Téléversement désactivé' : 'Glisser ou cliquer pour téléverser'}
                </span>
              </div>
              {!disabled && (
                <span className="text-xs text-gray-400 mt-1">
                  (Le fichier PDF peut contenir devis, facture, attestation et autres documents)
                </span>
              )}
            </div>
          </>
        )}
      </label>
      
      <input 
        type="file" 
        id="single-file-upload" 
        accept="application/pdf" 
        className="hidden" 
        onChange={handleFileChange}
        disabled={disabled}
      />
    </div>
  );
};

export default SingleFileUpload;
