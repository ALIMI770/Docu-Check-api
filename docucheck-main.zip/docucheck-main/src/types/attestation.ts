export interface AttestationParts {
  part_a_present?: boolean;
  part_a_dates?: Record<string, string>;
  part_b_present?: boolean;
  part_b_signature_manuscrite?: boolean;
  part_b_date_manuscrite?: string;
  part_b_company_info?: {
    nom_signataire?: string;
    prenom_signataire?: string;
    fonction_signataire?: string;
    raison_sociale?: string;
    siren?: string;
    adresse?: string;
  };
  part_c_present?: boolean;
  part_c_signature_manuscrite?: boolean;
  part_c_date_manuscrite?: string;
  part_c_company_info?: {
    nom_signataire?: string;
    prenom_signataire?: string;
    fonction_signataire?: string;
    raison_sociale?: string;
    siret?: string;
    adresse?: string;
  };
}

export interface FiabiliteManuscrits {
  signature?: number;
  tampon?: number;
  bon_pour_accord?: number;
  lu_et_approuve?: number;
  nom_manuscrit?: number;
  fonction_manuscrite?: number;
  date_manuscrite?: number;
}

export interface InfosTampon {
  nom?: string;
  adresse?: string;
  siret?: string;
}

export interface DocumentAnalysis {
  document_type?: string;
  is_attestation_cee?: boolean;
  attestation_parts?: AttestationParts;
  nom_client?: string;
  siret_client?: string;
  adresse_entreprise_client?: string;
  adresse_travaux?: string;
  date_emission?: string;
  amount_ttc?: string | number;
  tampon_present?: boolean;
  signature_manuscrite?: boolean;
  bon_pour_accord?: boolean;
  lu_et_approuve?: boolean;
  date_manuscrite?: string;
  nom_manuscrit?: string;
  fonction_manuscrite?: string;
  date_contrat?: string;
  nom_beneficiaire_contrat?: string;
  adresse_beneficiaire_contrat?: string;
  nom_entreprise_prestataire?: string;
  nom_representant_prestataire?: string;
  siret_prestataire?: string;
  adresse_prestataire?: string;
  date_signature?: string;
  nom_beneficiaire?: string;
  siren_beneficiaire?: string;
  adresse_beneficiaire?: string;
  nom_entreprise_oblige?: string;
  siret_oblige?: string;
  adresse_oblige?: string;
  nom_societe_signataire?: string;
  nom_signataire?: string;
  fonction_signataire?: string;
  infos_tampons?: InfosTampon[];
  infos_tampon?: InfosTampon;
  fiabilite_manuscrits?: FiabiliteManuscrits;
}

export interface DocumentPage {
  analysis: DocumentAnalysis;
  pageNumber?: number;
}

export interface DocumentData {
  pages: DocumentPage[];
  type?: string;
}
