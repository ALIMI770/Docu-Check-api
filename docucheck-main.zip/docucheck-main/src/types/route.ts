
export interface Appointment {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  time?: string;
  duration?: number; // en minutes
  notes?: string;
  teamId?: string; // Ajout de l'ID de l'équipe
}

export interface Waypoint {
  name: string;
  lat: number;
  lng: number;
  originalIndex: number;
}

export interface OptimizedRoute {
  waypoints: Waypoint[];
  distance: number; // en mètres
  duration: number; // en secondes
  routeGeometry: any; // les coordonnées de l'itinéraire pour l'affichage sur la carte
}

export interface Team {
  id: string;
  name: string;
  phoneNumber: string;
}
