
// Déclaration de type pour Leaflet ajouté à l'objet window global
interface Window {
  L: any;
}
