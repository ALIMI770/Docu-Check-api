/* eslint-disable @typescript-eslint/no-explicit-any */

export type DocumentType = "devis" | "facture" | "attestation";

export interface DocumentStatus {
  uploaded: boolean;
  file: File | null;
  preview: string | null;
}

export type StatusType = "success" | "warning" | "error";

export interface CheckResult {
  name: string;
  status: StatusType;
  details: string;
}

export interface AnalysisResult {
  score: number;
  timestamp: string;
  checks: CheckResult[];
  recommendations: string[];
  siretFound?: string;
  error?: string;
  rawResults?: any;
}

export interface OcrParams {
  threshold?: number;
  language?: string;
  apiKey?: string;
}
