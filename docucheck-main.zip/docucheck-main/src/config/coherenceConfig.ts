/**
 * Configuration et utilitaires pour la vérification de cohérence des documents
 * Contient les fonctions de normalisation, parsing et validation
 */

// ==================== INTERFACES ====================

export interface CoherenceItem {
  label: string;
  value: string;
}

export interface DateValidationResult {
  isConsistent: boolean;
  errors: string[];
  success: string[];
}

// ==================== UTILITAIRES ADRESSES ====================

/**
 * Normalise une adresse pour la comparaison
 * @param addr - Adresse à normaliser
 * @returns Adresse normalisée en minuscules sans caractères spéciaux
 */
export function normalizeAddress(addr?: string): string {
  if (!addr) return "";
  return addr
    .toLowerCase()
    .replace(/[,\-./\\]/g, " ")  // Remplace virgules, tirets, points, slashes par espaces
    .replace(/\s+/g, " ")         // Remplace espaces multiples par un seul
    .replace(/[^\w\s]/g, "")      // Supprime tous les caractères spéciaux sauf lettres, chiffres, espaces
    .trim();
}

/**
 * Vérifie si une adresse contient les informations essentielles
 * @param addr - Adresse à vérifier
 * @returns true si l'adresse contient un code postal et au moins 3 mots
 */
export function hasEssentialInfo(addr?: string): boolean {
  if (!addr) return false;
  const normalized = normalizeAddress(addr);
  // Vérifier la présence d'un code postal français (5 chiffres)
  const hasPostalCode = /\d{5}/.test(normalized);
  // Vérifier qu'il y a au moins 3 mots (rue, code postal, ville)
  const wordCount = normalized.split(/\s+/).filter(w => w.length > 0).length;
  return hasPostalCode && wordCount >= 3;
}

/**
 * Vérifie si deux adresses sont équivalentes
 * @param addr1 - Première adresse
 * @param addr2 - Seconde adresse
 * @returns true si les adresses sont considérées comme équivalentes
 */
export function areAddressesEquivalent(addr1?: string, addr2?: string): boolean {
  if (!addr1 || !addr2) return false;
  
  const norm1 = normalizeAddress(addr1);
  const norm2 = normalizeAddress(addr2);
  
  // Si identiques après normalisation
  if (norm1 === norm2) return true;
  
  // Vérifier que les deux ont les infos essentielles
  if (!hasEssentialInfo(addr1) || !hasEssentialInfo(addr2)) return false;
  
  // Extraire le code postal et la ville
  const postalCodeRegex = /\b(\d{5})\s+([a-z\s]+?)(?:\s|$)/;
  const match1 = norm1.match(postalCodeRegex);
  const match2 = norm2.match(postalCodeRegex);
  
  if (!match1 || !match2) return false;
  
  const postalCode1 = match1[1];
  const postalCode2 = match2[1];
  const city1 = match1[2].trim();
  const city2 = match2[2].trim();
  
  // Les codes postaux et villes doivent correspondre
  if (postalCode1 !== postalCode2 || city1 !== city2) return false;
  
  // Extraire la partie "rue/adresse" (avant le code postal)
  const street1 = norm1.split(postalCode1)[0].trim();
  const street2 = norm2.split(postalCode2)[0].trim();
  
  // Si l'une des adresses est incluse dans l'autre (la rue)
  return street1.includes(street2) || street2.includes(street1);
}

// ==================== UTILITAIRES DATES ====================

/**
 * Parse une chaîne de date en objet Date
 * @param str - Chaîne de date à parser (formats: YYYY-MM-DD, DD/MM/YYYY, ou format standard)
 * @returns Date parsée ou null si invalide
 */
export function parseDate(str?: string): Date | null {
  if (!str) return null;
  if (/^\d{4}-\d{2}-\d{2}/.test(str)) return new Date(str);
  if (/^\d{2}\/\d{2}\/\d{4}/.test(str)) {
    const [d, m, y] = str.split("/");
    return new Date(`${y}-${m}-${d}`);
  }
  const d = new Date(str);
  return isNaN(d.getTime()) ? null : d;
}

/**
 * Valide la cohérence des dates entre documents
 * @param dates - Objet contenant toutes les dates à valider
 * @returns Résultat de validation avec indicateur de cohérence et messages
 */
export function validateDateCoherence(dates: {
  devisDate?: string;
  devisSignatureDate?: string;
  factureDate?: string;
  attestationEngagementDate?: string;
  attestationRealisationDate?: string;
  attestationPartBSignatureDates?: string[];
  attestationPartCSignatureDates?: string[];
}): DateValidationResult {
  const {
    devisDate,
    devisSignatureDate,
    factureDate,
    attestationEngagementDate,
    attestationRealisationDate,
    attestationPartBSignatureDates = [],
    attestationPartCSignatureDates = []
  } = dates;

  const dDevis = parseDate(devisDate);
  const dSignature = parseDate(devisSignatureDate);
  const dFacture = parseDate(factureDate);
  const dEngagement = parseDate(attestationEngagementDate);
  const dRealisation = parseDate(attestationRealisationDate);

  let isConsistent = true;
  const errors: string[] = [];
  const success: string[] = [];

  // Validation 1: Date devis <= Date signature devis
  if (dDevis && dSignature && dDevis > dSignature) {
    isConsistent = false;
    errors.push("La date du devis doit précéder ou être égale à la date de signature du devis.");
  } else if (dDevis && dSignature) {
    success.push("La date du devis précède ou est égale à la date de signature du devis.");
  }

  // Validation 2: Date signature devis <= Date facture
  if (dSignature && dFacture && dSignature > dFacture) {
    isConsistent = false;
    errors.push("La date de signature du devis doit précéder ou être égale à la date de la facture.");
  } else if (dSignature && dFacture) {
    success.push("La date de signature du devis précède ou est égale à la date de la facture.");
  }

  // Validation 3: Date engagement attestation == Date signature devis
  if (dEngagement && dSignature && dEngagement.getTime() !== dSignature.getTime()) {
    isConsistent = false;
    errors.push("La date d'engagement de l'attestation (Partie A) doit être identique à la date de signature du devis.");
  } else if (dEngagement && dSignature && dEngagement.getTime() === dSignature.getTime()) {
    success.push("La date d'engagement de l'attestation (Partie A) est identique à la date de signature du devis.");
  }

  // Validation 4: Date réalisation attestation == Date facture
  if (dRealisation && dFacture && dRealisation.getTime() !== dFacture.getTime()) {
    isConsistent = false;
    errors.push("La date de réalisation de l'attestation (Partie A) doit être identique à la date de la facture.");
  } else if (dRealisation && dFacture && dRealisation.getTime() === dFacture.getTime()) {
    success.push("La date de réalisation de l'attestation (Partie A) est identique à la date de la facture.");
  }

  // Validation 5: Dates manuscrites Partie B == Date facture
  attestationPartBSignatureDates.forEach((date) => {
    const d = parseDate(date);
    if (d && dFacture && d.getTime() !== dFacture.getTime()) {
      isConsistent = false;
      errors.push(`La date manuscrite de la Partie B (${date}) doit être identique à la date de la facture (${factureDate}).`);
    } else if (d && dFacture && d.getTime() === dFacture.getTime()) {
      success.push(`La date manuscrite de la Partie B (${date}) est identique à la date de la facture.`);
    }
  });

  // Validation 6: Dates manuscrites Partie C == Date facture
  attestationPartCSignatureDates.forEach((date) => {
    const d = parseDate(date);
    if (d && dFacture && d.getTime() !== dFacture.getTime()) {
      isConsistent = false;
      errors.push(`La date manuscrite de la Partie C (${date}) doit être identique à la date de la facture (${factureDate}).`);
    } else if (d && dFacture && d.getTime() === dFacture.getTime()) {
      success.push(`La date manuscrite de la Partie C (${date}) est identique à la date de la facture.`);
    }
  });

  return { isConsistent, errors, success };
}

// ==================== UTILITAIRES SIRET ====================

/**
 * Valide la cohérence des SIRET entre documents
 * @param devisSiret - SIRET du devis
 * @param factureSiret - SIRET de la facture
 * @param attestationSiren - SIREN de l'attestation
 * @returns true si les SIRET sont cohérents
 */
export function validateSiretCoherence(
  devisSiret?: string,
  factureSiret?: string,
  attestationSiren?: string
): boolean {
  let isConsistent = true;

  if (devisSiret && devisSiret !== "Non détecté") {
    if (factureSiret && factureSiret !== "Non détecté") {
      isConsistent = isConsistent && (devisSiret === factureSiret);
    }
  }

  if (attestationSiren && attestationSiren !== "Non détecté") {
    if (devisSiret && devisSiret !== "Non détecté") {
      isConsistent = isConsistent && (devisSiret.substring(0, 9) === attestationSiren);
    }
    if (factureSiret && factureSiret !== "Non détecté") {
      isConsistent = isConsistent && (factureSiret.substring(0, 9) === attestationSiren);
    }
  }

  return isConsistent;
}

/**
 * Détermine la couleur à appliquer à un item SIRET selon sa cohérence
 * @param itemIndex - Index de l'item (0=devis, 1=facture, 2=attestation)
 * @param items - Tableau des items [devis, facture, attestation]
 * @returns Classe CSS pour la couleur du texte
 */
export function getSiretItemColor(itemIndex: number, items: CoherenceItem[]): string {
  if (items.length !== 3) return "";

  const item = items[itemIndex];
  if (item.value === "Non détecté" || item.value === "Non détectée") {
    return "text-red-600";
  }

  const devisSiret = items[0].value;
  const factureSiret = items[1].value;
  const attestationSiren = items[2].value;

  if (itemIndex === 0) { // Devis
    if (factureSiret !== "Non détecté" && devisSiret !== factureSiret) return "text-red-600";
    if (attestationSiren !== "Non détecté" && devisSiret.substring(0, 9) !== attestationSiren) return "text-red-600";
  }
  if (itemIndex === 1) { // Facture
    if (devisSiret !== "Non détecté" && factureSiret !== devisSiret) return "text-red-600";
    if (attestationSiren !== "Non détecté" && factureSiret.substring(0, 9) !== attestationSiren) return "text-red-600";
  }
  if (itemIndex === 2) { // Attestation SIREN
    if (devisSiret !== "Non détecté" && devisSiret.substring(0, 9) !== attestationSiren) return "text-red-600";
    if (factureSiret !== "Non détecté" && factureSiret.substring(0, 9) !== attestationSiren) return "text-red-600";
  }

  return "";
}

// ==================== UTILITAIRES GÉNÉRIQUES ====================

/**
 * Valide la cohérence d'une liste de valeurs (montants, noms, etc.)
 * @param items - Liste des items à comparer
 * @returns true si tous les items non vides ont la même valeur
 */
export function validateSimpleCoherence(items: CoherenceItem[]): boolean {
  const nonEmptyValues = items
    .map(item => item.value)
    .filter(value => value !== "Non détecté" && value !== "Non détectée");

  return nonEmptyValues.length === 0 ||
    nonEmptyValues.every(value => value === nonEmptyValues[0]);
}

/**
 * Détermine la couleur à appliquer à un item selon sa cohérence
 * @param item - Item à évaluer
 * @param items - Tous les items de la section
 * @param isConsistent - Indicateur global de cohérence
 * @returns Classe CSS pour la couleur du texte
 */
export function getSimpleItemColor(
  item: CoherenceItem,
  items: CoherenceItem[],
  isConsistent: boolean
): string {
  // Si la valeur est "Non détecté" ou "Non détectée", en rouge
  if (item.value === "Non détecté" || item.value === "Non détectée") {
    return "text-red-600";
  }

  // Si tout est cohérent, en noir
  if (isConsistent) {
    return "";
  }

  // Pour les autres types (montants, noms), si la valeur diffère de la référence
  const nonEmptyValues = items
    .map(i => i.value)
    .filter(value => value !== "Non détecté" && value !== "Non détectée");

  if (nonEmptyValues.length > 0 && item.value !== nonEmptyValues[0]) {
    return "text-red-600";
  }

  return "";
}
