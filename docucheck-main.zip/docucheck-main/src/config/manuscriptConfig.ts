/* eslint-disable @typescript-eslint/no-explicit-any */

import { DocumentPage } from '@/types/attestation';

/**
 * Configuration d'un élément manuscrit
 */
export interface ManuscriptElement {
  key: string;
  icon: string;
  label: string;
  present: boolean;
  score?: number;
  value?: string;
  detailsData?: {
    nom?: string;
    adresse?: string;
    siret?: string;
  };
}

/**
 * Options pour l'extraction des éléments manuscrits
 */
export interface ManuscriptExtractionOptions {
  usePartBSignature?: boolean;
  usePartCSignature?: boolean;
}

/**
 * Obtenir la couleur du badge selon le score de confiance
 */
export const getScoreBadgeColor = (score?: number): string => {
  if (!score || score === 0) return "bg-gray-100 text-gray-800";
  if (score >= 80) return "bg-green-100 text-green-800";
  if (score >= 60) return "bg-yellow-100 text-yellow-800";
  if (score >= 40) return "bg-orange-100 text-orange-800";
  return "bg-red-100 text-red-800";
};

/**
 * Extraire le premier score valide d'une liste de pages
 */
const extractFirstValidScore = (pages: any[], field: string): number | undefined => {
  return pages
    .map(p => p.analysis.fiabilite_manuscrits?.[field])
    .filter(s => s !== undefined && s !== null && s !== '' && s !== 0)[0];
};

/**
 * Déterminer quelle signature utiliser selon les options
 */
const getSignaturePresent = (
  page: any,
  options: ManuscriptExtractionOptions
): boolean => {
  if (options.usePartBSignature) {
    return page.analysis.attestation_parts?.part_b_signature_manuscrite;
  }
  if (options.usePartCSignature) {
    return page.analysis.attestation_parts?.part_c_signature_manuscrite;
  }
  return page.analysis.signature_manuscrite;
};

/**
 * Extraire les informations de tampon
 */
const extractTamponDetails = (pages: any[]): { nom?: string; adresse?: string; siret?: string } | undefined => {
  const pageWithInfos = pages.find(p => {
    const infos = p.analysis.infos_tampon;
    return infos && (infos.nom || infos.adresse || infos.siret);
  });
  
  return pageWithInfos?.analysis.infos_tampon;
};

/**
 * Extraire la valeur de la date manuscrite selon les options
 */
const extractDateValue = (
  pages: any[],
  options: ManuscriptExtractionOptions
): string | undefined => {
  const page = pages.find(p => 
    p.analysis.date_manuscrite ||
    (options.usePartBSignature && p.analysis.attestation_parts?.part_b_date_manuscrite) ||
    (options.usePartCSignature && p.analysis.attestation_parts?.part_c_date_manuscrite)
  );
  
  if (!page) return undefined;
  
  if (page.analysis.date_manuscrite) return page.analysis.date_manuscrite;
  
  if (options.usePartBSignature) {
    const partBPage = pages.find(p => p.analysis.attestation_parts?.part_b_date_manuscrite);
    if (partBPage) return partBPage.analysis.attestation_parts.part_b_date_manuscrite;
  }
  
  if (options.usePartCSignature) {
    const partCPage = pages.find(p => p.analysis.attestation_parts?.part_c_date_manuscrite);
    if (partCPage) return partCPage.analysis.attestation_parts.part_c_date_manuscrite;
  }
  
  return undefined;
};

/**
 * Extraire tous les éléments manuscrits depuis les pages
 */
export const extractManuscriptElements = (
  pages: any[],
  options: ManuscriptExtractionOptions = {}
): ManuscriptElement[] => {
  // Si on traite la partie B de l'attestation
  if (options.usePartBSignature) {
    return [
      {
        key: 'part_b_signature',
        icon: '✍️',
        label: 'Signature Partie B',
        present: pages.some(p => p.analysis.attestation_parts?.part_b_signature_manuscrite),
        score: extractFirstValidScore(pages, 'signature'),
      },
      {
        key: 'part_b_date',
        icon: '📅',
        label: 'Date manuscrite Partie B',
        present: pages.some(p => p.analysis.attestation_parts?.part_b_date_manuscrite),
        score: extractFirstValidScore(pages, 'date_manuscrite'),
        value: pages.find(p => p.analysis.attestation_parts?.part_b_date_manuscrite)?.analysis.attestation_parts.part_b_date_manuscrite,
      },
    ].filter(element => element.present); // Retourner uniquement les éléments présents
  }
  
  // Si on traite la partie C de l'attestation
  if (options.usePartCSignature) {
    return [
      {
        key: 'part_c_signature',
        icon: '✍️',
        label: 'Signature Partie C',
        present: pages.some(p => p.analysis.attestation_parts?.part_c_signature_manuscrite),
        score: extractFirstValidScore(pages, 'signature'),
      },
      {
        key: 'part_c_date',
        icon: '📅',
        label: 'Date manuscrite Partie C',
        present: pages.some(p => p.analysis.attestation_parts?.part_c_date_manuscrite),
        score: extractFirstValidScore(pages, 'date_manuscrite'),
        value: pages.find(p => p.analysis.attestation_parts?.part_c_date_manuscrite)?.analysis.attestation_parts.part_c_date_manuscrite,
      },
    ].filter(element => element.present); // Retourner uniquement les éléments présents
  }
  
  // Sinon, éléments manuscrits génériques (pour partie A et documents normaux)
  return [
    {
      key: 'tampon',
      icon: '🏢',
      label: 'Tampon entreprise',
      present: pages.some(p => p.analysis.tampon_present),
      score: extractFirstValidScore(pages, 'tampon'),
      detailsData: extractTamponDetails(pages)
    },
    {
      key: 'signature',
      icon: '✍️',
      label: 'Signature manuscrite',
      present: pages.some(p => getSignaturePresent(p, options)),
      score: extractFirstValidScore(pages, 'signature'),
    },
    {
      key: 'bon_pour_accord',
      icon: '✅',
      label: 'Bon pour accord',
      present: pages.some(p => p.analysis.bon_pour_accord),
      score: extractFirstValidScore(pages, 'bon_pour_accord'),
    },
    {
      key: 'lu_et_approuve',
      icon: '📖',
      label: 'Lu et approuvé',
      present: pages.some(p => p.analysis.lu_et_approuve),
      score: extractFirstValidScore(pages, 'lu_et_approuve'),
    },
    {
      key: 'nom_manuscrit',
      icon: '👤',
      label: 'Nom manuscrit',
      present: pages.some(p => p.analysis.nom_manuscrit),
      score: extractFirstValidScore(pages, 'nom_manuscrit'),
      value: pages.find(p => p.analysis.nom_manuscrit)?.analysis.nom_manuscrit,
    },
    {
      key: 'fonction_manuscrite',
      icon: '💼',
      label: 'Fonction manuscrite',
      present: pages.some(p => p.analysis.fonction_manuscrite),
      score: extractFirstValidScore(pages, 'fonction_manuscrite'),
      value: pages.find(p => p.analysis.fonction_manuscrite)?.analysis.fonction_manuscrite,
    },
    {
      key: 'date_manuscrite',
      icon: '📅',
      label: 'Date manuscrite',
      present: pages.some(p => 
        p.analysis.date_manuscrite || 
        (options.usePartBSignature && p.analysis.attestation_parts?.part_b_date_manuscrite) ||
        (options.usePartCSignature && p.analysis.attestation_parts?.part_c_date_manuscrite)
      ),
      score: extractFirstValidScore(pages, 'date_manuscrite'),
      value: extractDateValue(pages, options),
    },
  ].filter(element => element.present); // Retourner uniquement les éléments présents
};

/**
 * Vérifier si une page contient des éléments manuscrits
 */
export const hasManuscriptElements = (
  page: any,
  options: ManuscriptExtractionOptions = {}
): boolean => {
  // Si on cherche des éléments de la partie B spécifiquement
  if (options.usePartBSignature) {
    return page.analysis.attestation_parts?.part_b_signature_manuscrite ||
           page.analysis.attestation_parts?.part_b_date_manuscrite;
  }
  
  // Si on cherche des éléments de la partie C spécifiquement
  if (options.usePartCSignature) {
    return page.analysis.attestation_parts?.part_c_signature_manuscrite ||
           page.analysis.attestation_parts?.part_c_date_manuscrite;
  }
  
  // Sinon, chercher les éléments manuscrits génériques
  return getSignaturePresent(page, options) || 
         page.analysis.tampon_present || 
         page.analysis.bon_pour_accord ||
         page.analysis.lu_et_approuve ||
         page.analysis.nom_manuscrit ||
         page.analysis.fonction_manuscrite ||
         page.analysis.date_manuscrite;
};
