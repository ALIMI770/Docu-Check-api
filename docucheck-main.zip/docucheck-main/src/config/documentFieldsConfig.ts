/* eslint-disable @typescript-eslint/no-explicit-any */

/**
 * Configuration des champs à afficher pour chaque type de document
 */

export interface DocumentField {
  key: string;
  label: string;
  format?: (value: any) => string;
}

export interface DocumentFieldsConfig {
  generalFields: DocumentField[];
  manuscriptFields: DocumentField[];
}

/**
 * Configuration des champs pour le type DEVIS
 */
export const DEVIS_FIELDS: DocumentFieldsConfig = {
  generalFields: [
    { key: 'document_type', label: 'Type de document' },
    { key: 'nom_client', label: 'Nom du client' },
    { key: 'siret_client', label: 'SIRET client' },
    { key: 'adresse_entreprise_client', label: 'Adresse entreprise client' },
    { key: 'adresse_travaux', label: 'Adresse des travaux' },
    { key: 'date_emission', label: "Date d'émission" },
    { key: 'amount_ht', label: 'Montant HT', format: (v) => v ? `${v} €` : 'Non détecté' },
    { key: 'taux_tva', label: 'Taux de TVA', format: (v) => v ? `${v} %` : 'Non détecté' },
    { key: 'amount_ttc', label: 'Montant TTC', format: (v) => v ? `${v} €` : 'Non détecté' },
  ],
  manuscriptFields: [
    { key: 'tampon_present', label: "Tampon d'entreprise" },
    { key: 'signature_manuscrite', label: 'Signature manuscrite' },
    { key: 'bon_pour_accord', label: 'Bon pour accord' },
    { key: 'lu_et_approuve', label: 'Lu et approuvé' },
    { key: 'date_manuscrite', label: 'Date manuscrite' },
    { key: 'nom_manuscrit', label: 'Nom manuscrit' },
    { key: 'fonction_manuscrite', label: 'Fonction manuscrite' },
  ],
};

/**
 * Configuration des champs pour le type FACTURE
 */
export const FACTURE_FIELDS: DocumentFieldsConfig = {
  generalFields: [
    { key: 'document_type', label: 'Type de document' },
    { key: 'nom_client', label: 'Nom du client' },
    { key: 'siret_client', label: 'SIRET client' },
    { key: 'adresse_entreprise_client', label: 'Adresse entreprise client' },
    { key: 'adresse_travaux', label: 'Adresse des travaux' },
    { key: 'date_emission', label: "Date d'émission" },
    { key: 'amount_ht', label: 'Montant HT', format: (v) => v ? `${v} €` : 'Non détecté' },
    { key: 'taux_tva', label: 'Taux de TVA', format: (v) => v ? `${v} %` : 'Non détecté' },
    { key: 'amount_ttc', label: 'Montant TTC', format: (v) => v ? `${v} €` : 'Non détecté' },
  ],
  manuscriptFields: [
    { key: 'tampon_present', label: "Tampon d'entreprise" },
    { key: 'signature_manuscrite', label: 'Signature manuscrite' },
    { key: 'bon_pour_accord', label: 'Bon pour accord' },
    { key: 'lu_et_approuve', label: 'Lu et approuvé' },
    { key: 'date_manuscrite', label: 'Date manuscrite' },
    { key: 'nom_manuscrit', label: 'Nom manuscrit' },
    { key: 'fonction_manuscrite', label: 'Fonction manuscrite' },
  ],
};

/**
 * Configuration des champs pour le type CONTRAT
 */
export const CONTRAT_FIELDS: DocumentFieldsConfig = {
  generalFields: [
    { key: 'document_type', label: 'Type de document' },
    { key: 'date_contrat', label: 'Date du contrat' },
    { key: 'nom_beneficiaire_contrat', label: 'Nom bénéficiaire' },
    { key: 'adresse_beneficiaire_contrat', label: 'Adresse bénéficiaire' },
    { key: 'nom_entreprise_prestataire', label: 'Nom entreprise prestataire' },
    { key: 'nom_representant_prestataire', label: 'Nom représentant prestataire' },
    { key: 'siret_prestataire', label: 'SIRET prestataire' },
    { key: 'adresse_prestataire', label: 'Adresse prestataire' },
    { key: 'date_signature', label: 'Date de signature' },
    { key: 'amount_ttc', label: 'Montant TTC', format: (v) => v ? `${v} €` : 'Non détecté' },
  ],
  manuscriptFields: [
    { key: 'tampon_present', label: "Tampon d'entreprise" },
    { key: 'signature_manuscrite', label: 'Signature manuscrite' },
    { key: 'bon_pour_accord', label: 'Bon pour accord' },
    { key: 'lu_et_approuve', label: 'Lu et approuvé' },
    { key: 'date_manuscrite', label: 'Date manuscrite' },
    { key: 'nom_manuscrit', label: 'Nom manuscrit' },
    { key: 'fonction_manuscrite', label: 'Fonction manuscrite' },
  ],
};

/**
 * Configuration des champs pour le type INCITATION FINANCIERE
 */
export const INCITATION_FIELDS: DocumentFieldsConfig = {
  generalFields: [
    { key: 'document_type', label: 'Type de document' },
    { key: 'nom_beneficiaire', label: 'Nom bénéficiaire' },
    { key: 'siren_beneficiaire', label: 'SIREN bénéficiaire' },
    { key: 'adresse_beneficiaire', label: 'Adresse bénéficiaire' },
    { key: 'adresse_travaux', label: 'Adresse des travaux' },
    { key: 'nom_entreprise_oblige', label: 'Nom entreprise obligé' },
    { key: 'siret_oblige', label: 'SIRET obligé' },
    { key: 'adresse_oblige', label: 'Adresse obligé' },
    { key: 'nom_societe_signataire', label: 'Nom société signataire' },
    { key: 'nom_signataire', label: 'Nom signataire' },
    { key: 'fonction_signataire', label: 'Fonction signataire' },
    { key: 'amount_ttc', label: 'Montant TTC', format: (v) => v ? `${v} €` : 'Non détecté' },
  ],
  manuscriptFields: [
    { key: 'signature_manuscrite', label: 'Signature manuscrite' },
    { key: 'bon_pour_accord', label: 'Bon pour accord' },
    { key: 'lu_et_approuve', label: 'Lu et approuvé' },
    { key: 'date_manuscrite', label: 'Date manuscrite' },
    { key: 'nom_manuscrit', label: 'Nom manuscrit' },
    { key: 'fonction_manuscrite', label: 'Fonction manuscrite' },
  ],
};

/**
 * Retourne la configuration des champs selon le type de document
 */
export function getFieldsConfigByDocumentType(title: string): DocumentFieldsConfig | null {
  const lowerTitle = title.toLowerCase();
  
  if (lowerTitle.includes('devis')) return DEVIS_FIELDS;
  if (lowerTitle.includes('facture')) return FACTURE_FIELDS;
  if (lowerTitle.includes('contrat') || lowerTitle.includes('partenariat')) return CONTRAT_FIELDS;
  if (lowerTitle.includes('incitation') || lowerTitle.includes('financière')) return INCITATION_FIELDS;
  
  return null;
}
