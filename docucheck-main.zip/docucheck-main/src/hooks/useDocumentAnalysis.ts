/* eslint-disable @typescript-eslint/no-explicit-any */

import { useMemo } from 'react';
import { AnalysisResult } from '@/types/document';
import {
  createDocumentSynthesis,
  extractDocumentsByType,
  groupPagesByDocument,
  extractAttestationSignatureDates
} from '@/utils/dataProcessing';
import { logger } from '@/utils/logger';

/**
 * Interface pour les données traitées retournées par le hook
 */
export interface ProcessedDocumentData {
  documentsSynthese: any[];
  devis: any;
  facture: any;
  attestation: any;
  groupedPages: any[];
  attestationPartBSignatureDates: string[];
  attestationPartCSignatureDates: string[];
  originalDocuments: any[];
}

/**
 * Hook personnalisé pour traiter et organiser les données d'analyse de documents
 * Centralise toute la logique de traitement des rawResults
 * 
 * @param result - Résultat de l'analyse des documents
 * @returns Données traitées et organisées prêtes à l'affichage
 */
export function useDocumentAnalysis(result: AnalysisResult | null): ProcessedDocumentData | null {
  return useMemo(() => {
    // Vérification des données d'entrée
    if (!result || !result.rawResults) {
      logger.warn('useDocumentAnalysis: Aucune donnée rawResults disponible');
      return null;
    }

    const { documents } = result.rawResults;

    if (!documents || documents.length === 0) {
      logger.warn('useDocumentAnalysis: Aucun document trouvé dans rawResults');
      return null;
    }

    // Étape 1 : Créer une synthèse pour chaque document (fusion des pages)
    const documentsSynthese = documents.map(createDocumentSynthesis);
    logger.debug('Documents synthétisés:', documentsSynthese);

    // Étape 2 : Extraire les documents par type
    const { devis, facture, attestation } = extractDocumentsByType(documentsSynthese);
    logger.debug('Documents extraits par type:', { devis, facture, attestation });

    // Étape 3 : Regrouper les pages par document (pour l'affichage par pages)
    const groupedPages = groupPagesByDocument(documents);
    logger.debug('Pages regroupées:', groupedPages);

    // Étape 4 : Extraire les dates manuscrites des attestations
    const { partBDates, partCDates } = extractAttestationSignatureDates(documents);
    logger.debug('Dates d\'attestation extraites:', { partBDates, partCDates });

    return {
      documentsSynthese,
      devis,
      facture,
      attestation,
      groupedPages,
      attestationPartBSignatureDates: partBDates,
      attestationPartCSignatureDates: partCDates,
      originalDocuments: documents
    };
  }, [result]);
}
