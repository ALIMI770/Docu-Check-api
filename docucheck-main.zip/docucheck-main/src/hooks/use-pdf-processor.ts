import { useState, useRef, useCallback } from 'react';
import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

export interface StampTemplate {
  id: string;
  name: string;
  pageSettings: Record<number, { x: number; y: number; rotation: number }>;
}

export interface DocumentConfig {
  id: string;
  name: string;
  description: string;
  pageSettings: Record<number, { x: number; y: number; rotation: number }>;
}

export const STAMP_DIMENSIONS = {
  width: 150,
  height: 75
};

export const DEFAULT_POSITION = {
  x: 100,
  y: 700
};

// Ajout de constantes pour le format A4
export const A4_WIDTH_PT = 595;
export const A4_HEIGHT_PT = 842;

export function usePdfProcessor(stampImage: string | null) {
  const [state, setState] = useState({
    pdfFile: null as File | null,
    pdfUrl: null as string | null,
    isUploaded: false,
    currentPage: 0,
    totalPages: 0,
    scale: 1.0,
    pageWidth: A4_WIDTH_PT,
    pageHeight: A4_HEIGHT_PT,
    stampPosition: { ...DEFAULT_POSITION },
    rotation: 0,
    stampWidth: STAMP_DIMENSIONS.width,
    stampHeight: STAMP_DIMENSIONS.height,
    isProcessing: false,
    processingProgress: 0,
    selectedPages: {} as Record<number, boolean>,
    templates: [] as StampTemplate[],
    activeTemplate: null as string | null,
    documentConfigs: [] as DocumentConfig[],
    activeConfig: null as string | null,
    defaultConfig: null as string | null,
    pageSpecificSettings: {} as Record<number, { x: number; y: number; rotation: number }>,
    pageSpecificMode: true,
  });

  const pdfDocRef = useRef<pdfjsLib.PDFDocumentProxy | null>(null);
  const templateCounter = useRef(0);
  const configCounter = useRef(0);

  // Conversion des coordonnées entre les systèmes
  const convertPageCoordinates = (
    position: { x: number; y: number },
    sourcePageWidth: number,
    sourcePageHeight: number,
    targetPageWidth: number = A4_WIDTH_PT,
    targetPageHeight: number = A4_HEIGHT_PT
  ) => {
    const scaleX = targetPageWidth / sourcePageWidth;
    const scaleY = targetPageHeight / sourcePageHeight;
    
    return {
      x: position.x * scaleX,
      y: position.y * scaleY
    };
  };

  // Normalisation des coordonnées pour l'application du tampon
  const normalizeStampPosition = (
    position: { x: number; y: number },
    pageWidth: number,
    pageHeight: number
  ) => {
    const scaleX = A4_WIDTH_PT / pageWidth;
    const scaleY = A4_HEIGHT_PT / pageHeight;
    
    return {
      x: position.x * scaleX,
      y: position.y * scaleY
    };
  };

  // Reset l'upload
  const resetUpload = () => {
    if (state.pdfUrl) {
      URL.revokeObjectURL(state.pdfUrl);
    }
    pdfDocRef.current = null;
    setState(prevState => ({
      ...prevState,
      pdfFile: null,
      pdfUrl: null,
      isUploaded: false,
      currentPage: 0,
      totalPages: 0,
      scale: 1.0,
      pageWidth: A4_WIDTH_PT,
      pageHeight: A4_HEIGHT_PT,
      stampPosition: { ...DEFAULT_POSITION },
      rotation: 0,
      selectedPages: {},
      activeTemplate: null,
      activeConfig: null,
      pageSpecificSettings: {},
      pageSpecificMode: false
    }));
  };

  // Changement de fichier PDF
  const handleFileChange = (file: File | null) => {
    if (file) {
      resetUpload();
      const url = URL.createObjectURL(file);
      setState(prevState => ({
        ...prevState,
        pdfFile: file,
        pdfUrl: url,
        isUploaded: true,
        selectedPages: {}
      }));
    }
  };

  // Chargement de la prévisualisation PDF
  const loadPdfPreview = async () => {
    console.log("Loading PDF preview");
    
    if (!state.pdfFile) {
      console.error("No PDF file available for preview");
      return false;
    }
    
    if (!pdfDocRef.current) {
      try {
        setState(prev => ({ ...prev, isProcessing: true }));
        const pdfBytes = await state.pdfFile!.arrayBuffer();
        const pdfDoc = await pdfjsLib.getDocument(pdfBytes).promise;
        pdfDocRef.current = pdfDoc;
        
        // Mise à jour des dimensions de la page au format A4 normalisé
        setState(prev => ({
          ...prev,
          pageWidth: A4_WIDTH_PT,
          pageHeight: A4_HEIGHT_PT,
          totalPages: pdfDoc.numPages,
          isProcessing: false,
          processingProgress: 0
        }));
        
        // Initialiser la sélection des pages
        const initialSelectedPages: Record<number, boolean> = {};
        for (let i = 0; i < pdfDoc.numPages; i++) {
          initialSelectedPages[i] = true;
        }
        setState(prev => ({ ...prev, selectedPages: initialSelectedPages }));
      } catch (error) {
        console.error("Error loading PDF:", error);
        setState(prev => ({ ...prev, isProcessing: false }));
        return false;
      }
    }
    
    return true;
  };

  // Changement de page
  const changePage = (page: number) => {
    if (page >= 0 && page < state.totalPages) {
      setState(prevState => {
        // If we're in page-specific mode, get the settings for this page or use current position
        const pageSettings = prevState.pageSpecificSettings[page];
        
        if (prevState.pageSpecificMode && pageSettings) {
          return {
            ...prevState,
            currentPage: page,
            stampPosition: { x: pageSettings.x, y: pageSettings.y },
            rotation: pageSettings.rotation
          };
        } else {
          return { ...prevState, currentPage: page };
        }
      });
    }
  };

  // Changement du zoom
  const changeZoom = (newScale: number) => {
    setState(prevState => ({ ...prevState, scale: newScale }));
  };

  // Définir une position exacte
  const setExactPosition = (x: number, y: number) => {
    setState(prev => {
      const position = { x, y };
      
      console.log(`Set exact position to: x=${x}, y=${y}`);
      
      // If we're in page-specific mode, update the settings for this page
      if (prev.pageSpecificMode) {
        const pageSettings = {
          ...prev.pageSpecificSettings,
          [prev.currentPage]: {
            x: position.x,
            y: position.y,
            rotation: prev.rotation
          }
        };
        
        return {
          ...prev,
          stampPosition: position,
          pageSpecificSettings: pageSettings
        };
      }
      
      return {
        ...prev,
        stampPosition: position
      };
    });
  };

  // Déplacement du tampon
  const moveStamp = (direction: 'up' | 'down' | 'left' | 'right', amount: number = 20) => {
    setState(prev => {
      const position = { ...prev.stampPosition };
      
      switch (direction) {
        case 'up':
          position.y -= amount;
          break;
        case 'down':
          position.y += amount;
          break;
        case 'left':
          position.x -= amount;
          break;
        case 'right':
          position.x += amount;
          break;
      }
      
      console.log(`Moved stamp ${direction} by ${amount}px to:`, position);
      
      // If we're in page-specific mode, update the settings for this page
      if (prev.pageSpecificMode) {
        const pageSettings = {
          ...prev.pageSpecificSettings,
          [prev.currentPage]: {
            x: position.x,
            y: position.y,
            rotation: prev.rotation
          }
        };
        
        return {
          ...prev,
          stampPosition: position,
          pageSpecificSettings: pageSettings
        };
      }
      
      return {
        ...prev,
        stampPosition: position
      };
    });
  };

  // Rotation du tampon
  const rotateStamp = (clockwise: boolean) => {
    setState(prev => {
      const newRotation = clockwise ? (prev.rotation + 5) % 360 : (prev.rotation - 5 + 360) % 360;
      
      // If we're in page-specific mode, update the settings for this page
      if (prev.pageSpecificMode) {
        const pageSettings = {
          ...prev.pageSpecificSettings,
          [prev.currentPage]: {
            x: prev.stampPosition.x,
            y: prev.stampPosition.y,
            rotation: newRotation
          }
        };
        
        return {
          ...prev,
          rotation: newRotation,
          pageSpecificSettings: pageSettings
        };
      }
      
      return {
        ...prev,
        rotation: newRotation
      };
    });
  };

  // Reset la position du tampon
  const resetToDefaultPosition = () => {
    setState(prev => {
      // If we're in page-specific mode, update the settings for this page
      if (prev.pageSpecificMode) {
        const pageSettings = {
          ...prev.pageSpecificSettings
        };
        
        // Remove the settings for this page
        delete pageSettings[prev.currentPage];
        
        return {
          ...prev,
          stampPosition: { ...DEFAULT_POSITION },
          rotation: 0,
          pageSpecificSettings: pageSettings
        };
      }
      
      return {
        ...prev,
        stampPosition: { ...DEFAULT_POSITION },
        rotation: 0
      };
    });
  };

  // Toggle page-specific mode
  const togglePageSpecificMode = () => {
    setState(prev => {
      const newMode = !prev.pageSpecificMode;
      
      // Si on active le mode par page, sauvegarde automatique de la position actuelle
      if (newMode) {
        const pageSettings = {
          ...prev.pageSpecificSettings,
          [prev.currentPage]: {
            x: prev.stampPosition.x,
            y: prev.stampPosition.y,
            rotation: prev.rotation
          }
        };
        
        return {
          ...prev,
          pageSpecificMode: newMode,
          pageSpecificSettings: pageSettings
        };
      }
      
      return {
        ...prev,
        pageSpecificMode: newMode
      };
    });
  };

  // Sélection des pages
  const togglePageSelection = (page: number) => {
    setState(prev => ({
      ...prev,
      selectedPages: {
        ...prev.selectedPages,
        [page]: !prev.selectedPages[page]
      }
    }));
  };

  // Sélection de toutes les pages
  const selectAllPages = (selected: boolean) => {
    const newSelectedPages: Record<number, boolean> = {};
    for (let i = 0; i < state.totalPages; i++) {
      newSelectedPages[i] = selected;
    }
    setState(prev => ({
      ...prev,
      selectedPages: newSelectedPages
    }));
  };

  // Sauvegarde d'un template
  const saveTemplate = (name: string) => {
    const newTemplate: StampTemplate = {
      id: `template-${templateCounter.current++}`,
      name: name,
      pageSettings: { ...state.pageSpecificSettings }
    };
    
    if (Object.keys(state.pageSpecificSettings).length === 0) {
      newTemplate.pageSettings = {
        0: {
          x: state.stampPosition.x,
          y: state.stampPosition.y,
          rotation: state.rotation
        }
      };
    }
    
    setState(prev => ({
      ...prev,
      templates: [...prev.templates, newTemplate],
      activeTemplate: newTemplate.id
    }));
    return newTemplate.id;
  };

  // Suppression d'un template
  const deleteTemplate = (id: string) => {
    setState(prev => ({
      ...prev,
      templates: prev.templates.filter(template => template.id !== id),
      activeTemplate: prev.activeTemplate === id ? null : prev.activeTemplate
    }));
  };

  // Application d'un template
  const applyTemplate = (id: string) => {
    const templateToApply = state.templates.find(template => template.id === id);
    if (templateToApply) {
      const currentPageSettings = templateToApply.pageSettings[state.currentPage] || 
                                 templateToApply.pageSettings[0] || 
                                 { x: DEFAULT_POSITION.x, y: DEFAULT_POSITION.y, rotation: 0 };
      
      setState(prev => ({
        ...prev,
        stampPosition: {
          x: currentPageSettings.x,
          y: currentPageSettings.y
        },
        rotation: currentPageSettings.rotation,
        activeTemplate: id,
        pageSpecificSettings: { ...templateToApply.pageSettings },
        pageSpecificMode: Object.keys(templateToApply.pageSettings).length > 1
      }));
    }
  };

  // Sauvegarde d'une configuration de document
  const saveDocumentConfig = (name: string, description: string) => {
    const newConfig: DocumentConfig = {
      id: `config-${configCounter.current++}`,
      name: name,
      description: description,
      pageSettings: { ...state.pageSpecificSettings }
    };
    
    if (Object.keys(state.pageSpecificSettings).length === 0) {
      newConfig.pageSettings = {
        0: {
          x: state.stampPosition.x,
          y: state.stampPosition.y,
          rotation: state.rotation
        }
      };
    }
    
    setState(prev => ({
      ...prev,
      documentConfigs: [...prev.documentConfigs, newConfig],
      activeConfig: newConfig.id
    }));
    return newConfig.id;
  };

  // Suppression d'une configuration de document
  const deleteDocumentConfig = (id: string) => {
    setState(prev => ({
      ...prev,
      documentConfigs: prev.documentConfigs.filter(config => config.id !== id),
      activeConfig: prev.activeConfig === id ? null : prev.activeConfig,
      defaultConfig: prev.defaultConfig === id ? null : prev.defaultConfig
    }));
  };

  // Application d'une configuration de document
  const applyDocumentConfig = (id: string) => {
    const configToApply = state.documentConfigs.find(config => config.id === id);
    if (configToApply) {
      const currentPageSettings = configToApply.pageSettings[state.currentPage] || 
                                 configToApply.pageSettings[0] || 
                                 { x: DEFAULT_POSITION.x, y: DEFAULT_POSITION.y, rotation: 0 };
      
      const newSelectedPages: Record<number, boolean> = {};
      for (let i = 0; i < state.totalPages; i++) {
        newSelectedPages[i] = true;
      }
      
      setState(prev => ({
        ...prev,
        stampPosition: {
          x: currentPageSettings.x,
          y: currentPageSettings.y
        },
        rotation: currentPageSettings.rotation,
        activeConfig: id,
        pageSpecificSettings: { ...configToApply.pageSettings },
        pageSpecificMode: Object.keys(configToApply.pageSettings).length > 1,
        selectedPages: newSelectedPages
      }));
    }
  };

  // Définition de la configuration par défaut
  const setDefaultDocumentConfig = (id: string | null) => {
    setState(prev => ({
      ...prev,
      defaultConfig: id
    }));
  };

  // Application du tampon sur le PDF
  const applyStampToPdf = async () => {
    try {
      if (!pdfDocRef.current || !stampImage) {
        console.error("Missing PDF document or stamp image for stamping");
        return false;
      }
      
      setState(prev => ({
        ...prev,
        isProcessing: true,
        processingProgress: 0
      }));
      
      console.log("Starting application of stamp to PDF...");
      
      const { PDFDocument, degrees } = await import('pdf-lib');
      
      // Charger le document PDF
      const pdfBytes = await state.pdfFile!.arrayBuffer();
      const pdfDoc = await PDFDocument.load(pdfBytes);
      
      // Charger l'image du tampon
      const stampImageBytes = await fetch(stampImage).then(res => res.arrayBuffer());
      const stampImg = await pdfDoc.embedPng(stampImageBytes);
      
      // Obtenir les pages du document
      const pages = pdfDoc.getPages();
      console.log(`Processing ${pages.length} pages...`);
      
      // Pour chaque page sélectionnée, appliquer le tampon
      const selectedPageIndexes = Object.entries(state.selectedPages)
        .filter(([_, selected]) => selected)
        .map(([pageIndex]) => parseInt(pageIndex));
      
      let processedCount = 0;
      
      for (let i = 0; i < pages.length; i++) {
        // Vérifier si la page actuelle est sélectionnée
        if (selectedPageIndexes.length === 0 || selectedPageIndexes.includes(i)) {
          const page = pages[i];
          const { width: pageWidth, height: pageHeight } = page.getSize();
          
          // Récupérer la position spécifique pour cette page
          let position = { ...state.stampPosition };
          let pageRotation = state.rotation;
          
          // Mode page par page - utiliser les paramètres spécifiques si disponibles
          if (state.pageSpecificSettings[i]) {
            const pageSettings = state.pageSpecificSettings[i];
            position = { x: pageSettings.x, y: pageSettings.y };
            pageRotation = pageSettings.rotation;
            console.log(`Using page-specific settings for page ${i}:`, position, pageRotation);
          } 
          // Si aucun paramètre spécifique pour cette page, utiliser les paramètres de la page actuelle
          else if (state.pageSpecificMode && !state.pageSpecificSettings[i] && state.pageSpecificSettings[state.currentPage]) {
            const currentPageSettings = state.pageSpecificSettings[state.currentPage];
            position = { x: currentPageSettings.x, y: currentPageSettings.y };
            pageRotation = currentPageSettings.rotation;
            console.log(`No settings for page ${i}, using current page settings:`, position, pageRotation);
          }
          
          console.log(`Applying stamp to page ${i}: x=${position.x}, y=${position.y}, rotation=${pageRotation}`);
          
          // Adapter les dimensions du tampon à l'échelle de la page
          const scaleX = pageWidth / A4_WIDTH_PT;
          const scaleY = pageHeight / A4_HEIGHT_PT;
          
          const stampWidthOnPage = STAMP_DIMENSIONS.width * scaleX;
          const stampHeightOnPage = STAMP_DIMENSIONS.height * scaleY;
          
          // La position Y doit être inversée car PDF-lib utilise des coordonnées depuis le bas de la page
          const yPosition = pageHeight - (position.y * scaleY + stampHeightOnPage / 2);
          
          // Appliquer le tampon sur la page
          page.drawImage(stampImg, {
            x: position.x * scaleX - stampWidthOnPage / 2,
            y: yPosition,
            width: stampWidthOnPage,
            height: stampHeightOnPage,
            opacity: 0.9,
            rotate: degrees(pageRotation),
          });
        }
        
        processedCount++;
        setState(prev => ({
          ...prev,
          processingProgress: (processedCount / pages.length) * 100
        }));
      }
      
      console.log("Saving modified PDF...");
      
      // Sauvegarder le PDF modifié
      const modifiedPdfBytes = await pdfDoc.save();
      
      // Créer un blob pour le téléchargement
      const blob = new Blob([modifiedPdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      
      // Télécharger le PDF
      const a = document.createElement('a');
      a.href = url;
      a.download = `${state.pdfFile!.name.replace('.pdf', '')}_with_stamp.pdf`;
      document.body.appendChild(a);
      
      console.log("Triggering download...");
      a.click();
      
      // Nettoyer
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      setState(prev => ({
        ...prev,
        isProcessing: false,
        processingProgress: 100
      }));
      
      return true;
    } catch (error) {
      console.error("Error applying stamp to PDF:", error);
      
      setState(prev => ({
        ...prev,
        isProcessing: false,
        processingProgress: 0
      }));
      
      return false;
    }
  };

  return {
    state,
    pdfDocRef,
    handleFileChange,
    resetUpload,
    loadPdfPreview,
    changePage,
    changeZoom,
    moveStamp,
    rotateStamp,
    resetToDefaultPosition,
    togglePageSelection,
    selectAllPages,
    saveTemplate,
    deleteTemplate,
    applyTemplate,
    saveDocumentConfig,
    deleteDocumentConfig,
    applyDocumentConfig,
    setDefaultDocumentConfig,
    applyStampToPdf,
    togglePageSpecificMode,
    setExactPosition,
  };
}
