/* eslint-disable @typescript-eslint/no-explicit-any */

/**
 * Utilitaires pour le traitement et la fusion des données d'analyse
 */

/**
 * Fusionne récursivement les champs d'analyse de plusieurs pages
 * @param pages - Tableau de pages contenant des analyses
 * @param field - Nom du champ à fusionner
 * @returns La valeur fusionnée
 */
export function mergeFieldsFromPages(pages: any[], field: string): any {
  const values = pages.map(p => p.analysis?.[field]);

  // Cas booléen : retourne true si au moins une valeur est true
  const firstBoolean = values.find(v => typeof v === "boolean");
  if (firstBoolean !== undefined) {
    return values.some(v => v === true);
  }

  // Cas objet : fusion récursive des propriétés
  const firstObject = values.find(v => v !== undefined && v !== null && typeof v === "object");
  if (firstObject !== null && firstObject !== undefined) {
    const merged: any = {};
    const allKeys = new Set(values.flatMap(v => v ? Object.keys(v) : []));
    
    for (const key of allKeys) {
      merged[key] = mergeFieldsFromPages(
        pages.map(p => ({ analysis: { [key]: p.analysis?.[field]?.[key] } })),
        key
      );
    }
    
    return merged;
  }

  // Cas valeur simple : retourne la première valeur non vide
  return values.find(v => v !== undefined && v !== null && v !== "");
}

/**
 * Crée une synthèse d'un document en fusionnant les données de toutes ses pages
 * @param doc - Document contenant plusieurs pages
 * @returns Document avec une seule page contenant la synthèse
 */
export function createDocumentSynthesis(doc: any): any {
  const allFields = Object.keys(doc.pages[0]?.analysis || {});

  const synthese: any = {};
  for (const field of allFields) {
    synthese[field] = mergeFieldsFromPages(doc.pages, field);
  }

  // Conserver la première image trouvée
  synthese.image = doc.pages.find((p: any) => p.image)?.image;

  return {
    ...doc,
    pages: [
      {
        ...doc.pages[0],
        analysis: synthese
      }
    ]
  };
}

/**
 * Extrait les documents par type depuis une liste de documents synthétisés
 * @param documents - Liste de documents synthétisés
 * @returns Objet contenant les documents extraits par type
 */
export function extractDocumentsByType(documents: any[]) {
  const devis = documents
    .find(doc => doc.type.toLowerCase().includes('devis'))
    ?.pages[0]?.analysis;

  const facture = documents
    .find(doc => doc.type.toLowerCase().includes('facture'))
    ?.pages[0]?.analysis;

  const attestation = documents
    .find(doc => 
      doc.type.toLowerCase().includes('attestation') || 
      doc.type.toLowerCase().includes('honneur')
    )?.pages[0]?.analysis;

  return { devis, facture, attestation };
}

/**
 * Regroupe les pages par document avec informations sur les numéros de pages
 * @param documents - Liste des documents originaux
 * @returns Liste des documents avec métadonnées de pagination
 */
export function groupPagesByDocument(documents: any[]) {
  return documents.map(doc => ({
    type: doc.type,
    pages: doc.pages,
    startPage: doc.pages[0]?.page ?? 1,
    endPage: doc.pages[doc.pages.length - 1]?.page ?? 1
  }));
}

/**
 * Extrait les dates manuscrites des parties B et C d'une attestation
 * @param documents - Liste des documents originaux
 * @returns Objet contenant les dates manuscrites des parties B et C
 */
export function extractAttestationSignatureDates(documents: any[]) {
  const attestationDoc = documents.find(doc =>
    doc.pages.some((p: any) => p.analysis?.is_attestation_cee)
  );

  if (!attestationDoc) {
    return {
      partBDates: [],
      partCDates: []
    };
  }

  // Partie B - dates manuscrites
  const partBDates = attestationDoc.pages
    .filter((p: any) => 
      p.analysis?.attestation_parts?.part_b_present || 
      p.analysis?.attestation_parts?.part_b_date_manuscrite
    )
    .map((p: any) => 
      p.analysis?.attestation_parts?.part_b_date_manuscrite || 
      p.analysis?.date_manuscrite
    )
    .filter((date: any) => !!date);

  // Partie C - dates manuscrites
  const partCDates = attestationDoc.pages
    .filter((p: any) => 
      p.analysis?.attestation_parts?.part_c_present || 
      p.analysis?.attestation_parts?.part_c_date_manuscrite
    )
    .map((p: any) => 
      p.analysis?.attestation_parts?.part_c_date_manuscrite || 
      p.analysis?.date_manuscrite
    )
    .filter((date: any) => !!date);

  return {
    partBDates,
    partCDates
  };
}
