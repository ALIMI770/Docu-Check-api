/* eslint-disable @typescript-eslint/no-explicit-any */

/**
 * Utilitaires pour la manipulation et l'identification des documents
 */

/**
 * Types de documents supportés
 */
export type DocumentTypeIdentifier = 'devis' | 'facture' | 'attestation' | 'contrat' | 'incitation' | 'unknown';

/**
 * Obtient l'icône emoji correspondant au type de document
 * @param type - Le type de document
 * @returns L'emoji représentant le type de document
 */
export function getDocumentIcon(type: string): string {
  const lowerType = type.toLowerCase();
  
  if (lowerType.includes('devis')) return '📄';
  if (lowerType.includes('facture')) return '🧾';
  if (lowerType.includes('attestation') || lowerType.includes('honneur')) return '📝';
  if (lowerType.includes('contrat') || lowerType.includes('partenariat')) return '📋';
  if (lowerType.includes('incitation') || lowerType.includes('financière')) return '💰';
  
  return '📄';
}

/**
 * Identifie le type de document basé sur son nom
 * @param type - Le nom du type de document
 * @returns Le type de document identifié
 */
export function identifyDocumentType(type: string): DocumentTypeIdentifier {
  const lowerType = type.toLowerCase();
  
  if (lowerType.includes('devis')) return 'devis';
  if (lowerType.includes('facture')) return 'facture';
  if (lowerType.includes('attestation') || lowerType.includes('honneur')) return 'attestation';
  if (lowerType.includes('contrat') || lowerType.includes('partenariat')) return 'contrat';
  if (lowerType.includes('incitation') || lowerType.includes('financière')) return 'incitation';
  
  return 'unknown';
}

/**
 * Vérifie si un document est une attestation CEE
 * @param type - Le type de document
 * @returns true si c'est une attestation CEE
 */
export function isAttestationCEE(type: string): boolean {
  const lowerType = type.toLowerCase();
  return lowerType.includes('attestation') || lowerType.includes('honneur');
}

/**
 * Extrait une valeur d'un tableau de pages en cherchant la première occurrence non vide
 * @param pages - Tableau de pages
 * @param field - Champ à extraire
 * @param defaultValue - Valeur par défaut si non trouvé
 * @returns La valeur trouvée ou la valeur par défaut
 */
export function extractFieldFromPages<T = any>(
  pages: any[],
  field: string,
  defaultValue: string = "Non détecté"
): string {
  const value = pages.find(p => p.analysis?.[field])?.analysis[field];
  return value || defaultValue;
}

/**
 * Extrait un score de fiabilité d'un tableau de pages
 * @param pages - Tableau de pages
 * @param field - Champ du score à extraire
 * @returns Le score trouvé ou undefined
 */
export function extractScoreFromPages(
  pages: any[],
  field: string
): number | undefined {
  return pages
    .map(p => p.analysis?.fiabilite_manuscrits?.[field])
    .filter(s => s !== undefined && s !== null && s !== '' && s !== 0)[0];
}
