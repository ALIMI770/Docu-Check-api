/* eslint-disable @typescript-eslint/no-explicit-any */

/**
 * Système de logging configurable pour le développement et la production
 */

const isDevelopment = import.meta.env.MODE === 'development';

/**
 * Logger personnalisé avec contrôle basé sur l'environnement
 */
export const logger = {
  /**
   * Log des informations générales (uniquement en développement)
   */
  log: (...args: any[]): void => {
    if (isDevelopment) {
      console.log(...args);
    }
  },

  /**
   * Log des informations de debug (uniquement en développement)
   */
  debug: (...args: any[]): void => {
    if (isDevelopment) {
      console.debug(...args);
    }
  },

  /**
   * Log des avertissements (uniquement en développement)
   */
  warn: (...args: any[]): void => {
    if (isDevelopment) {
      console.warn(...args);
    }
  },

  /**
   * Log des erreurs (toujours actif)
   */
  error: (...args: any[]): void => {
    console.error(...args);
  },

  /**
   * Log groupé pour une meilleure organisation (uniquement en développement)
   */
  group: (label: string, ...args: any[]): void => {
    if (isDevelopment) {
      console.group(label);
      console.log(...args);
      console.groupEnd();
    }
  }
};
