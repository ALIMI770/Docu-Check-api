
export interface DocumentZones {
  headerZone: string;
  signatureZone: string;
  stampZone: string;
  amountZone: string;
}

export interface HandwrittenInfo {
  name: string;
  function: string;
  date: string;
  signature: boolean;
  agreement: boolean;
  documentType?: string;
  isAttestationCee?: boolean;
  attestationPart?: string;
}

export interface OcrResults {
  text: string;
  handwrittenInfo?: HandwrittenInfo;
  zones?: {
    headerText: string;
    signatureText: string;
    stampText: string;
    amountText: string;
  };
  devis?: any;
  facture?: any;
  attestation?: any;
}

export interface AttestationCEEParts {
  partA: {
    present: boolean;
    dates: string[];
    workAddress: string;
  };
  partB: {
    present: boolean;
    clientName: string;
    clientSignature: boolean;
    bonPourAccord: boolean;
  };
  partC: {
    present: boolean;
    companyName: string;
    siret: string;
    address: string;
    stampPresent: boolean;
    signature: boolean;
  };
}

// Add missing interface definitions
export interface SiretVerification {
  isValid: boolean;
  companyName?: string;
  address?: string;
  status?: string;
  error?: string;
}

export interface SireneApiResponse {
  etablissement?: {
    uniteLegale?: {
      denominationUniteLegale?: string;
      nomUniteLegale?: string;
      prenomUsuelUniteLegale?: string;
      etatAdministratifUniteLegale?: string;
    };
    adresseEtablissement?: {
      numeroVoieEtablissement?: string;
      typeVoieEtablissement?: string;
      libelleVoieEtablissement?: string;
      codePostalEtablissement?: string;
      libelleCommuneEtablissement?: string;
    };
  };
}
