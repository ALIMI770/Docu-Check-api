
/**
 * Service de géocodage pour convertir les adresses en coordonnées géographiques
 * Utilise Nominatim (OpenStreetMap) pour le géocodage
 */

export interface GeocodingResult {
  lat: number;
  lng: number;
  displayName?: string;
}

/**
 * Convertit une adresse en coordonnées géographiques (latitude, longitude)
 * @param address L'adresse à géocoder
 * @returns Une promesse qui résout vers un objet contenant lat et lng, ou null si non trouvé
 */
export const geocodeAddress = async (address: string): Promise<GeocodingResult | null> => {
  try {
    // Utilise l'API Nominatim d'OpenStreetMap
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
        address
      )}&limit=1`,
      {
        headers: {
          "Accept-Language": "fr", // Préférer les résultats en français
          "User-Agent": "DocuCheck-AI-RouteOptimizer", // Identifiant pour Nominatim
        },
      }
    );

    if (!response.ok) {
      console.error("Erreur API Nominatim:", response.statusText);
      return null;
    }

    const data = await response.json();

    if (!data || data.length === 0) {
      return null;
    }

    const result = data[0];
    return {
      lat: parseFloat(result.lat),
      lng: parseFloat(result.lon),
      displayName: result.display_name,
    };
  } catch (error) {
    console.error("Erreur de géocodage:", error);
    return null;
  }
};

/**
 * Convertit des coordonnées géographiques en adresse (géocodage inverse)
 * @param lat Latitude
 * @param lng Longitude
 * @returns Une promesse qui résout vers une adresse, ou null si non trouvé
 */
export const reverseGeocode = async (
  lat: number,
  lng: number
): Promise<string | null> => {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`,
      {
        headers: {
          "Accept-Language": "fr",
          "User-Agent": "DocuCheck-AI-RouteOptimizer",
        },
      }
    );

    if (!response.ok) {
      console.error("Erreur API Nominatim (reverse):", response.statusText);
      return null;
    }

    const data = await response.json();

    if (!data || !data.display_name) {
      return null;
    }

    return data.display_name;
  } catch (error) {
    console.error("Erreur de géocodage inverse:", error);
    return null;
  }
};
