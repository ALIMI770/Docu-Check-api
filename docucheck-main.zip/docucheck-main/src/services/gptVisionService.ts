/* eslint-disable @typescript-eslint/no-explicit-any */

import { detectManuscriptZones } from './manuscriptDetectionService';



// Clé API OpenAI intégrée directement dans l'application
const OPENAI_API_KEY = "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";

interface DocumentAnalysis {
  page_number_doc: number;
  document_type: string;
  page_number: number;
  total_pages: number;
  is_continuation: boolean;

  // Champs partagés - DEVIS & FACTURE
  nom_client: string;
  siret_client: string;
  adresse_entreprise_client: string;
  adresse_travaux: string;
  date_emission: string;
  amount_ht: number;
  taux_tva: number;

  // Champs partagés - CONTRAT DE PARTENARIAT
  date_contrat: string;
  nom_beneficiaire_contrat: string;
  adresse_beneficiaire_contrat: string;
  nom_entreprise_prestataire: string;
  nom_representant_prestataire: string;
  siret_prestataire: string;
  adresse_prestataire: string;
  date_signature: string;

  // Champs partagés - INCITATION FINANCIERE
  nom_beneficiaire: string;
  siren_beneficiaire: string;
  adresse_beneficiaire: string;
  nom_entreprise_oblige: string;
  siret_oblige: string;
  adresse_oblige: string;
  nom_societe_signataire: string;
  nom_signataire: string;
  fonction_signataire: string;
  infos_tampons: Array<{
    nom: string;
    adresse: string;
    siret: string;
  }>;

  // Champ partagé - Montant (tous documents)
  amount_ttc: number;

  // Champ partagé - Tampon (tous documents sauf incitation)
  tampon_present: boolean;
  infos_tampon: {
    nom: string;
    adresse: string;
    siret: string;
  };

  // Éléments manuscrits partagés
  bon_pour_accord: boolean;
  lu_et_approuve: boolean;
  signature_manuscrite: boolean;
  nom_manuscrit: string;
  fonction_manuscrite: string;
  date_manuscrite: string;

  // Coordonnées englobantes UNIQUES par page (si éléments manuscrits présents)
  coordinates_manuscrits: string;

  // Fiabilité par type d'élément manuscrit (0-100)
  fiabilite_manuscrits?: {
    tampon: number;
    signature: number;
    nom_manuscrit: number;
    fonction_manuscrite: number;
    date_manuscrite: number;
    bon_pour_accord: number;
    lu_et_approuve: number;
  };

  // ATTESTATION CEE - Sections spécifiques
  is_attestation_cee: boolean;
  attestation_parts?: {
    part_a_present: boolean;
    part_a_dates: {
      engagement: string;
      realisation: string;
      visite: string;
    };
    part_b_present: boolean;
    part_b_company_info: {
      adresse: string;
      nom_signataire: string;
      prenom_signataire: string;
      fonction_signataire: string;
      raison_sociale: string;
      siren: string;
    };
    part_b_signature_manuscrite: boolean;
    part_b_date_manuscrite: string;
    part_c_present: boolean;
    part_c_company_info: {
      adresse: string;
      nom_signataire: string;
      prenom_signataire: string;
      fonction_signataire: string;
      raison_sociale: string;
      siret: string;
    };
    part_c_signature_manuscrite: boolean;
    part_c_date_manuscrite: string;
  };

  error?: string;
}

interface BatchAnalysisResult {
  individual_analyses: (DocumentAnalysis & { filename: string; timestamp: string })[];
  global_analysis: {
    score: number;
    document_types_found: Record<string, number>;
    unique_sirets: string[];
    valid_documents: number;
    total_documents: number;
    siret_consistency: string;
  };
  errors?: Array<{ filename: string; error: string }>;
  error?: string;
}

interface DocumentContext {
  document_type?: string;
  company_name?: string;
  siret?: string;
  page_count?: number;
}

// Fonction principale pour analyser un document avec GPT-4 Vision
export const analyzeDocumentWithGpt = async (imageDataUrls: any | File[]): Promise<DocumentAnalysis[]> => {
  try {
    // Générer un ID unique pour cette analyse afin de garantir l'indépendance
    const analysisId = `ANALYSIS_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    
    // Prompt détaillé optimisé par type de document avec champs partagés
    const prompt = `
    [ID D'ANALYSE: ${analysisId}]
    
    ╔═══════════════════════════════════════════════════════════════════════════════╗
    ║  IMPORTANTE : ANALYSE INDÉPENDANTE ET ISOLÉE                                  ║
    ╚═══════════════════════════════════════════════════════════════════════════════╝
    
    Cette analyse est COMPLÈTEMENT NOUVELLE et INDÉPENDANTE de toute analyse précédente.
    
    RÈGLES D'INDÉPENDANCE STRICTES :
    • Ignorez TOTALEMENT toutes les analyses que vous auriez pu faire auparavant
    • Ne faites AUCUN lien avec des documents similaires analysés précédemment
    • Même si une image vous semble familière, analysez-la comme si c'était la première fois
    • Analysez UNIQUEMENT ce qui est visible dans les images fournies MAINTENANT
    • N'utilisez AUCUNE information provenant d'analyses antérieures
    • Réinitialisez votre contexte : cette analyse part de zéro
    
    ═══════════════════════════════════════════════════════════════════════════════
    
    Analysez avec PRÉCISION ces pages de documents CEE français. Ne sautez AUCUNE page dans l'analyse et le retour de résultats.

    Même si le dossier contient beaucoup de pages, prenez le temps de bien tout analyser et renseigner sans erreur toutes les informations demandées pour chaque page si elles sont disponibles.

    TYPES DE DOCUMENTS POSSIBLES (dans un ordre aléatoire avec un nombre variable de pages) :
    - Devis
    - Facture
    - Attestation sur l'honneur (CEE)
    - Contrat de partenariat
    - Incitation financière
    - Autres documents administratifs

    ═══════════════════════════════════════════════════════════════════════════════
    RÈGLES GÉNÉRALES POUR CHAQUE PAGE
    ═══════════════════════════════════════════════════════════════════════════════

    1. Identifiez le type du sous-document (devis, facture, attestation_cee, contrat_partenariat, incitation_financiere, etc.)
    2. Si une page est la suite d'un sous-document précédent, mettez "is_continuation": true
    3. Si vous n'êtes pas CERTAIN de la présence d'un élément, laissez-le vide ("") ou false
    4. Ne faites AUCUNE supposition sur les éléments manquants
    5. "page_number" = numéro de la page dans le sous-document
    6. "total_pages" = nombre total de pages du sous-document
    7. "page_number_doc" = numéro de page global du document complet

    ⚠️ RÈGLE CRITIQUE POUR LES PAGES DE CONTINUATION (is_continuation: true) :
    
    Pour chaque page analysée, rapportez UNIQUEMENT ce qui est PHYSIQUEMENT VISIBLE sur 
    CETTE page SPÉCIFIQUE. NE COPIEZ PAS et NE RÉPÉTEZ PAS les informations des pages 
    précédentes du même document.
    
    Exemples CORRECTS :
    • Si la signature est sur la page 1 mais PAS sur la page 2 → page 2 : signature_manuscrite = false
    • Si le tampon est sur la page 3 mais PAS sur la page 4 → page 4 : tampon_present = false
    • Si "Bon pour accord" est sur la page 1 mais PAS sur la page 2 → page 2 : bon_pour_accord = false
    
    Exemples INCORRECTS (À NE PAS FAIRE) :
    • ❌ Reporter la signature de la page 1 sur toutes les pages suivantes
    • ❌ Copier le tampon d'une page sur les pages de continuation
    • ❌ Répéter les éléments manuscrits des pages précédentes
    
    ANALYSEZ CHAQUE PAGE INDÉPENDAMMENT pour les éléments manuscrits et visuels.

    ═══════════════════════════════════════════════════════════════════════════════
    INFORMATIONS À EXTRAIRE PAR TYPE DE DOCUMENT
    ═══════════════════════════════════════════════════════════════════════════════

    ┌─────────────────────────────────────────────────────────────────────────────┐
    │ DEVIS & FACTURE                                                             │
    └─────────────────────────────────────────────────────────────────────────────┘
    Remplir UNIQUEMENT si document_type = "devis" ou "facture":
    
    • nom_client : Nom complet de l'entreprise cliente
    • siret_client : Numéro SIRET du client (14 chiffres)
    • adresse_entreprise_client : Adresse du siège social de l'entreprise
    • adresse_travaux : Adresse où les travaux seront réalisés
    • date_emission : Date d'émission au format JJ/MM/AAAA
    • amount_ht : Montant hors taxes en euros
    • taux_tva : Taux de TVA en pourcentage (ex: 20 pour 20%)
    • amount_ttc : Montant total TTC en euros
    • tampon_present : true/false
    • infos_tampon : {nom, adresse, siret}
    • signature_manuscrite : true/false
    • bon_pour_accord : true/false
    • lu_et_approuve : true/false
    • nom_manuscrit : Nom manuscrit du signataire
    • fonction_manuscrite : Fonction manuscrite du signataire
    • date_manuscrite : Date manuscrite

    ┌─────────────────────────────────────────────────────────────────────────────┐
    │ ATTESTATION SUR L'HONNEUR (CEE)                                             │
    └─────────────────────────────────────────────────────────────────────────────┘
    Remplir UNIQUEMENT si document_type = "attestation_cee":
    
    ⚠️ RÈGLE CRITIQUE POUR LES ATTESTATIONS CEE MULTI-PAGES :
    
    Une attestation CEE contient généralement 3 parties distinctes (A, B, C) qui peuvent être 
    sur des pages DIFFÉRENTES. Pour CHAQUE PAGE analysée :
    
    1. Identifiez QUELLE partie (A, B, ou C) est PHYSIQUEMENT VISIBLE sur CETTE page
    2. Marquez UNIQUEMENT la partie présente : 
       - Si vous voyez "PARTIE A" ou "Cadre réservé au professionnel" → part_a_present = true
       - Si vous voyez "PARTIE B" ou "Cadre réservé au bénéficiaire" → part_b_present = true  
       - Si vous voyez "PARTIE C" ou "Cadre réservé à l'installateur" → part_c_present = true
    3. Pour les éléments manuscrits (signature, date) :
       - Si signature dans la zone PARTIE B sur CETTE page → part_b_signature_manuscrite = true
       - Si signature dans la zone PARTIE C sur CETTE page → part_c_signature_manuscrite = true
       - Ne JAMAIS reporter une signature d'une partie sur une autre partie
    
    EXEMPLES CORRECTS :
    ✅ Page 1 : PARTIE A visible → part_a_present = true, part_b_present = false, part_c_present = false
    ✅ Page 2 : PARTIE B visible avec signature → part_b_present = true, part_b_signature_manuscrite = true
    ✅ Page 3 : PARTIE C visible avec signature → part_c_present = true, part_c_signature_manuscrite = true
    
    EXEMPLES INCORRECTS :
    ❌ Reporter la signature de la partie B sur toutes les pages
    ❌ Marquer part_b_present = true sur une page qui montre seulement la partie C
    ❌ Confondre la signature de la partie B avec celle de la partie C
    
    • is_attestation_cee : true
    • amount_ttc : Montant de la prime CEE en euros
    
    Section A (UNIQUEMENT si visible sur CETTE page):
    • attestation_parts.part_a_present : true/false (true seulement si PARTIE A visible sur CETTE page)
    • attestation_parts.part_a_dates.engagement : Date au format JJ/MM/AAAA
    • attestation_parts.part_a_dates.realisation : Date au format JJ/MM/AAAA
    • attestation_parts.part_a_dates.visite : Date au format JJ/MM/AAAA
    
    Section B (UNIQUEMENT si visible sur CETTE page):
    • attestation_parts.part_b_present : true/false (true seulement si PARTIE B visible sur CETTE page)
    • attestation_parts.part_b_company_info.adresse : Adresse de l'entreprise
    • attestation_parts.part_b_company_info.nom_signataire : Nom du signataire
    • attestation_parts.part_b_company_info.prenom_signataire : Prénom du signataire
    • attestation_parts.part_b_company_info.fonction_signataire : Fonction du signataire
    • attestation_parts.part_b_company_info.raison_sociale : Raison sociale
    • attestation_parts.part_b_company_info.siren : Numéro SIREN (9 chiffres)
    • attestation_parts.part_b_signature_manuscrite : true/false (true SEULEMENT si signature visible dans PARTIE B sur CETTE page)
    • attestation_parts.part_b_date_manuscrite : Date manuscrite (SEULEMENT si date visible dans PARTIE B sur CETTE page)
    • infos_tampon : {nom, adresse, siret} (tampon de la section B, SEULEMENT si visible sur CETTE page)
    
    Section C (UNIQUEMENT si visible sur CETTE page):
    • attestation_parts.part_c_present : true/false (true seulement si PARTIE C visible sur CETTE page)
    • attestation_parts.part_c_company_info.adresse : Adresse de l'entreprise
    • attestation_parts.part_c_company_info.nom_signataire : Nom du signataire
    • attestation_parts.part_c_company_info.prenom_signataire : Prénom du signataire
    • attestation_parts.part_c_company_info.fonction_signataire : Fonction du signataire
    • attestation_parts.part_c_company_info.raison_sociale : Raison sociale
    • attestation_parts.part_c_company_info.siret : Numéro SIRET (14 chiffres)
    • attestation_parts.part_c_signature_manuscrite : true/false (true SEULEMENT si signature visible dans PARTIE C sur CETTE page)
    • attestation_parts.part_c_date_manuscrite : Date manuscrite (SEULEMENT si date visible dans PARTIE C sur CETTE page)
    • infos_tampon : {nom, adresse, siret} (tampon de la section C, SEULEMENT si visible sur CETTE page)

    ┌─────────────────────────────────────────────────────────────────────────────┐
    │ CONTRAT DE PARTENARIAT                                                      │
    └─────────────────────────────────────────────────────────────────────────────┘
    Remplir UNIQUEMENT si document_type = "contrat_partenariat":
    
    • date_contrat : Date du contrat au format JJ/MM/AAAA
    • amount_ttc : Montant total TTC en euros (si applicable)
    • nom_beneficiaire_contrat : Nom du bénéficiaire
    • adresse_beneficiaire_contrat : Adresse du bénéficiaire
    • nom_entreprise_prestataire : Nom de l'entreprise prestataire
    • nom_representant_prestataire : Nom du représentant du prestataire
    • siret_prestataire : Numéro SIRET du prestataire (14 chiffres)
    • adresse_prestataire : Adresse du prestataire
    • date_signature : Date de signature au format JJ/MM/AAAA
    • tampon_present : true/false
    • infos_tampon : {nom, adresse, siret}
    • signature_manuscrite : true/false

    ┌─────────────────────────────────────────────────────────────────────────────┐
    │ INCITATION FINANCIÈRE                                                       │
    └─────────────────────────────────────────────────────────────────────────────┘
    Remplir UNIQUEMENT si document_type = "incitation_financiere":
    
    • date_emission : Date au format JJ/MM/AAAA
    • amount_ttc : Montant total TTC en euros (si applicable)
    • nom_beneficiaire : Nom du bénéficiaire
    • siren_beneficiaire : Numéro SIREN du bénéficiaire (9 chiffres)
    • adresse_beneficiaire : Adresse complète du bénéficiaire
    • adresse_travaux : Adresse des travaux
    • nom_entreprise_oblige : Nom de l'entreprise obligée
    • siret_oblige : Numéro SIRET de l'obligé (14 chiffres)
    • adresse_oblige : Adresse complète de l'obligé
    • date_signature : Date de signature au format JJ/MM/AAAA
    • nom_societe_signataire : Nom de la société signataire
    • nom_signataire : Nom du signataire
    • fonction_signataire : Fonction du signataire
    • infos_tampons : TABLEAU [{nom, adresse, siret}, ...] (un ou plusieurs tampons)
    • signature_manuscrite : true/false

    ═══════════════════════════════════════════════════════════════════════════════
    ÉLÉMENTS MANUSCRITS ET TAMPONS (Examinez ATTENTIVEMENT)
    ═══════════════════════════════════════════════════════════════════════════════

    ⚠️ RÈGLE ABSOLUE : Analysez UNIQUEMENT ce qui est VISIBLE sur LA PAGE ACTUELLE
    
    Ne rapportez un élément manuscrit (signature, tampon, etc.) que s'il est PHYSIQUEMENT 
    PRÉSENT sur la page que vous analysez en ce moment. Ne copiez JAMAIS les éléments des 
    pages précédentes même si elles font partie du même document.

    DÉFINITIONS IMPORTANTES :
    • Tampon d'entreprise : Plusieurs petites lignes de texte (droites ou penchées) contenant
      le nom de la société, l'adresse, le numéro SIRET, parfois un logo. Peut être en couleur
      ou noir et blanc.
    • Signature manuscrite : Peut être partiellement lisible, fluide, stylisée, seule ou
      chevauchant un tampon.
    • S'il y a plusieurs tampons/signatures : considérer uniquement le plus pertinent.

    ÉLÉMENTS À DÉTECTER (sur la page actuelle uniquement) :
    • tampon_present : true/false (true SEULEMENT si visible sur CETTE page)
    • infos_tampon : {nom, adresse, siret} (SEULEMENT si tampon sur CETTE page)
    • "Bon pour accord" présent? (SEULEMENT si visible sur CETTE page)
    • "Lu et approuvé" présent? (SEULEMENT si visible sur CETTE page)
    • signature_manuscrite : true/false (true SEULEMENT si visible sur CETTE page)
    • nom_manuscrit : Nom manuscrit du signataire (SEULEMENT si écrit sur CETTE page)
    • fonction_manuscrite : Fonction manuscrite du signataire (SEULEMENT si écrite sur CETTE page)
    • date_manuscrite : Date manuscrite (SEULEMENT si écrite sur CETTE page)

    ═══════════════════════════════════════════════════════════════════════════════
    FIABILITÉ DES ÉLÉMENTS MANUSCRITS
    ═══════════════════════════════════════════════════════════════════════════════

    Pour chaque élément manuscrit détecté, donnez une note de fiabilité de 0 à 100 sur la
    QUALITÉ DE LECTURE des caractères manuscrits (pas sur la présence/absence de l'élément).

    "fiabilite_manuscrits": {
      "tampon": 0-100,
      "signature": 0-100,
      "nom_manuscrit": 0-100,
      "fonction_manuscrite": 0-100,
      "date_manuscrite": 0-100,
      "bon_pour_accord": 0-100,
      "lu_et_approuve": 0-100
    }

    ═══════════════════════════════════════════════════════════════════════════════
    ⚠️ RAPPEL FINAL CRITIQUE - ATTESTATIONS CEE MULTI-PAGES
    ═══════════════════════════════════════════════════════════════════════════════
    
    Si vous analysez une ATTESTATION CEE avec plusieurs pages :
    
    1. CHAQUE page doit avoir son propre objet dans le tableau "pages"
    2. Pour CHAQUE page, identifiez QUELLE partie (A, B, ou C) est VISIBLE sur cette page précise
    3. Marquez part_a_present, part_b_present, ou part_c_present selon ce qui est VISIBLE
    4. Les éléments manuscrits (signature, date) doivent être assignés à la BONNE partie :
       - Signature dans zone "PARTIE B" → part_b_signature_manuscrite = true sur CETTE page
       - Signature dans zone "PARTIE C" → part_c_signature_manuscrite = true sur CETTE page
    5. NE JAMAIS copier/reporter les infos d'une partie vers une autre
    
    EXEMPLE CONCRET d'une attestation sur 3 pages :
    
    Page 1 (Partie A) :
    {
      "page_number_doc": 1,
      "document_type": "attestation_cee",
      "attestation_parts": {
        "part_a_present": true,  ← PARTIE A visible
        "part_b_present": false,
        "part_c_present": false,
        ...
      }
    }
    
    Page 2 (Partie B avec signature) :
    {
      "page_number_doc": 2,
      "document_type": "attestation_cee",
      "is_continuation": true,
      "attestation_parts": {
        "part_a_present": false,
        "part_b_present": true,  ← PARTIE B visible
        "part_b_signature_manuscrite": true,  ← Signature visible dans PARTIE B
        "part_c_present": false,
        ...
      }
    }
    
    Page 3 (Partie C avec signature) :
    {
      "page_number_doc": 3,
      "document_type": "attestation_cee",
      "is_continuation": true,
      "attestation_parts": {
        "part_a_present": false,
        "part_b_present": false,
        "part_c_present": true,  ← PARTIE C visible
        "part_c_signature_manuscrite": true,  ← Signature visible dans PARTIE C
        ...
      }
    }

    ═══════════════════════════════════════════════════════════════════════════════
    FORMAT JSON DE RÉPONSE (OBLIGATOIRE)
    ═══════════════════════════════════════════════════════════════════════════════

    RÉPONDEZ UNIQUEMENT AU FORMAT JSON SUIVANT sans texte supplémentaire:
    {
      "pages": [
        {
          "page_number_doc": number,
          "document_type": "devis|facture|attestation_cee|contrat_partenariat|incitation_financiere|autre",
          "page_number": number,
          "total_pages": number,
          "is_continuation": true|false,
          
          "nom_client": "",
          "siret_client": "",
          "adresse_entreprise_client": "",
          "adresse_travaux": "",
          "date_emission": "",
          
          "date_contrat": "",
          "nom_beneficiaire_contrat": "",
          "adresse_beneficiaire_contrat": "",
          "nom_entreprise_prestataire": "",
          "nom_representant_prestataire": "",
          "siret_prestataire": "",
          "adresse_prestataire": "",
          "date_signature": "",
          
          "nom_beneficiaire": "",
          "siren_beneficiaire": "",
          "adresse_beneficiaire": "",
          "nom_entreprise_oblige": "",
          "siret_oblige": "",
          "adresse_oblige": "",
          "nom_societe_signataire": "",
          "nom_signataire": "",
          "fonction_signataire": "",
          "infos_tampons": [],
          
          "amount_ht": 0,
          "taux_tva": 0,
          "amount_ttc": 0,
          
          "tampon_present": false,
          "infos_tampon": {"nom": "", "adresse": "", "siret": ""},
          
          "bon_pour_accord": false,
          "lu_et_approuve": false,
          "signature_manuscrite": false,
          "nom_manuscrit": "",
          "fonction_manuscrite": "",
          "date_manuscrite": "",
          
          "fiabilite_manuscrits": {
            "tampon": 0,
            "signature": 0,
            "nom_manuscrit": 0,
            "fonction_manuscrite": 0,
            "date_manuscrite": 0,
            "bon_pour_accord": 0,
            "lu_et_approuve": 0
          },
          
          "is_attestation_cee": false,
          "attestation_parts": {
            // RAPPEL : Pour chaque page d'attestation, marquer UNIQUEMENT la partie visible sur CETTE page
            // Ne PAS reporter les infos d'une partie sur une autre partie ou sur une autre page
            "part_a_present": false,  // true SEULEMENT si PARTIE A est sur CETTE page
            "part_a_dates": {"engagement": "", "realisation": "", "visite": ""},
            "part_b_present": false,  // true SEULEMENT si PARTIE B est sur CETTE page
            "part_b_company_info": {
              "adresse": "",
              "nom_signataire": "",
              "prenom_signataire": "",
              "fonction_signataire": "",
              "raison_sociale": "",
              "siren": ""
            },
            "part_b_signature_manuscrite": false,  // true SEULEMENT si signature PARTIE B visible sur CETTE page
            "part_b_date_manuscrite": "",  // Remplir SEULEMENT si date manuscrite PARTIE B visible sur CETTE page
            "part_c_present": false,  // true SEULEMENT si PARTIE C est sur CETTE page
            "part_c_company_info": {
              "adresse": "",
              "nom_signataire": "",
              "prenom_signataire": "",
              "fonction_signataire": "",
              "raison_sociale": "",
              "siret": ""
            },
            "part_c_signature_manuscrite": false,  // true SEULEMENT si signature PARTIE C visible sur CETTE page
            "part_c_date_manuscrite": ""  // Remplir SEULEMENT si date manuscrite PARTIE C visible sur CETTE page
          }
        }
      ]
    }
    `;
    
    console.log("Envoi des images à GPT-4o pour analyse détaillée...");
    
    // Appel à l'API OpenAI avec GPT-4o et forcer la réponse JSON
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: "o4-mini",
        messages: [
          {
            role: "system", 
            content: "Vous êtes un expert en analyse de documents CEE (CERTIFICATS D'ÉCONOMIES D'ÉNERGIE) français, vous savez aussi détecter dans les documents : des éléments manuscrits, des signatures et des tampons d'entreprise (avec ou sans signature au par dessus). Vous êtes capable de comprendre la continuité entre les pages en utilisant la numérotation inscrite parfois sur les pages, et/ou le contexte de la page."
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `
                ${prompt}
                `
              },
              ...imageDataUrls.map(({ dataUrl }) => ({
                type: "image_url",
                image_url: {
                  url: dataUrl,
                  detail: "high"
                }
              }))
            ]
          }
        ],
        // max_tokens: 4000,
        // temperature: 0.1, // Température basse pour plus de déterminisme, mais pas 0 pour éviter le cache
        response_format: { type: "json_object" },
        // Paramètres pour garantir l'indépendance des analyses
        seed: Date.now() % 1000000, // Seed unique pour chaque analyse
        user: `analysis_${Date.now()}` // Identifiant utilisateur unique pour isoler les requêtes
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error("Erreur API OpenAI:", errorData);
      throw new Error(`Erreur API OpenAI: ${response.status} - ${JSON.stringify(errorData)}`);
    }

    const data = await response.json();    
    
    if (data.choices && data.choices.length > 0 && data.choices[0].message && data.choices[0].message.content) {
      const content = data.choices[0].message.content;      
      
      try {
        const parsedResult = JSON.parse(content);
        
        if (!parsedResult.pages || !Array.isArray(parsedResult.pages)) {
          throw new Error("Format de réponse invalide: pages manquantes");
        }
        
        console.log("Analyse GPT terminée. Vérification des pages avec éléments manuscrits...");
        
        // Identifier les pages qui contiennent des éléments manuscrits selon GPT
        const pagesWithManuscript = parsedResult.pages.map((page: any, index: number) => {
          const hasManuscriptElements = 
            page.tampon_present || 
            page.signature_manuscrite || 
            page.bon_pour_accord || 
            page.lu_et_approuve ||
            page.nom_manuscrit || 
            page.fonction_manuscrite || 
            page.date_manuscrite ||
            page.attestation_parts?.part_b_signature_manuscrite ||
            page.attestation_parts?.part_b_date_manuscrite ||
            page.attestation_parts?.part_c_signature_manuscrite ||
            page.attestation_parts?.part_c_date_manuscrite;
          
          return { index, hasManuscript: hasManuscriptElements };
        });
        
        const pagesToAnalyze = pagesWithManuscript.filter(p => p.hasManuscript);
        
        if (pagesToAnalyze.length > 0) {
          console.log(`${pagesToAnalyze.length} page(s) avec manuscrit détecté(s). Lancement de Tesseract...`);
        } else {
          console.log("Aucun élément manuscrit détecté par GPT. Tesseract non nécessaire.");
        }
        
        // Détecter les zones manuscrites UNIQUEMENT pour les pages avec manuscrit
        const manuscriptDetections = new Array(parsedResult.pages.length).fill(null);
        
        for (const pageInfo of pagesToAnalyze) {
          try {
            console.log(`Analyse Tesseract de la page ${pageInfo.index + 1}...`);
            const detection = await detectManuscriptZones(imageDataUrls[pageInfo.index].dataUrl);
            manuscriptDetections[pageInfo.index] = detection;
          } catch (error) {
            console.error(`Erreur Tesseract page ${pageInfo.index + 1}:`, error);
            manuscriptDetections[pageInfo.index] = { hasManuscript: false, zones: [], globalBoundingBox: undefined };
          }
        }
        
        console.log("Détection manuscrite terminée. Fusion des résultats...");

        // Convertir les résultats en format DocumentAnalysis avec coordonnées détectées
        return parsedResult.pages.map((page: any, index: number) => {
          // Utiliser les coordonnées Tesseract si disponibles, sinon vide
          const manuscriptData = manuscriptDetections[index] || { hasManuscript: false, zones: [], globalBoundingBox: undefined };
          
          return {
          // Navigation
          page_number_doc: page.page_number_doc || index + 1,
          document_type: page.document_type || "inconnu",
          page_number: page.page_number || index + 1,
          total_pages: page.total_pages || imageDataUrls.length,
          is_continuation: page.is_continuation || false,

          // Champs DEVIS & FACTURE
          nom_client: page.nom_client || "",
          siret_client: page.siret_client || "",
          adresse_entreprise_client: page.adresse_entreprise_client || "",
          adresse_travaux: page.adresse_travaux || "",
          date_emission: page.date_emission || "",

          // Champs CONTRAT DE PARTENARIAT
          date_contrat: page.date_contrat || "",
          nom_beneficiaire_contrat: page.nom_beneficiaire_contrat || "",
          adresse_beneficiaire_contrat: page.adresse_beneficiaire_contrat || "",
          nom_entreprise_prestataire: page.nom_entreprise_prestataire || "",
          nom_representant_prestataire: page.nom_representant_prestataire || "",
          siret_prestataire: page.siret_prestataire || "",
          adresse_prestataire: page.adresse_prestataire || "",
          date_signature: page.date_signature || "",

          // Champs INCITATION FINANCIERE
          nom_beneficiaire: page.nom_beneficiaire || "",
          siren_beneficiaire: page.siren_beneficiaire || "",
          adresse_beneficiaire: page.adresse_beneficiaire || "",
          nom_entreprise_oblige: page.nom_entreprise_oblige || "",
          siret_oblige: page.siret_oblige || "",
          adresse_oblige: page.adresse_oblige || "",
          nom_societe_signataire: page.nom_societe_signataire || "",
          nom_signataire: page.nom_signataire || "",
          fonction_signataire: page.fonction_signataire || "",
          infos_tampons: page.infos_tampons || [],

          // Montant (partagé)
          amount_ht: page.amount_ht || 0,
          taux_tva: page.taux_tva || 0,
          amount_ttc: page.amount_ttc || 0,

          // Tampon (partagé sauf incitation)
          tampon_present: page.tampon_present || false,
          infos_tampon: {
            nom: page.infos_tampon?.nom || "",
            adresse: page.infos_tampon?.adresse || "",
            siret: page.infos_tampon?.siret || ""
          },

          // Éléments manuscrits partagés
          bon_pour_accord: page.bon_pour_accord || false,
          lu_et_approuve: page.lu_et_approuve || false,
          signature_manuscrite: page.signature_manuscrite || false,
          nom_manuscrit: page.nom_manuscrit || "",
          fonction_manuscrite: page.fonction_manuscrite || "",
          date_manuscrite: page.date_manuscrite || "",

          // Coordonnées englobantes détectées automatiquement par Tesseract
          coordinates_manuscrits: manuscriptData.globalBoundingBox || "",

          // Fiabilité par élément
          fiabilite_manuscrits: page.fiabilite_manuscrits ? {
            tampon: page.fiabilite_manuscrits.tampon || 0,
            signature: page.fiabilite_manuscrits.signature || 0,
            nom_manuscrit: page.fiabilite_manuscrits.nom_manuscrit || 0,
            fonction_manuscrite: page.fiabilite_manuscrits.fonction_manuscrite || 0,
            date_manuscrite: page.fiabilite_manuscrits.date_manuscrite || 0,
            bon_pour_accord: page.fiabilite_manuscrits.bon_pour_accord || 0,
            lu_et_approuve: page.fiabilite_manuscrits.lu_et_approuve || 0
          } : undefined,

          // ATTESTATION CEE
          is_attestation_cee: page.is_attestation_cee || false,
          attestation_parts: page.attestation_parts ? {
            part_a_present: page.attestation_parts.part_a_present || false,
            part_a_dates: {
              engagement: page.attestation_parts.part_a_dates?.engagement || "",
              realisation: page.attestation_parts.part_a_dates?.realisation || "",
              visite: page.attestation_parts.part_a_dates?.visite || ""
            },
            part_b_present: page.attestation_parts.part_b_present || false,
            part_b_company_info: {
              adresse: page.attestation_parts.part_b_company_info?.adresse || "",
              nom_signataire: page.attestation_parts.part_b_company_info?.nom_signataire || "",
              prenom_signataire: page.attestation_parts.part_b_company_info?.prenom_signataire || "",
              fonction_signataire: page.attestation_parts.part_b_company_info?.fonction_signataire || "",
              raison_sociale: page.attestation_parts.part_b_company_info?.raison_sociale || "",
              siren: page.attestation_parts.part_b_company_info?.siren || ""
            },
            part_b_signature_manuscrite: page.attestation_parts.part_b_signature_manuscrite || false,
            part_b_date_manuscrite: page.attestation_parts.part_b_date_manuscrite || "",
            part_c_present: page.attestation_parts.part_c_present || false,
            part_c_company_info: {
              adresse: page.attestation_parts.part_c_company_info?.adresse || "",
              nom_signataire: page.attestation_parts.part_c_company_info?.nom_signataire || "",
              prenom_signataire: page.attestation_parts.part_c_company_info?.prenom_signataire || "",
              fonction_signataire: page.attestation_parts.part_c_company_info?.fonction_signataire || "",
              raison_sociale: page.attestation_parts.part_c_company_info?.raison_sociale || "",
              siret: page.attestation_parts.part_c_company_info?.siret || ""
            },
            part_c_signature_manuscrite: page.attestation_parts.part_c_signature_manuscrite || false,
            part_c_date_manuscrite: page.attestation_parts.part_c_date_manuscrite || ""
          } : undefined
        };
        });
      } catch (parseError) {
        console.error("Erreur lors du parsing JSON:", parseError);
        throw new Error(`Erreur de parsing: ${parseError.message}`);
      }
    } else {
      throw new Error("Format de réponse OpenAI invalide");
    }
  } catch (error) {
    console.error("Erreur lors de l'analyse avec GPT Vision:", error);
    throw error;
  }
};

// Fonction pour analyser plusieurs documents ensemble - implémentation réelle du traitement par lots
export const analyzeMultipleDocumentsWithGpt = async (files: File[]): Promise<BatchAnalysisResult> => {
  try {
    console.log(`Démarrage du traitement par lots: ${files.length} fichiers à analyser...`);
    
    // Variables pour suivre la progression
    let processedCount = 0;
    const totalCount = files.length;
    
    // Analyser chaque document individuellement
    const individualAnalyses = [];
    const errors = [];
    
    for (const file of files) {
      try {
        console.log(`Analyse du fichier ${++processedCount}/${totalCount}: ${file.name}`);
        
        // Mettre à jour la progression (en pourcentage)
        const progressPercent = Math.round((processedCount / totalCount) * 100);
        
        // Déclencher un événement personnalisé pour informer l'UI de la progression
        window.dispatchEvent(new CustomEvent('batchProcessProgress', { 
          detail: { 
            progress: progressPercent,
            currentFile: file.name,
            processedCount,
            totalCount
          } 
        }));
        
        // Analyser le document
        const result = await analyzeDocumentWithGpt(file);
        
        // Ajouter le nom du fichier au résultat
        const analysisWithFilename = {
          ...result,
          filename: file.name,
          timestamp: new Date().toISOString()
        };
        
        individualAnalyses.push(analysisWithFilename);
        
        // Notifier que ce fichier est terminé
        window.dispatchEvent(new CustomEvent('toast', { 
          detail: { 
            title: `Analyse terminée (${processedCount}/${totalCount})`,
            description: `Le fichier "${file.name}" a été analysé avec succès.`
          } 
        }));
      } catch (error) {
        console.error(`Erreur lors de l'analyse du fichier ${file.name}:`, error);
        errors.push({
          filename: file.name,
          error: error instanceof Error ? error.message : "Erreur inconnue"
        });
        
        // Notifier l'erreur
        window.dispatchEvent(new CustomEvent('toast', { 
          detail: { 
            title: `Erreur d'analyse (${processedCount}/${totalCount})`,
            description: `Problème lors de l'analyse de "${file.name}".`,
            variant: "destructive"
          } 
        }));
      }
      
      // Petite pause entre chaque analyse pour éviter de surcharger l'API
      if (processedCount < totalCount) {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
    
    // Générer un rapport global
    const globalAnalysis = generateBatchReport(individualAnalyses);
    
    return {
      individual_analyses: individualAnalyses,
      global_analysis: globalAnalysis,
      errors: errors.length > 0 ? errors : undefined,
      error: errors.length > 0 ? `Erreurs lors de l'analyse de ${errors.length} documents` : undefined
    };
  } catch (error) {
    console.error("Erreur lors de l'analyse globale:", error);
    return {
      individual_analyses: [],
      errors: [{
        filename: "unknown",
        error: error instanceof Error ? error.message : "Erreur inconnue lors de l'analyse multiple"
      }],
      error: error instanceof Error ? error.message : "Erreur inconnue lors de l'analyse multiple",
      global_analysis: {
        score: 0,
        document_types_found: {},
        unique_sirets: [],
        valid_documents: 0,
        total_documents: 0,
        siret_consistency: "incohérent"
      }
    };
  }
};

// Fonction pour générer un rapport global à partir des analyses individuelles
function generateBatchReport(analyses: DocumentAnalysis[]): BatchAnalysisResult['global_analysis'] {
  // Filtrer les analyses avec erreur
  const validAnalyses = analyses.filter(a => !a.error);
  
  if (validAnalyses.length === 0) {
    return {
      score: 0,
      document_types_found: {},
      unique_sirets: [],
      valid_documents: 0,
      total_documents: analyses.length,
      siret_consistency: "incohérent"
    };
  }
  
  // Extraire les types de documents trouvés
  const documentTypes = validAnalyses.map(a => a.document_type);
  const documentTypeCounts: Record<string, number> = {};
  
  documentTypes.forEach(type => {
    if (type && type !== "inconnu") {
      documentTypeCounts[type] = (documentTypeCounts[type] || 0) + 1;
    }
  });
  
  // Extraire les informations sur les entreprises (SIRET, etc.)
  const siretsList = validAnalyses
    .map(a => a.siret_client || a.siret_prestataire || a.siret_oblige || "")
    .filter(s => s && s.length === 14);
  
  const uniqueSirets = [...new Set(siretsList)];
  
  // Calculer un score global (exemple simple)
  const scoreFactors = {
    documentTypesDiversity: Object.keys(documentTypeCounts).length / 3, // Idéalement 3 types (devis, facture, attestation)
    siretConsistency: uniqueSirets.length === 1 ? 1 : 0.5 / uniqueSirets.length, // Idéalement 1 seul SIRET
    validDocumentsRatio: validAnalyses.length / analyses.length
  };
  
  const globalScore = Math.round(
    (scoreFactors.documentTypesDiversity * 30 +
    scoreFactors.siretConsistency * 40 +
    scoreFactors.validDocumentsRatio * 30)
  );
  
  return {
    score: Math.min(100, Math.max(0, globalScore)),
    document_types_found: documentTypeCounts,
    unique_sirets: uniqueSirets,
    valid_documents: validAnalyses.length,
    total_documents: analyses.length,
    siret_consistency: uniqueSirets.length === 1 ? "cohérent" : "incohérent"
  };
}
