/* eslint-disable @typescript-eslint/no-explicit-any */

import { pdfjs } from 'react-pdf';
import { convertPdfToImages, PDF_CONVERSION } from './utils/fileUtils';

// Initialisation de PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

export interface SplitDocuments {
  devis: File | null;
  facture: File | null;
  attestation: File | null;
}

// Fonction pour diviser un PDF en plusieurs documents
export const splitPdfIntoDocuments = async (pdfFile: File): Promise<SplitDocuments> => {
  try {
    console.log("Étape 1/6: Chargement du PDF...");
    
    // Charger le PDF
    const fileArrayBuffer = await pdfFile.arrayBuffer();
    const pdf = await pdfjs.getDocument({ data: fileArrayBuffer }).promise;
    const numPages = pdf.numPages;
    
    console.log(`Étape 2/6: PDF chargé avec ${numPages} pages`);
    
    // Catégories de documents
    const devisPages: number[] = [];
    const facturePages: number[] = [];
    const attestationPages: number[] = [];
    
    // Analyser chaque page pour déterminer son type
    for (let i = 1; i <= numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(' ').toLowerCase();
      
      // Identification basée sur le texte (simplifié)
      if (pageText.includes('devis') || pageText.includes('bon de commande')) {
        devisPages.push(i);
      } else if (pageText.includes('facture') || pageText.includes('règlement')) {
        facturePages.push(i);
      } else if (pageText.includes('attestation') || pageText.includes('sur l\'honneur')) {
        attestationPages.push(i);
      } else {
        // Page non identifiée - attribution basée sur heuristiques
        if (i === 1 && numPages > 2) {
          // Première page souvent un devis
          devisPages.push(i);
        } else if (i === numPages) {
          // Dernière page souvent une attestation
          attestationPages.push(i);
        } else if (pageText.includes('montant') || pageText.includes('paiement') || pageText.includes('ttc')) {
          // Probablement une facture
          facturePages.push(i);
        } else {
          // Par défaut, considérer comme partie de l'attestation
          attestationPages.push(i);
        }
      }
    }
    
    console.log("Étape 3/6: Classification des pages terminée");
    console.log(`Devis: ${devisPages.length} pages, Facture: ${facturePages.length} pages, Attestation: ${attestationPages.length} pages`);
    
    // Si aucune page n'est identifiée pour un document, utiliser des pages par défaut
    if (devisPages.length === 0 && numPages >= 1) devisPages.push(1);
    if (facturePages.length === 0 && numPages >= 2) facturePages.push(2);
    if (attestationPages.length === 0 && numPages >= 3) attestationPages.push(3);
    
    // Fonction pour créer un fichier à partir d'une page PDF
    async function createImageFromPage(pageNum: number, name: string): Promise<File | null> {
      try {
        const page = await pdf.getPage(pageNum);
        // Utiliser notre résolution optimale pour l'analyse
        const scale = PDF_CONVERSION.ANALYSIS_DPI / 72;
        const viewport = page.getViewport({ scale });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        await page.render({
          canvasContext: context as any,
          viewport: viewport
        }).promise;
        
        // Convertir le canvas en blob
        const blob = await new Promise<Blob>(resolve => {
          canvas.toBlob(blob => resolve(blob as Blob), 'image/jpeg', PDF_CONVERSION.JPEG_QUALITY);
        });
        
        // Créer un fichier à partir du blob
        return new File([blob], `${name}_page${pageNum}.jpeg`, { type: 'image/jpeg' });
      } catch (error) {
        console.error(`Erreur lors de la création de l'image pour la page ${pageNum}:`, error);
        return null;
      }
    }
    
    // Fonction pour créer un fichier composite à partir de plusieurs pages
    async function createDocumentFromPages(pages: number[], docType: string): Promise<File | null> {
      if (pages.length === 0) return null;
      
      // Si une seule page, on retourne directement l'image de cette page
      if (pages.length === 1) {
        return createImageFromPage(pages[0], docType);
      }
      
      // Pour le moment, on utilise juste la première page comme représentative
      // Dans une version plus avancée, on pourrait fusionner les images
      console.log(`Création d'une image pour le document ${docType} à partir de la page ${pages[0]}`);
      return createImageFromPage(pages[0], docType);
    }
    
    console.log("Étape 4/6: Création des images pour chaque page...");
    
    // Créer les fichiers pour chaque type de document
    const [devisFile, factureFile, attestationFile] = await Promise.all([
      createDocumentFromPages(devisPages, 'devis'),
      createDocumentFromPages(facturePages, 'facture'),
      createDocumentFromPages(attestationPages, 'attestation')
    ]);
    
    console.log("Étape 5/6: Documents séparés créés avec succès");
    
    return {
      devis: devisFile,
      facture: factureFile,
      attestation: attestationFile
    };
  } catch (error) {
    console.error("Erreur lors de la séparation du PDF:", error);
    throw new Error("Impossible de séparer le PDF en documents distincts");
  }
}

// Fonction pour extraire toutes les pages d'un PDF sous forme d'images
export const extractAllPagesAsImages = async (pdfFile: File): Promise<File[]> => {
  try {
    console.log("Extraction de toutes les pages du PDF en images...");
    
    // Charger le PDF
    const fileArrayBuffer = await pdfFile.arrayBuffer();
    const pdf = await pdfjs.getDocument({ data: fileArrayBuffer }).promise;
    const numPages = pdf.numPages;
    
    console.log(`PDF chargé avec ${numPages} pages à extraire`);
    
    const pagePromises: Promise<File | null>[] = [];
    
    // Convertir chaque page en image avec la résolution optimale pour l'analyse
    const scale = PDF_CONVERSION.ANALYSIS_DPI / 72;
    
    // Convertir chaque page en image
    for (let i = 1; i <= numPages; i++) {
      pagePromises.push(
        (async (pageNum) => {
          try {
            const page = await pdf.getPage(pageNum);
            const viewport = page.getViewport({ scale });
            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d');
            
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            
            await page.render({
              canvasContext: context as any,
              viewport: viewport
            }).promise;
            
            // Convertir le canvas en blob
            const blob = await new Promise<Blob>(resolve => {
              canvas.toBlob(blob => resolve(blob as Blob), 'image/jpeg', PDF_CONVERSION.JPEG_QUALITY);
            });
            
            // Créer un fichier à partir du blob
            return new File([blob], `page_${pageNum}.jpeg`, { type: 'image/jpeg' });
          } catch (error) {
            console.error(`Erreur lors de la création de l'image pour la page ${pageNum}:`, error);
            return null;
          }
        })(i)
      );
    }
    
    // Attendre que toutes les conversions soient terminées
    const pageFiles = await Promise.all(pagePromises);
    
    // Filtrer les pages nulles (en cas d'erreur)
    const validFiles = pageFiles.filter(file => file !== null) as File[];
    
    console.log(`${validFiles.length} pages extraites avec succès`);
    
    return validFiles;
  } catch (error) {
    console.error("Erreur lors de l'extraction des pages:", error);
    throw new Error("Impossible d'extraire les pages du PDF");
  }
}
