
import Tesseract from 'tesseract.js';
import { createValidImageUrl } from './utils/fileUtils';

// Clé API OpenAI (à sécuriser dans un environnement de production)
const OPENAI_API_KEY = "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";

// Modèle OpenAI
const MODEL = "gpt-4o";

// Construction du prompt simplifié pour l'analyse rapide
function buildPrompt(ocrText: string): string {
  return `
Analysez ce document CEE français. Extrayez:

- Nom de l'entreprise
- Numéro SIRET (14 chiffres)
- Adresse
- Type de document (devis/facture/attestation)
- Date
- Montant TTC
- Tampon entreprise présent (oui/non)
- "Bon pour accord" présent (oui/non)
- Signature présente (oui/non)
- Nom manuscrit
- Fonction manuscrite

Répondez STRICTEMENT au format JSON suivant sans texte supplémentaire:

{
  "entreprise": {
    "nom": "",
    "siret": "",
    "adresse": ""
  },
  "document": {
    "type": "",
    "date": "",
    "montantTTC": 0
  },
  "signatures": {
    "tamponPresent": false,
    "bonPourAccord": false,
    "signaturePresente": false,
    "nomManuscrit": "",
    "fonctionManuscrite": ""
  }
}

Document:
"""
${ocrText}
"""
`;
}

// Fonction OCR pour extraire le texte d'une image/page
async function extractTextFromImage(imageData: string | File): Promise<string> {
  try {
    // Si c'est un fichier, on crée une URL valide
    const imageUrl = typeof imageData === 'string' ? imageData : await createValidImageUrl(imageData, true);
    
    console.log("Exécution de l'OCR...");
    const worker = await Tesseract.createWorker('fra');
    const result = await worker.recognize(imageUrl);
    await worker.terminate();
    
    return result.data.text;
  } catch (error) {
    console.error("Erreur lors de l'OCR:", error);
    return "";
  }
}

// Fonction pour analyser une page avec GPT-4o
async function analyzePage(pageNumber: number, pageText: string): Promise<string> {
  const prompt = buildPrompt(pageText);
  
  try {
    console.log(`Analyse de la page ${pageNumber} avec GPT-4o...`);
    
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          {
            role: "system",
            content: "Vous êtes un expert en analyse de documents CEE. Votre tâche est d'extraire les informations demandées et de les formater EXACTEMENT dans le format JSON spécifié, sans texte supplémentaire."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.1,
        max_tokens: 500, // Réduction des tokens pour accélérer le traitement
        response_format: { type: "json_object" } // Force GPT à retourner du JSON valide
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Erreur API OpenAI: ${response.status} - ${JSON.stringify(errorData)}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content;
    
    // Validation que le contenu est bien du JSON
    try {
      // Vérification simple que le contenu est parsable
      JSON.parse(content);
      return content;
    } catch (e) {
      console.error("La réponse n'est pas un JSON valide:", content);
      
      // Fallback : retourner un JSON valide mais vide
      return JSON.stringify({
        entreprise: { nom: "", siret: "", adresse: "" },
        document: { type: "", date: "", montantTTC: 0 },
        signatures: { tamponPresent: false, bonPourAccord: false, signaturePresente: false, nomManuscrit: "", fonctionManuscrite: "" }
      });
    }
  } catch (error) {
    console.error(`Erreur lors de l'analyse de la page ${pageNumber}:`, error);
    
    // Fallback : retourner un JSON valide mais avec erreur
    return JSON.stringify({
      entreprise: { nom: "", siret: "", adresse: "" },
      document: { type: "", date: "", montantTTC: 0 },
      signatures: { tamponPresent: false, bonPourAccord: false, signaturePresente: false, nomManuscrit: "", fonctionManuscrite: "" },
      error: error instanceof Error ? error.message : "Erreur inconnue"
    });
  }
}

// Fonction pour traiter séquentiellement les images extraites d'un PDF
export async function processDocumentImages(images: (string | File)[]): Promise<{ pageNumber: number, result: string }[]> {
  const results = [];
  
  // Traiter toutes les pages sans limite
  const totalPages = images.length;
  
  for (let i = 0; i < totalPages; i++) {
    const image = images[i];
    console.log(`Traitement de l'image/page ${i + 1}/${totalPages}...`);
    
    // Extraction du texte par OCR
    const extractedText = await extractTextFromImage(image);
    
    // Analyse du texte avec GPT-4o
    const analysisResult = await analyzePage(i + 1, extractedText);
    
    results.push({
      pageNumber: i + 1,
      result: analysisResult
    });
    
    // Attendre un court délai pour éviter les limites de débit de l'API
    if (i < images.length - 1) {
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }
  
  return results;
}

// Fonction pour traiter un document PDF complet
export async function processDocument(file: File): Promise<{ pageNumber: number, result: string }[]> {
  try {
    // Importer dynamiquement le module pdfjs si nécessaire
    const { extractAllPagesAsImages } = await import('./pdfSplitter');
    
    console.log("Extraction des pages du PDF...");
    const pageImages = await extractAllPagesAsImages(file);
    
    if (pageImages.length === 0) {
      throw new Error("Aucune page n'a pu être extraite du PDF");
    }
    
    console.log(`${pageImages.length} pages extraites avec succès.`);
    return await processDocumentImages(pageImages);
  } catch (error) {
    console.error("Erreur lors du traitement du document:", error);
    return [{
      pageNumber: 0,
      result: JSON.stringify({
        entreprise: { nom: "", siret: "", adresse: "" },
        document: { type: "", date: "", montantTTC: 0 },
        signatures: { tamponPresent: false, bonPourAccord: false, signaturePresente: false, nomManuscrit: "", fonctionManuscrite: "" },
        error: error instanceof Error ? error.message : "Erreur inconnue"
      })
    }];
  }
}
