/* eslint-disable @typescript-eslint/no-explicit-any */

// Gardons les imports existants
import { AnalysisResult, CheckResult } from '@/types/document';
import { analyzeDocumentWithGpt } from './gptVisionService';
import { splitPdfIntoDocuments, extractAllPagesAsImages } from './pdfSplitter';
import { 
  verifySiretConsistency, 
  verifySiretValidity, 
  verifyAmountsConsistency,
  verifyDatesConsistency,
  verifyManuscriptMentions,
  verifyStamp,
  verifyWorkAddress,
  verifyNameConsistency,
  verifyRoleConsistency,
  verifyBonPourAccord,
  verifyDocumentDateConsistency,
  verifyAllDatesConsistency
} from './documentVerificationService';
import { verifyDocumentConsistency } from './siretVerificationService';
import { createValidImageUrl } from './utils/fileUtils';

// Fonction pour analyser un dossier PDF unique et le diviser
export const analyzeSinglePdf = async (pdfFile: File): Promise<AnalysisResult> => {
  try {
    console.log("Étape 1/2: Extraction des pages du PDF...");
    
    // Extraire toutes les pages comme images individuelles
    const pageImages = await extractAllPagesAsImages(pdfFile);
    
    if (pageImages.length === 0) {
      throw new Error("Aucune page n'a pu être extraite du PDF");
    }

    // Convertir en tableau si un seul fichier
    const fileArray = Array.isArray(pageImages) ? pageImages : [pageImages];
    
    // Convertir tous les fichiers en URLs d'images
    const imageDataUrls = await Promise.all(fileArray.map(file => createValidImageUrl(file)));
    
    // Analyser toutes les pages en une seule requête
    console.log("Étape 2/2: Analyse des pages avec GPT Vision...");
    const pageResults = await analyzeDocumentWithGpt(imageDataUrls);
    
    // Vérifier si nous avons des résultats exploitables
    if (pageResults.length === 0) {
      throw new Error("Aucune page n'a pu être analysée correctement");
    }
    
    // Regrouper les pages par document
    const documents: { [key: string]: any[] } = {};
    let currentDocument: string | null = null;
    
    const imagesUrlWithSize = await Promise.all(pageImages.map(page => createValidImageUrl(page)));
    
    pageResults.forEach((page, index) => {
      // Si c'est une continuation, utiliser le document en cours
      if (page.is_continuation && currentDocument) {
        documents[currentDocument].push({
          page: index + 1,
          image: imagesUrlWithSize[index],
          analysis: page
        });
      } else {
        // Créer un nouveau document
        const docType = page.document_type.toLowerCase();
        
        // Extraire le nom et SIRET selon le type de document
        let companyName = '';
        let siret = '';
        
        if (docType.includes('devis') || docType.includes('facture')) {
          companyName = page.nom_client || '';
          siret = page.siret_client || '';
        } else if (docType.includes('contrat')) {
          companyName = page.nom_entreprise_prestataire || '';
          siret = page.siret_prestataire || '';
        } else if (docType.includes('incitation')) {
          companyName = page.nom_entreprise_oblige || '';
          siret = page.siret_oblige || '';
        } else if (docType.includes('attestation')) {
          // Pour les attestations, essayer partie B ou C
          companyName = page.attestation_parts?.part_b_company_info?.raison_sociale || 
                       page.attestation_parts?.part_c_company_info?.raison_sociale || '';
          siret = page.attestation_parts?.part_b_company_info?.siren || 
                 page.attestation_parts?.part_c_company_info?.siret || '';
        }
        
        const docKey = `${docType}_${companyName}_${siret}`;
        currentDocument = docKey;
        
        if (!documents[docKey]) {
          documents[docKey] = [];
        }
        
        documents[docKey].push({
          page: index + 1,
          image: imagesUrlWithSize[index],
          analysis: page
        });
      }
    });    
    
    // Convertir les documents en format attendu
    const rawResults = {
      allPages: pageResults,
      documents: Object.entries(documents).map(([key, pages]) => {
        const firstPage = pages[0].analysis;
        const docType = firstPage.document_type.toLowerCase();
        
        // Extraire company et siret selon le type de document
        let company = '';
        let siret = '';
        
        if (docType.includes('devis') || docType.includes('facture')) {
          company = firstPage.nom_client || '';
          siret = firstPage.siret_client || '';
        } else if (docType.includes('contrat')) {
          company = firstPage.nom_entreprise_prestataire || '';
          siret = firstPage.siret_prestataire || '';
        } else if (docType.includes('incitation')) {
          company = firstPage.nom_entreprise_oblige || '';
          siret = firstPage.siret_oblige || '';
        } else if (docType.includes('attestation')) {
          company = firstPage.attestation_parts?.part_b_company_info?.raison_sociale || 
                   firstPage.attestation_parts?.part_c_company_info?.raison_sociale || '';
          siret = firstPage.attestation_parts?.part_b_company_info?.siren || 
                 firstPage.attestation_parts?.part_c_company_info?.siret || '';
        }
        
        return {
          type: firstPage.document_type,
          company: company,
          siret: siret,
          pages: pages.map(p => ({
            page: p.page,
            image: p.image,
            analysis: p.analysis
          }))
        };
      })
    };

    console.log(rawResults);
    
    
    // Calculer le score global
    const score = calculateGlobalScore(rawResults.documents);
    
    // Générer les vérifications
    const checks = generateDocumentChecks(rawResults.documents);
    
    // Générer les recommandations
    const recommendations = generateDocumentRecommendations(rawResults.documents);
    
    return {
      score,
      timestamp: new Date().toISOString(),
      checks,
      recommendations,
      rawResults
    };
    
  } catch (error) {
    console.error("Erreur lors de l'analyse du PDF unique:", error);
    return {
      score: 0,
      timestamp: new Date().toISOString(),
      checks: [
        {
          name: "Erreur d'analyse du PDF",
          status: "error",
          details: `Une erreur est survenue lors de l'analyse du PDF: ${error instanceof Error ? error.message : 'Erreur inconnue'}`
        }
      ],
      recommendations: [
        "Vérifiez que votre PDF est lisible et contient bien des documents distincts",
        "Essayez d'utiliser le mode 'Documents séparés' et téléversez chaque document individuellement",
        "Assurez-vous que votre PDF n'est pas protégé ou corrompu"
      ],
      error: error instanceof Error ? error.message : 'Erreur inconnue'
    };
  }
};

// Fonction pour calculer le score global
function calculateGlobalScore(documents: any[]): number {
  let totalScore = 0;
  let totalWeight = 0;
  
  documents.forEach(doc => {
    // Score pour chaque document
    let docScore = 0;
    let docWeight = 0;
    
    // Vérifier la présence des éléments essentiels
    if (doc.pages[0].analysis.company_name) {
      docScore += 10;
      docWeight += 10;
    }
    if (doc.pages[0].analysis.siret) {
      docScore += 15;
      docWeight += 15;
    }
    if (doc.pages[0].analysis.address) {
      docScore += 10;
      docWeight += 10;
    }
    if (doc.pages[0].analysis.document_type) {
      docScore += 10;
      docWeight += 10;
    }
    if (doc.pages[0].analysis.date) {
      docScore += 10;
      docWeight += 10;
    }
    if (doc.pages[0].analysis.amount_ttc) {
      docScore += 10;
      docWeight += 10;
    }
    
    // Vérifier les éléments manuscrits et tampons
    const hasStamp = doc.pages.some(p => p.analysis.stamp_present);
    const hasSignature = doc.pages.some(p => p.analysis.signature);
    const hasBonPourAccord = doc.pages.some(p => p.analysis.bon_pour_accord);
    
    if (hasStamp) {
      docScore += 10;
      docWeight += 10;
    }
    if (hasSignature) {
      docScore += 10;
      docWeight += 10;
    }
    if (hasBonPourAccord) {
      docScore += 5;
      docWeight += 5;
    }
    
    // Ajouter le score pondéré du document
    if (docWeight > 0) {
      totalScore += (docScore / docWeight) * 100;
      totalWeight += 1;
    }
  });
  
  return totalWeight > 0 ? Math.round(totalScore / totalWeight) : 0;
}

// Fonction pour générer les vérifications
function generateDocumentChecks(documents: any[]): CheckResult[] {
  const checks: CheckResult[] = [];
  
  documents.forEach(doc => {
    // Vérification du type de document
    checks.push({
      name: `Type de document: ${doc.type}`,
      status: "success",
      details: `Document identifié comme ${doc.type}`
    });
    
    // Vérification du SIRET
    if (doc.siret) {
      checks.push({
        name: "Présence du SIRET",
        status: "success",
        details: `SIRET détecté: ${doc.siret}`
      });
    } else {
      checks.push({
        name: "Présence du SIRET",
        status: "warning",
        details: "Aucun SIRET détecté"
      });
    }
    
    // Vérification des éléments manuscrits
    const hasStamp = doc.pages.some(p => p.analysis.stamp_present);
    const hasSignature = doc.pages.some(p => p.analysis.signature);
    const hasBonPourAccord = doc.pages.some(p => p.analysis.bon_pour_accord);
    
    const manuscriptCheck = {
      name: "Éléments manuscrits",
      status: "success" as "success" | "warning" | "error",
      details: "Vérification des éléments manuscrits"
    };
    
    if (hasStamp) {
      manuscriptCheck.details += ", tampon présent";
    } else {
      manuscriptCheck.status = "warning";
      manuscriptCheck.details += ", tampon manquant";
    }
    
    if (hasSignature) {
      manuscriptCheck.details += ", signature présente";
    } else {
      if (manuscriptCheck.status !== "error") manuscriptCheck.status = "warning";
      manuscriptCheck.details += ", signature manquante";
    }
    
    if (hasBonPourAccord) {
      manuscriptCheck.details += ', mention "Bon pour accord" présente';
    } else {
      if (manuscriptCheck.status !== "error") manuscriptCheck.status = "warning";
      manuscriptCheck.details += ', mention "Bon pour accord" manquante';
    }
    
    checks.push(manuscriptCheck);
  });
  
  return checks;
}

// Fonction pour générer les recommandations
function generateDocumentRecommendations(documents: any[]): string[] {
  const recommendations: string[] = [];
  
  documents.forEach(doc => {
    if (!doc.siret) {
      recommendations.push("Vérifiez que le numéro SIRET est clairement visible sur les documents");
    }
    
    const hasStamp = doc.pages.some(p => p.analysis.stamp_present);
    const hasSignature = doc.pages.some(p => p.analysis.signature);
    const hasBonPourAccord = doc.pages.some(p => p.analysis.bon_pour_accord);
    
    if (!hasStamp) {
      recommendations.push("Vérifiez que le tampon de l'entreprise est bien visible sur tous les documents");
    }
    
    if (!hasSignature || !hasBonPourAccord) {
      recommendations.push("Assurez-vous que les éléments manuscrits (signature, mention 'Bon pour accord') sont présents et lisibles");
    }
  });
  
  return recommendations;
}

// Fonction utilitaire pour combiner les images verticalement
async function combineImagesVertically(images: File[]): Promise<File> {
  // Créer un canvas temporaire
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error("Impossible de créer le contexte canvas");
  }
  
  // Calculer les dimensions totales
  let totalHeight = 0;
  let maxWidth = 0;
  
  // Charger toutes les images pour obtenir leurs dimensions
  const loadedImages = await Promise.all(images.map(img => {
    return new Promise<HTMLImageElement>((resolve) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.src = URL.createObjectURL(img);
    });
  }));
  
  // Calculer les dimensions totales
  loadedImages.forEach(img => {
    totalHeight += img.height;
    maxWidth = Math.max(maxWidth, img.width);
  });
  
  // Configurer le canvas
  canvas.width = maxWidth;
  canvas.height = totalHeight;
  
  // Dessiner les images verticalement
  let currentHeight = 0;
  for (const img of loadedImages) {
    ctx.drawImage(img, 0, currentHeight);
    currentHeight += img.height;
  }
  
  // Convertir le canvas en File
  return new Promise((resolve) => {
    canvas.toBlob((blob) => {
      if (blob) {
        resolve(new File([blob], 'combined_document.png', { type: 'image/png' }));
      } else {
        throw new Error("Impossible de créer l'image combinée");
      }
    }, 'image/png');
  });
}

// Fonction pour calculer le score global
function calculateScore(analysis: any): number {
  let score = 0;
  
  // Vérifier la présence des éléments essentiels
  if (analysis.company_name) score += 10;
  if (analysis.siret) score += 15;
  if (analysis.address) score += 10;
  if (analysis.document_type) score += 10;
  if (analysis.date) score += 10;
  if (analysis.amount_ttc) score += 10;
  if (analysis.stamp_present) score += 10;
  if (analysis.signature) score += 10;
  if (analysis.bon_pour_accord) score += 10;
  if (analysis.handwritten_name) score += 5;
  
  return Math.min(100, score);
}

// Fonction pour générer les vérifications
function generateChecks(analysis: any): CheckResult[] {
  const checks: CheckResult[] = [];
  
  // Vérification du SIRET
  if (analysis.siret) {
    checks.push({
      name: "Présence du SIRET",
      status: "success",
      details: `SIRET détecté: ${analysis.siret}`
    });
  } else {
    checks.push({
      name: "Présence du SIRET",
      status: "warning",
      details: "Aucun SIRET détecté"
    });
  }
  
  // Vérification du tampon
  if (analysis.stamp_present) {
    checks.push({
      name: "Présence du tampon",
      status: "success",
      details: "Tampon d'entreprise détecté"
    });
  } else {
    checks.push({
      name: "Présence du tampon",
      status: "warning",
      details: "Aucun tampon d'entreprise détecté"
    });
  }
  
  // Vérification des éléments manuscrits
  const manuscriptCheck = {
    name: "Éléments manuscrits",
    status: "success" as "success" | "warning" | "error",
    details: "Vérification des éléments manuscrits"
  };
  
  if (analysis.handwritten_name) {
    manuscriptCheck.details = `Nom manuscrit détecté: ${analysis.handwritten_name}`;
  } else {
    manuscriptCheck.status = "warning";
    manuscriptCheck.details = "Aucun nom manuscrit détecté";
  }
  
  if (analysis.signature) {
    manuscriptCheck.details += ", signature présente";
  } else {
    if (manuscriptCheck.status !== "error") manuscriptCheck.status = "warning";
    manuscriptCheck.details += ", signature manquante";
  }
  
  if (analysis.bon_pour_accord) {
    manuscriptCheck.details += ', mention "Bon pour accord" présente';
  } else {
    if (manuscriptCheck.status !== "error") manuscriptCheck.status = "warning";
    manuscriptCheck.details += ', mention "Bon pour accord" manquante';
  }
  
  checks.push(manuscriptCheck);
  
  return checks;
}

// Fonction pour générer les recommandations
function generateRecommendations(analysis: any): string[] {
  const recommendations: string[] = [];
  
  if (!analysis.siret) {
    recommendations.push("Vérifiez que le numéro SIRET est clairement visible sur les documents");
  }
  
  if (!analysis.stamp_present) {
    recommendations.push("Vérifiez que le tampon de l'entreprise est bien visible sur tous les documents");
  }
  
  if (!analysis.signature || !analysis.bon_pour_accord) {
    recommendations.push("Assurez-vous que les éléments manuscrits (signature, mention 'Bon pour accord') sont présents et lisibles");
  }
  
  return recommendations;
}

// Fonction pour analyser plusieurs documents
export const analyzeMultipleDocuments = async (
  documents: {
    devis: File | null;
    facture: File | null;
    attestation: File | null;
  }, 
  preAnalyzedResults?: {
    devis: any | null;
    facture: any | null;
    attestation: any | null;
  }
): Promise<AnalysisResult> => {
  const results: Record<string, any> = preAnalyzedResults || {};
  const checks: CheckResult[] = [];
  let score = 0;
  const recommendations: string[] = [];
  let siretFound: string | undefined;
  let rawResults = null;
  
  try {
    // 1. Analyser chaque document avec GPT Vision (si pas déjà analysé)
    for (const [docType, file] of Object.entries(documents)) {
      if (file && !results[docType]) {
        try {
          console.log(`Analyse du document ${docType} avec GPT Vision...`);
          results[docType] = await analyzeDocumentWithGpt(file);
          console.log(`Résultat de l'analyse pour ${docType}:`, results[docType]);
          
          // Si une erreur est détectée dans le résultat, l'ajouter aux vérifications
          if (results[docType]?.error) {
            checks.push({
              name: `Analyse du ${docType}`,
              status: "error",
              details: `Erreur lors de l'analyse: ${results[docType].error}`
            });
          }
        } catch (error) {
          console.error(`Erreur lors de l'analyse du ${docType}:`, error);
          checks.push({
            name: `Analyse du ${docType}`,
            status: "error",
            details: `Erreur: ${error instanceof Error ? error.message : "Erreur inconnue"}`
          });
        }
      }
    }
    
    // Vérifier si nous avons au moins un document analysé correctement
    const hasValidResults = Object.values(results).some(r => r && !r.error);
    
    if (!hasValidResults) {
      throw new Error("Aucun document n'a pu être analysé correctement");
    }
    
    // 2. Extraire les SIRETs pour vérification
    const sirets = Object.entries(results)
      .map(([docType, result]) => result?.siret)
      .filter(Boolean);
    
    if (sirets.length > 0) {
      // Vérifier la cohérence des SIRETs entre les documents
      const siretCheck = verifySiretConsistency(sirets);
      checks.push(siretCheck);
      score += siretCheck.status === "success" ? 15 : 0;
      
      siretFound = [...new Set(sirets)][0];
      
      // 3. Vérifier le SIRET avec l'API INSEE
      if (siretFound) {
        try {
          const siretValidityCheck = await verifySiretValidity(siretFound);
          checks.push(siretValidityCheck);
          score += siretValidityCheck.status === "success" ? 10 : 0;
        } catch (error) {
          console.error("Erreur lors de la vérification SIRET:", error);
          checks.push({
            name: "Vérification SIRET",
            status: "warning",
            details: "Impossible de vérifier la validité du SIRET en ligne"
          });
        }
      }
    } else {
      checks.push({
        name: "Détection SIRET",
        status: "warning",
        details: "Aucun numéro SIRET n'a pu être extrait des documents"
      });
      recommendations.push("Vérifiez que le numéro SIRET est clairement visible sur les documents");
    }
    
    // 4. Vérifier la cohérence des éléments manuscrits
    // Extraction des mentions manuscrites et du tampon
    if (results.attestation) {
      // Vérification des mentions manuscrites
      const manuscriptCheck = {
        name: "Éléments manuscrits",
        status: "success" as "success" | "warning" | "error",
        details: "Vérification des éléments manuscrits dans l'attestation"
      };
      
      // Vérification nom manuscrit
      if (results.attestation.handwritten_name) {
        manuscriptCheck.details = `Nom manuscrit détecté: ${results.attestation.handwritten_name}`;
      } else {
        manuscriptCheck.status = "warning";
        manuscriptCheck.details = "Aucun nom manuscrit détecté dans l'attestation";
      }
      
      // Vérification fonction manuscrite
      if (results.attestation.handwritten_function) {
        manuscriptCheck.details += `, fonction manuscrite: ${results.attestation.handwritten_function}`;
      } else {
        if (manuscriptCheck.status !== "error") manuscriptCheck.status = "warning";
        manuscriptCheck.details += ", aucune fonction manuscrite détectée";
      }
      
      // Vérification bon pour accord
      if (results.attestation.bon_pour_accord) {
        manuscriptCheck.details += ', mention "Bon pour accord" présente';
      } else {
        if (manuscriptCheck.status !== "error") manuscriptCheck.status = "warning";
        manuscriptCheck.details += ', mention "Bon pour accord" manquante';
      }
      
      // Vérification signature
      if (results.attestation.signature) {
        manuscriptCheck.details += ", signature présente";
      } else {
        if (manuscriptCheck.status !== "error") manuscriptCheck.status = "warning";
        manuscriptCheck.details += ", signature manquante";
      }
      
      checks.push(manuscriptCheck);
      score += manuscriptCheck.status === "success" ? 15 : 
              manuscriptCheck.status === "warning" ? 5 : 0;
    }
    
    // 5. Vérifier la présence de tampon sur le devis et la facture
    const docTypes = ["devis", "facture"];
    
    for (const docType of docTypes) {
      if (results[docType]?.stamp_present) {
        checks.push({
          name: `Tampon sur ${docType}`,
          status: "success",
          details: `Tampon d'entreprise détecté sur le ${docType}`
        });
        score += 10;
      } else if (results[docType]) {
        checks.push({
          name: `Tampon sur ${docType}`,
          status: "warning",
          details: `Aucun tampon d'entreprise détecté sur le ${docType}`
        });
      }
    }
    
    // 6. Vérification de la cohérence des dates
    if (results.devis?.date && results.facture?.date) {
      try {
        // Convertir les dates au format JJ/MM/AAAA
        const devisDate = results.devis.date;
        const factureDate = results.facture.date;
        
        const devisDateObj = parseDate(devisDate);
        const factureDateObj = parseDate(factureDate);
        
        if (devisDateObj && factureDateObj) {
          // La facture doit être postérieure ou égale au devis
          const isConsistent = factureDateObj >= devisDateObj;
          
          checks.push({
            name: "Cohérence des dates devis/facture",
            status: isConsistent ? "success" : "warning",
            details: isConsistent ? 
              `Les dates sont cohérentes: devis (${devisDate}) antérieur à la facture (${factureDate})` :
              `Incohérence: la date du devis (${devisDate}) est postérieure à la facture (${factureDate})`
          });
          
          score += isConsistent ? 15 : 0;
        }
      } catch (e) {
        console.error("Erreur lors de la vérification des dates:", e);
      }
    }
    
    // 7. Vérification des montants
    if (results.devis?.amount_ttc && results.facture?.amount_ttc) {
      const devisAmount = parseFloat(results.devis.amount_ttc);
      const factureAmount = parseFloat(results.facture.amount_ttc);
      
      if (!isNaN(devisAmount) && !isNaN(factureAmount)) {
        // On accepte une différence de 1€ maximum
        const isConsistent = Math.abs(devisAmount - factureAmount) <= 1;
        
        checks.push({
          name: "Cohérence des montants",
          status: isConsistent ? "success" : "warning",
          details: isConsistent ? 
            `Les montants sont cohérents: devis (${devisAmount}€) et facture (${factureAmount}€)` :
            `Incohérence: le montant du devis (${devisAmount}€) diffère de la facture (${factureAmount}€)`
        });
        
        score += isConsistent ? 15 : 0;
      }
    }
    
    // Stocker les résultats bruts pour l'affichage détaillé
    rawResults = results;
    
    // Ajouter des recommandations en fonction des résultats
    if (checks.some(check => check.status === "warning" || check.status === "error")) {
      const warningChecks = checks.filter(check => check.status === "warning" || check.status === "error");
      
      warningChecks.forEach(check => {
        if (check.name.includes("SIRET")) {
          recommendations.push("Vérifiez que le numéro SIRET est clairement visible et identique sur tous les documents");
        } else if (check.name.includes("Analyse")) {
          recommendations.push("Essayez d'améliorer la qualité des documents ou réessayez l'analyse");
        } else if (check.name.includes("Tampon")) {
          recommendations.push("Vérifiez que le tampon de l'entreprise est bien visible sur tous les documents");
        } else if (check.name.includes("manuscrit")) {
          recommendations.push("Assurez-vous que les éléments manuscrits (nom, fonction, signature, mention 'Bon pour accord') sont présents et lisibles");
        } else if (check.name.includes("dates")) {
          recommendations.push("Vérifiez la cohérence chronologique des dates sur vos documents");
        } else if (check.name.includes("montants")) {
          recommendations.push("Vérifiez que les montants sont identiques entre le devis et la facture");
        }
      });
    }
    
    // Si nous n'avons pas beaucoup de vérifications, ajouter une recommandation générale
    if (checks.length < 3) {
      recommendations.push("L'analyse n'a pu extraire que peu d'informations. Essayez d'améliorer la qualité des documents ou de réessayer.");
    }
    
    // Retourner le rapport d'analyse final
    return {
      score: Math.min(100, Math.max(0, score)), // Limiter le score entre 0 et 100
      timestamp: new Date().toISOString(),
      checks,
      recommendations,
      siretFound,
      rawResults,
      error: undefined
    };
  } catch (error) {
    console.error("Erreur générale lors de l'analyse:", error);
    // Retourner un résultat d'erreur
    return {
      score: 0,
      timestamp: new Date().toISOString(),
      checks: [
        {
          name: "Erreur d'analyse",
          status: "error",
          details: `Une erreur est survenue lors de l'analyse: ${error instanceof Error ? error.message : 'Erreur inconnue'}`
        }
      ],
      recommendations: [
        "Assurez-vous que les documents téléchargés sont dans un format supporté (PNG, JPEG, GIF, WEBP, PDF)",
        "Vérifiez que les documents sont suffisamment lisibles",
        "Si vous utilisez le mode PDF unique, essayez plutôt le mode documents séparés"
      ],
      error: error instanceof Error ? error.message : 'Erreur inconnue',
      rawResults
    };
  }
};

// Fonction utilitaire pour analyser les dates
function parseDate(dateStr: string): Date | null {
  try {
    // Format JJ/MM/AAAA
    const parts = dateStr.split('/');
    if (parts.length === 3) {
      const day = parseInt(parts[0]);
      const month = parseInt(parts[1]) - 1; // Les mois commencent à 0 en JavaScript
      const year = parseInt(parts[2]);
      
      if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
        return new Date(year, month, day);
      }
    }
    
    // Essai avec d'autres formats de date courants
    const date = new Date(dateStr);
    return isNaN(date.getTime()) ? null : date;
  } catch {
    return null;
  }
}
