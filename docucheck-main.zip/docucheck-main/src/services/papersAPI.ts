
import { useToast } from "@/hooks/use-toast";

// Clé API intégrée directement dans l'application - À remplacer par votre clé Papers
const PAPERS_API_KEY = "YOUR_PAPERS_API_KEY";

interface PapersCompanyData {
  name: string;
  siret: string;
  vat_number?: string;
  address?: {
    street?: string;
    postal_code?: string;
    city?: string;
    country?: string;
  };
  legal_form?: string;
  registration_number?: string;
  activity_code?: string;
  creation_date?: string;
  is_active?: boolean;
}

export const fetchCompanyBySiret = async (siret: string): Promise<PapersCompanyData | null> => {
  try {
    console.log(`Fetching company data for SIRET: ${siret}`);
    
    const response = await fetch(`https://api.papers.fr/v1/company?siret=${siret}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${PAPERS_API_KEY}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      console.error("Papers API Error:", errorData);
      throw new Error(`Error ${response.status}: ${errorData?.message || response.statusText}`);
    }

    const data = await response.json();
    return data.data;
  } catch (error) {
    console.error("Error fetching company data:", error);
    return null;
  }
};

export const formatCompanyAddress = (address?: PapersCompanyData['address']): string => {
  if (!address) return '';
  
  const parts = [
    address.street,
    address.postal_code && address.city ? `${address.postal_code} ${address.city}` : (address.postal_code || address.city),
    address.country
  ].filter(Boolean);
  
  return parts.join(', ');
};
