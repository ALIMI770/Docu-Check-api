
export interface StripePackage {
  id: string;
  name: string;
  credits: number;
  price: number;
  description?: string;
  mostPopular?: boolean;
}

// Packages de crédits disponibles
export const getAvailablePackages = (): StripePackage[] => {
  return [
    { 
      id: 'starter', 
      name: 'Démarrage', 
      credits: 10, 
      price: 19.99,
      description: 'Idéal pour tester le service'
    },
    { 
      id: 'standard', 
      name: 'Standard', 
      credits: 50, 
      price: 79.99,
      description: 'Pour les utilisations régulières',
      mostPopular: true
    },
    { 
      id: 'premium', 
      name: 'Premium', 
      credits: 200, 
      price: 249.99,
      description: 'Pour les professionnels' 
    },
    { 
      id: 'enterprise', 
      name: 'Entreprise', 
      credits: 500, 
      price: 499.99,
      description: 'Volume important' 
    },
  ];
};

/**
 * Fonction pour initier un paiement Stripe
 * Dans une application réelle, cette fonction appellerait une API backend qui créerait
 * une session Stripe et retournerait l'URL de la session
 */
export const initiateStripeCheckout = async (packageId: string): Promise<string> => {
  // Simulation d'une API appelant le backend
  console.log(`Initiation du paiement Stripe pour le package ID: ${packageId}`);
  
  // Récupération des informations du package
  const packages = getAvailablePackages();
  const selectedPackage = packages.find(pkg => pkg.id === packageId);
  
  if (!selectedPackage) {
    throw new Error(`Package avec l'ID ${packageId} non trouvé`);
  }
  
  // Simulation d'un délai réseau
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Dans une vraie implémentation, voici ce qui se passerait:
  // 1. Appel à l'API backend (fonction edge dans Supabase)
  // 2. Le backend crée une session Stripe avec les détails du produit
  // 3. Le backend retourne l'URL de la session Stripe
  // 4. Le frontend redirige l'utilisateur vers cette URL
  
  // Pour cette simulation, nous retournons une URL simulée
  const mockSessionId = `cs_test_${Math.random().toString(36).substring(2, 15)}`;
  const mockUniqueId = Date.now().toString();
  
  // URL simulée vers la page de paiement Stripe
  return `https://checkout.stripe.com/c/pay/${mockSessionId}_${packageId}_${mockUniqueId}`;
};

/**
 * Fonction pour vérifier si un paiement a été complété
 * Dans une vraie implémentation, cette fonction vérifierait le statut d'une session Stripe
 */
export const verifyPaymentStatus = async (sessionId: string): Promise<{success: boolean, credits?: number}> => {
  // Simulation d'un délai réseau
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Pour cette simulation, nous retournons toujours un succès
  // Dans une vraie implémentation, vous vérifieriez le statut via une API backend
  
  // Extraire l'ID du package du sessionId simulé
  const parts = sessionId.split('_');
  const packageId = parts.length > 2 ? parts[2] : 'standard';
  
  const packages = getAvailablePackages();
  const selectedPackage = packages.find(pkg => pkg.id === packageId) || packages[1]; // Fallback au package standard
  
  return {
    success: true,
    credits: selectedPackage.credits
  };
};
