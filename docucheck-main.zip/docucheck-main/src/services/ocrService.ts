/* eslint-disable @typescript-eslint/no-explicit-any */
import { DocumentType, AnalysisResult } from '@/types/document';
import { OcrResults } from './types';
import { analyzeMultipleDocuments, analyzeSinglePdf } from './documentAnalyzerService';
import { useToast } from '@/hooks/use-toast';
import { processDocument } from './optimizedDocumentProcessor';

// Main function for document analysis
export const analyzeDocuments = async (
  documents: {
    devis: File | null;
    facture: File | null;
    attestation: File | null;
  },
  singlePdfFile?: File
): Promise<AnalysisResult> => {
  console.log("Démarrage de l'analyse des documents avec la méthode optimisée...");
  
  try {
    // La clé API est maintenant intégrée directement dans l'application
    
    // Utiliser le mode approprié selon le type d'upload
    if (singlePdfFile) {
      console.log('Analyse du dossier PDF complet avec la méthode optimisée...');
      return await analyzeSinglePdf(singlePdfFile);
    } else {
      // Mode documents séparés
      console.log('Analyse des documents séparés avec la méthode optimisée...');
      return await analyzeMultipleDocuments(documents);
    }
  } catch (error) {
    console.error('Erreur lors de l\'analyse des documents:', error);
    
    // Retourner un résultat d'erreur
    return {
      score: 0,
      timestamp: new Date().toISOString(),
      checks: [
        {
          name: "Erreur d'analyse",
          status: "error",
          details: `Une erreur est survenue lors de l'analyse: ${error instanceof Error ? error.message : 'Erreur inconnue'}`
        }
      ],
      recommendations: [
        "Vérifiez que vos documents sont dans un format supporté (PDF)",
        "Assurez-vous que les documents sont suffisamment lisibles",
        "Vérifiez que votre connexion internet est stable"
      ]
    };
  }
};

// Nouvelle fonction pour détecter les zones appropriées pour les tampons
export const detectStampAreas = async (page: any): Promise<{ x: number, y: number }[]> => {
  try {
    // Logique pour détecter les zones appropriées pour les tampons
    // Cette fonction serait utilisée par le service de positionnement
    return [];
  } catch (error) {
    console.error('Erreur lors de la détection des zones de tampon:', error);
    return [];
  }
};

// Ne pas supprimer ces exports car ils pourraient être utilisés ailleurs
export { extractTextFromDocument } from './textExtraction';
export { detectHandwrittenInfo, detectStamp, extractAmounts } from './contentAnalysis';
export { preprocessImage, identifyDocumentZones } from './imageProcessing';
