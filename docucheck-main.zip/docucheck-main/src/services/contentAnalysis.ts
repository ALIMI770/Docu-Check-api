import { HandwrittenInfo } from './types';

// Fonction pour détecter les informations manuscrites (nom, fonction, date)
export const detectHandwrittenInfo = (text: string): HandwrittenInfo => {
  // Recherche de "Bon pour accord" qui apparaît souvent près des signatures
  const bonPourAccordRegex = /bon pour accord|bon p.{0,2}r accord/i;
  const agreementFound = bonPourAccordRegex.test(text);
  
  // Regex pour détecter un nom (prénom et nom en majuscules/minuscules)
  // Plus permissive pour les formats manuscrits courants
  const nameRegex = /([A-Z][a-zéèêëàâäôöùûüïî]+ [A-Z][A-ZÉÈÊËÀÂÄÔÖÙÛÜÏÎa-zéèêëàâäôöùûüïî]+|[A-Z]+ [A-Z][a-zéèêëàâäôöùûüïî]+|[A-Za-zéèêëàâäôöùûüïî]+ [A-Za-zéèêëàâäôöùûüïî]+)/g;
  
  // Expression pour détecter une fonction (gérant, directeur, président...)
  // Plus permissive pour inclure des variations manuscrites
  const functionRegex = /(G[ée]rant|Directeur|Pr[ée]sident|G[ée]rant\(e\)|Directeur\(trice\)|PDG|Responsable|Dirigeant|Manager)/i;
  
  // Expression pour détecter une date au format français
  // Plus robuste pour gérer les différentes façons d'écrire une date
  const dateRegex = /(\d{1,2})[\/\.-](\d{1,2})[\/\.-](20\d{2})/g;
  
  // Détection de signature avec support pour les traces manuscrites
  const signatureRegex = /(sign[ée]|signature|accord)/i;
  
  // Amélioration de la détection des noms
  const names = text.match(nameRegex);
  
  // Filtrage des noms pour éliminer les faux positifs
  const filteredNames = names ? names.filter(name => 
    name.length >= 4 && 
    !name.match(/^(ENGIE|PAGE|DATE|TOTAL|MONTANT|DEVIS|FACTURE)$/)
  ) : [];
  
  // Recherche de fonctions
  const functions = text.match(functionRegex) || [];
  
  // Recherche de dates
  const dates = text.match(dateRegex) || [];
  
  // Détection de signature améliorée
  const hasSignature = 
    signatureRegex.test(text) || 
    bonPourAccordRegex.test(text) || 
    text.includes('xxxx') || 
    text.includes('____') || 
    // Détecte les lignes qui ressemblent à une signature manuscrite
    /[A-Za-z]{1,2}[\.\-\_]{2,}/i.test(text);

  return {
    name: filteredNames.length > 0 ? filteredNames[0] : "",
    function: functions.length > 0 ? functions[0] : "",
    date: dates.length > 0 ? dates[0] : "",
    signature: hasSignature,
    agreement: agreementFound
  };
};

// Fonction pour détecter un tampon d'entreprise
export const detectStamp = (text: string): {
  stampText: string | null;
  companyName: string | null;
  siret: string | null;
} => {
  console.log("Analyse de tampon sur texte:", text.substring(0, 100) + "...");
  
  // Recherche de texte qui ressemble à un nom d'entreprise (souvent en majuscules)
  const stampRegex = /([A-Z]{2,}(?: [A-Z]+){1,5}|ASSOCIATION [A-Z]+( [A-Z]+)*)/g;
  const potentialStamps = text.match(stampRegex) || [];
  
  // Recherche spécifique pour les noms d'entreprise
  const specificCompanyRegex = /(CAR GENESIS|GREEN CLIM|FEELING DANCE|ASSOCIATION)/i;
  const specificCompany = text.match(specificCompanyRegex);
  
  // Recherche de siret/siren qui indique souvent un tampon d'entreprise
  const siretRegex = /(SIRET|SIREN)\s*:?\s*(\d{9}|\d{14})/i;
  const siretMatch = text.match(siretRegex);
  
  // Filtrer pour éliminer les faux positifs
  const filteredStamps = potentialStamps.filter(stamp => 
    stamp.length >= 4 && // Au moins 4 caractères
    !stamp.match(/^(ENGIE|PAGE|DATE|TOTAL|MONTANT|DEVIS|FACTURE)$/) // Exclure des mots courants
  );
  
  const companyName = specificCompany ? specificCompany[0] : 
                       filteredStamps.length > 0 ? filteredStamps[0] : null;
  
  const siret = siretMatch ? siretMatch[2].replace(/\s/g, '') : null;
  
  const stampText = companyName || siret ? 
    `${companyName || "Entreprise"} ${siret ? `(SIRET: ${siret})` : ""}` : null;
  
  return {
    stampText,
    companyName,
    siret
  };
};

// Fonction pour extraire les montants
export const extractAmounts = (text: string): number[] => {
  // Recherche des montants au format euro (1 234,56 € ou 1234,56€ ou 1 234.56 €)
  const amountRegex = /(\d[\d\s]*[,.]\d{2})(?:\s*€|\s*EUR)/g;
  
  // Version améliorée qui détecte aussi les montants sans décimales
  const simpleAmountRegex = /(\d[\d\s]*)(?:\s*€|\s*EUR)/g;
  
  const amounts: number[] = [];
  let match;
  
  // D'abord chercher les montants avec décimales (plus précis)
  while ((match = amountRegex.exec(text)) !== null) {
    try {
      // Nettoyer et convertir en nombre
      const cleanAmount = match[1].replace(/\s/g, '').replace(',', '.');
      amounts.push(parseFloat(cleanAmount));
    } catch (e) {
      console.error('Erreur lors de la conversion du montant:', match[0]);
    }
  }
  
  // Si aucun montant avec décimales n'est trouvé, chercher des montants simples
  if (amounts.length === 0) {
    while ((match = simpleAmountRegex.exec(text)) !== null) {
      try {
        // Nettoyer et convertir en nombre
        const cleanAmount = match[1].replace(/\s/g, '');
        // S'assurer que ce n'est pas juste un chiffre isolé
        if (cleanAmount.length >= 2) {
          amounts.push(parseInt(cleanAmount));
        }
      } catch (e) {
        console.error('Erreur lors de la conversion du montant simple:', match[0]);
      }
    }
  }
  
  return amounts;
};

// Fonction pour vérifier la cohérence des dates entre les documents
export const checkDatesConsistency = (
  devisDate: string | null, 
  factureDate: string | null
): boolean => {
  if (!devisDate || !factureDate) return true;

  const devisParts = devisDate.split(/[\/\.-]/);
  const factureParts = factureDate.split(/[\/\.-]/);
  
  if (devisParts.length === 3 && factureParts.length === 3) {
    const devisDateObj = new Date(parseInt(devisParts[2]), parseInt(devisParts[1]) - 1, parseInt(devisParts[0]));
    const factureDateObj = new Date(parseInt(factureParts[2]), parseInt(factureParts[1]) - 1, parseInt(factureParts[0]));
    
    return factureDateObj >= devisDateObj;
  }
  
  return true;
};

// Fonction pour extraire les numéros de référence
export const extractReferences = (text: string): string[] => {
  // Formats courants de références: XXX-XXX, XXXXXX/XX, etc.
  const refRegex = /(20\d{2}[-\/]\d{3,4}|GRC-20\d{2}-\d{4})/g;
  return text.match(refRegex) || [];
};

// Fonction pour extraire les adresses
export const extractAddress = (text: string): string | null => {
  // Recherche de motifs d'adresse comme "53 RUE PAUL DOUCET" dans l'exemple
  const addressRegex = /(\d{1,4}\s+(?:RUE|AVENUE|BOULEVARD|BD|AV)\s+[A-Za-zÀ-ÿ\s]{3,})/i;
  const addressMatch = text.match(addressRegex);
  
  // Recherche de code postal et ville
  const postalCodeRegex = /(\d{5})\s+([A-Za-zÀ-ÿ\s\-]{3,})/i;
  const postalMatch = text.match(postalCodeRegex);
  
  if (addressMatch) {
    if (postalMatch) {
      return `${addressMatch[0]}, ${postalMatch[0]}`;
    }
    return addressMatch[0];
  }
  
  return null;
};

// Fonction pour vérifier la cohérence du SIRET entre le tampon et l'en-tête
export const verifySiretConsistency = (headerSiret: string | null, stampSiret: string | null): boolean => {
  if (!headerSiret || !stampSiret) {
    return false;
  }
  
  // Normaliser les numéros SIRET (supprimer les espaces, tirets, etc.)
  const normalizedHeaderSiret = headerSiret.replace(/\D/g, '');
  const normalizedStampSiret = stampSiret.replace(/\D/g, '');
  
  // Vérifier si les SIRET sont identiques ou si l'un contient l'autre
  return normalizedHeaderSiret.includes(normalizedStampSiret) || 
         normalizedStampSiret.includes(normalizedHeaderSiret);
};

// Fonction pour extraire le SIRET de l'en-tête
export const extractSiret = (text: string): string | null => {
  // Formats courants de SIRET: 14 chiffres, éventuellement séparés par des espaces
  const siretRegex = /(?:SIRET|SIREN)[^\d]*(\d{3}[ \.]?\d{3}[ \.]?\d{3}[ \.]?\d{5}|\d{3}[ \.]?\d{3}[ \.]?\d{3}|\d{9}|\d{14})/i;
  const match = text.match(siretRegex);
  
  if (match && match[1]) {
    return match[1].replace(/\D/g, ''); // Retourne seulement les chiffres
  }
  
  return null;
};
