import { DocumentZones } from './types';

/**
 * Interface pour les coordonnées de recadrage en pourcentage
 */
interface CropCoordinates {
  x: number;
  y: number;
  width: number;
  height: number;
}

/**
 * Marge en pourcentage à ajouter autour de la zone recadrée
 * pour s'assurer de capturer tout le contenu
 */
const CROP_MARGIN_PERCENT = 0.5;

/**
 * Recadre une image selon des coordonnées spécifiées en pourcentage
 * @param imageDataUrl - Image au format base64 (data URL)
 * @param coordinatesStr - Chaîne de coordonnées au format "x, y, largeur, hauteur" (en pourcentage)
 * @returns Promise résolue avec l'image recadrée au format base64
 * @throws Error si l'image n'est pas fournie, si les coordonnées sont invalides ou si le traitement échoue
 * @example
 * cropImageFromBase64('data:image/jpeg;base64,...', '10, 20, 30, 40')
 *   .then(croppedImage => console.log(croppedImage))
 *   .catch(error => console.error(error));
 */
export const cropImageFromBase64 = (
  imageDataUrl: string | null,
  coordinatesStr: string
): Promise<string> => {
  return new Promise((resolve, reject) => {
    // Validation de l'image
    if (!imageDataUrl) {
      reject(new Error("Aucune image fournie."));
      return;
    }

    // Validation de la chaîne de coordonnées
    if (!coordinatesStr) {
      reject(new Error("Aucune chaîne de coordonnées fournie."));
      return;
    }

    // Conversion et validation des coordonnées
    const coordinates = coordinatesStr
      .split(',')
      .map(coord => parseFloat(coord.trim()));

    if (coordinates.length !== 4 || coordinates.some(isNaN)) {
      reject(
        new Error(
          "Le format des coordonnées doit être 'x, y, largeur, hauteur' (4 valeurs numériques)"
        )
      );
      return;
    }

    const [xPercent, yPercent, widthPercent, heightPercent] = coordinates;

    // Chargement de l'image
    const img = new Image();

    img.onload = () => {
      const imgWidth = img.width;
      const imgHeight = img.height;

      // Convertir les pourcentages en pixels avec marge
      let x = ((xPercent - CROP_MARGIN_PERCENT) / 100) * imgWidth;
      let y = ((yPercent - CROP_MARGIN_PERCENT) / 100) * imgHeight;
      let width = ((widthPercent + 2 * CROP_MARGIN_PERCENT) / 100) * imgWidth;
      let height = ((heightPercent + 2 * CROP_MARGIN_PERCENT) / 100) * imgHeight;

      // Ajuster pour rester dans les limites de l'image
      x = Math.max(0, x);
      y = Math.max(0, y);
      width = Math.min(width, imgWidth - x);
      height = Math.min(height, imgHeight - y);

      // Vérification supplémentaire : s'assurer que les coordonnées ne dépassent pas l'image source
      const safeX = Math.min(x, imgWidth - width);
      const safeY = Math.min(y, imgHeight - height);

      // Créer un canvas pour le traitement
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');

      if (!ctx) {
        reject(new Error("Impossible de créer le contexte canvas"));
        return;
      }

      // Dessiner l'image recadrée à partir des coordonnées sécurisées
      ctx.drawImage(img, safeX, safeY, width, height, 0, 0, width, height);

      // Convertir le canvas en base64
      const croppedBase64 = canvas.toDataURL("image/jpeg");
      resolve(croppedBase64);
    };

    img.onerror = () => {
      reject(new Error("Erreur lors du chargement de l'image"));
    };

    img.src = imageDataUrl;
  });
};

// Fonction pour prétraiter l'image avant OCR
export const preprocessImage = async (file: File): Promise<string> => {
  try {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async (event) => {
        if (!event.target?.result) {
          reject(new Error('Échec de lecture du fichier'));
          return;
        }

        const img = new Image();
        img.onload = () => {
          // Création du canvas pour l'image
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext('2d');
          
          if (!ctx) {
            reject(new Error('Impossible de créer le contexte canvas'));
            return;
          }
          
          // Dessiner l'image sur le canvas
          ctx.drawImage(img, 0, 0);
          
          // Améliorations pour l'OCR
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const data = imageData.data;
          
          // Amélioration adaptative du contraste pour mieux détecter le texte manuscrit et les tampons
          for (let i = 0; i < data.length; i += 4) {
            const avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
            
            // Filtrage adaptatif en fonction de la valeur de gris
            // Préserve mieux les détails des signatures et tampons
            if (avg < 100) {
              // Renforcer les zones sombres (textes, signatures, tampons)
              data[i] = Math.max(0, avg - 30);     // rouge
              data[i + 1] = Math.max(0, avg - 30); // vert
              data[i + 2] = Math.max(0, avg - 30); // bleu
            } else if (avg > 200) {
              // Éclaircir davantage les zones claires (fond)
              data[i] = 255;     // rouge
              data[i + 1] = 255; // vert
              data[i + 2] = 255; // bleu
            } else {
              // Améliorer le contraste pour les zones de valeur moyenne
              const newValue = avg < 150 ? avg * 0.7 : Math.min(255, avg * 1.2);
              data[i] = newValue;     // rouge
              data[i + 1] = newValue; // vert
              data[i + 2] = newValue; // bleu
            }
          }
          
          ctx.putImageData(imageData, 0, 0);
          
          // Conversion du canvas en dataURL
          const processedImageUrl = canvas.toDataURL('image/png');
          resolve(processedImageUrl);
        };
        
        img.onerror = () => {
          reject(new Error('Impossible de charger l\'image'));
        };
        
        // Définir la source de l'image
        img.src = event.target.result as string;
      };
      
      reader.onerror = () => {
        reject(new Error('Erreur lors de la lecture du fichier'));
      };
      
      reader.readAsDataURL(file);
    });
  } catch (error) {
    console.error('Erreur de prétraitement:', error);
    // En cas d'échec, renvoyer l'original
    return URL.createObjectURL(file);
  }
};

// Fonction pour retirer le fond d'une image de tampon et normaliser ses dimensions
export const removeBackgroundFromImage = async (imageElement: HTMLImageElement): Promise<string> => {
  return new Promise((resolve, reject) => {
    try {
      // Dimensions maximales pour le tampon (75mm x 38mm, convertis en pixels approximativement)
      const MAX_STAMP_WIDTH = 283; // 75mm à 96dpi
      const MAX_STAMP_HEIGHT = 143; // 38mm à 96dpi
      
      // Calculer le ratio d'aspect de l'image originale
      const originalRatio = imageElement.naturalWidth / imageElement.naturalHeight;
      
      // Déterminer les nouvelles dimensions en préservant le ratio d'aspect
      let newWidth, newHeight;
      
      if (originalRatio > MAX_STAMP_WIDTH / MAX_STAMP_HEIGHT) {
        // L'image est plus large proportionnellement
        newWidth = MAX_STAMP_WIDTH;
        newHeight = Math.floor(newWidth / originalRatio);
      } else {
        // L'image est plus haute proportionnellement
        newHeight = MAX_STAMP_HEIGHT;
        newWidth = Math.floor(newHeight * originalRatio);
      }
      
      // Créer un canvas pour l'image redimensionnée
      const canvas = document.createElement('canvas');
      canvas.width = newWidth;
      canvas.height = newHeight;
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        reject(new Error('Impossible de créer le contexte canvas'));
        return;
      }
      
      // Dessiner l'image redimensionnée sur le canvas
      ctx.drawImage(imageElement, 0, 0, newWidth, newHeight);
      
      // Obtenir les données de l'image
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      
      // Analyse pour détecter la couleur de fond dominante
      const colorCounts: {[key: string]: number} = {};
      
      // Échantillonner les bords pour trouver la couleur de fond
      const sampleEdgePixels = () => {
        // Échantillonner 100 pixels sur chaque bord
        const edgePixels: number[] = [];
        
        // Top edge
        for (let x = 0; x < canvas.width; x += Math.max(1, Math.floor(canvas.width / 100))) {
          const idx = (0 * canvas.width + x) * 4;
          edgePixels.push(idx);
        }
        
        // Bottom edge
        for (let x = 0; x < canvas.width; x += Math.max(1, Math.floor(canvas.width / 100))) {
          const idx = ((canvas.height - 1) * canvas.width + x) * 4;
          edgePixels.push(idx);
        }
        
        // Left edge
        for (let y = 0; y < canvas.height; y += Math.max(1, Math.floor(canvas.height / 100))) {
          const idx = (y * canvas.width + 0) * 4;
          edgePixels.push(idx);
        }
        
        // Right edge
        for (let y = 0; y < canvas.height; y += Math.max(1, Math.floor(canvas.height / 100))) {
          const idx = (y * canvas.width + (canvas.width - 1)) * 4;
          edgePixels.push(idx);
        }
        
        // Compter les couleurs des bords
        for (const idx of edgePixels) {
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];
          const a = data[idx + 3];
          
          // Ignorer les pixels transparents
          if (a < 250) continue;
          
          // Simplifier légèrement la couleur pour regrouper des teintes similaires
          const colorKey = `${Math.floor(r/5)*5}_${Math.floor(g/5)*5}_${Math.floor(b/5)*5}`;
          colorCounts[colorKey] = (colorCounts[colorKey] || 0) + 1;
        }
      };
      
      sampleEdgePixels();
      
      // Trouver la couleur de fond la plus fréquente
      let mostCommonColorKey = '';
      let maxCount = 0;
      
      for (const colorKey in colorCounts) {
        if (colorCounts[colorKey] > maxCount) {
          maxCount = colorCounts[colorKey];
          mostCommonColorKey = colorKey;
        }
      }
      
      // Extraire les composants RGB de la couleur dominante
      const [r, g, b] = mostCommonColorKey.split('_').map(c => parseInt(c));
      
      // Fonction pour déterminer si une couleur est proche de la couleur de fond
      const isColorSimilarToBackground = (r1: number, g1: number, b1: number, threshold: number = 30) => {
        const distance = Math.sqrt(
          Math.pow(r1 - r, 2) +
          Math.pow(g1 - g, 2) +
          Math.pow(b1 - b, 2)
        );
        return distance < threshold;
      };
      
      // Remplacer les pixels proches de la couleur de fond par des pixels transparents
      for (let i = 0; i < data.length; i += 4) {
        const r1 = data[i];
        const g1 = data[i + 1];
        const b1 = data[i + 2];
        
        if (isColorSimilarToBackground(r1, g1, b1)) {
          // Rendre le pixel transparent
          data[i + 3] = 0;
        }
      }
      
      // Mettre à jour les données de l'image
      ctx.putImageData(imageData, 0, 0);
      
      // Conversion du canvas en dataURL avec transparence (PNG)
      const processedImageUrl = canvas.toDataURL('image/png');
      resolve(processedImageUrl);
    } catch (error) {
      console.error('Erreur lors du retrait du fond:', error);
      reject(error);
    }
  });
};

// Fonction pour identifier les zones du document
export const identifyDocumentZones = async (imageUrl: string): Promise<DocumentZones> => {
  return new Promise((resolve) => {
    const img = new Image();
    
    img.onload = () => {
      // Créer plusieurs canvas pour les différentes zones
      const mainCanvas = document.createElement('canvas');
      mainCanvas.width = img.width;
      mainCanvas.height = img.height;
      const ctx = mainCanvas.getContext('2d');
      
      if (!ctx) {
        // Si pas de contexte, renvoyer l'image entière pour chaque zone
        resolve({
          headerZone: imageUrl,
          signatureZone: imageUrl,
          stampZone: imageUrl,
          amountZone: imageUrl,
        });
        return;
      }
      
      ctx.drawImage(img, 0, 0);
      
      // Division de l'image en zones d'intérêt basées sur la structure typique des documents
      // Définition de dimensions relatives à l'image
      const width = img.width;
      const height = img.height;
      
      // Coordonnées pour les différentes zones (en pourcentage de l'image)
      // 1. Zone de l'en-tête (partie supérieure)
      const headerCanvas = document.createElement('canvas');
      headerCanvas.width = width;
      headerCanvas.height = height * 0.25;
      const headerCtx = headerCanvas.getContext('2d');
      headerCtx?.drawImage(img, 0, 0, width, height * 0.25, 0, 0, width, height * 0.25);
      
      // 2. Zone de signature (bas de page, souvent côté gauche)
      const signatureCanvas = document.createElement('canvas');
      signatureCanvas.width = width * 0.5;
      signatureCanvas.height = height * 0.25;
      const signatureCtx = signatureCanvas.getContext('2d');
      signatureCtx?.drawImage(
        img, 
        0, height * 0.75, width * 0.5, height * 0.25,
        0, 0, width * 0.5, height * 0.25
      );
      
      // 3. Zone du tampon (bas de page, souvent côté droit)
      const stampCanvas = document.createElement('canvas');
      stampCanvas.width = width * 0.5;
      stampCanvas.height = height * 0.25;
      const stampCtx = stampCanvas.getContext('2d');
      stampCtx?.drawImage(
        img, 
        width * 0.5, height * 0.75, width * 0.5, height * 0.25,
        0, 0, width * 0.5, height * 0.25
      );
      
      // 4. Zone des montants (milieu de page)
      const amountCanvas = document.createElement('canvas');
      amountCanvas.width = width;
      amountCanvas.height = height * 0.5;
      const amountCtx = amountCanvas.getContext('2d');
      amountCtx?.drawImage(
        img, 
        0, height * 0.25, width, height * 0.5,
        0, 0, width, height * 0.5
      );
      
      resolve({
        headerZone: headerCanvas.toDataURL('image/png'),
        signatureZone: signatureCanvas.toDataURL('image/png'),
        stampZone: stampCanvas.toDataURL('image/png'),
        amountZone: amountCanvas.toDataURL('image/png'),
      });
    };
    
    img.onerror = () => {
      // En cas d'échec, renvoyer l'image entière pour chaque zone
      resolve({
        headerZone: imageUrl,
        signatureZone: imageUrl,
        stampZone: imageUrl,
        amountZone: imageUrl,
      });
    };
    
    // Définir la source de l'image
    img.src = imageUrl;
  });
};
