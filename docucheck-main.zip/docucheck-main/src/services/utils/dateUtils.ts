
// Fonction utilitaire pour vérifier si plusieurs dates sont proches
export function areDatesCloseEnough(dateStrings: string[]): boolean {
  if (dateStrings.length < 2) return true;
  
  try {
    // Convertir les dates au format JJ/MM/AAAA en objets Date
    const dates = dateStrings.map(dateString => {
      const [day, month, year] = dateString.split('/').map(Number);
      return new Date(year, month - 1, day);
    });
    
    // Calculer la différence max en jours entre n'importe quelles 2 dates
    let maxDiffDays = 0;
    
    for (let i = 0; i < dates.length; i++) {
      for (let j = i + 1; j < dates.length; j++) {
        const diffTime = Math.abs(dates[j].getTime() - dates[i].getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        maxDiffDays = Math.max(maxDiffDays, diffDays);
      }
    }
    
    // Pour les documents CEE, on est plus souple : on accepte jusqu'à 60 jours d'écart
    // au lieu des 31 jours précédemment définis
    return maxDiffDays <= 60;
  } catch (error) {
    console.error("Erreur lors de la comparaison des dates:", error);
    return true; // On considère les dates comme valides en cas d'erreur pour la démo
  }
}

// Fonction pour comparer deux dates et vérifier leur cohérence
export function areDatesConsistent(date1: string, date2: string): boolean {
  if (!date1 || !date2) return true; // Si une date est manquante, on considère que c'est cohérent pour la démo
  
  try {
    // Convertir les dates au format JJ/MM/AAAA en objets Date
    const [day1, month1, year1] = date1.split('/').map(Number);
    const [day2, month2, year2] = date2.split('/').map(Number);
    
    // Vérifier si les dates sont valides
    if (isNaN(day1) || isNaN(month1) || isNaN(year1) || 
        isNaN(day2) || isNaN(month2) || isNaN(year2)) {
      return true; // On considère les dates comme valides en cas d'erreur pour la démo
    }
    
    // Comparer les dates
    const date1Obj = new Date(year1, month1 - 1, day1);
    const date2Obj = new Date(year2, month2 - 1, day2);
    
    // Calculer la différence en jours
    const diffTime = Math.abs(date2Obj.getTime() - date1Obj.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    // Pour les documents CEE, on est plus souple : on accepte jusqu'à 60 jours d'écart
    // au lieu des 31 jours précédemment définis
    return diffDays <= 60;
  } catch (error) {
    console.error("Erreur lors de la comparaison des dates:", error);
    return true; // On considère les dates comme valides en cas d'erreur pour la démo
  }
}

// Fonction pour vérifier si la date d'engagement correspond à la date manuscrite
export function isEngagementDateConsistent(handwrittenDate: string, engagementDate: string): boolean {
  if (!handwrittenDate || !engagementDate) return true;
  
  try {
    // Convertir les dates au format JJ/MM/AAAA en objets Date
    const [day1, month1, year1] = handwrittenDate.split('/').map(Number);
    const [day2, month2, year2] = engagementDate.split('/').map(Number);
    
    // Vérifier si les dates sont valides
    if (isNaN(day1) || isNaN(month1) || isNaN(year1) || 
        isNaN(day2) || isNaN(month2) || isNaN(year2)) {
      return true;
    }
    
    // Les dates d'engagement doivent idéalement être identiques, mais on tolère une différence minime
    const date1Obj = new Date(year1, month1 - 1, day1);
    const date2Obj = new Date(year2, month2 - 1, day2);
    
    // Calculer la différence en jours
    const diffTime = Math.abs(date2Obj.getTime() - date1Obj.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    // Pour les dates d'engagement, on est plus strict: la tolérance est de 5 jours max
    return diffDays <= 5;
  } catch (error) {
    console.error("Erreur lors de la comparaison des dates d'engagement:", error);
    return true;
  }
}

// Fonction pour valider la chronologie des dates (devis < engagement < facture)
export function validateDateChronology(
  devisDate: string | null,
  engagementDate: string | null,
  factureDate: string | null
): boolean {
  if (!devisDate || !engagementDate || !factureDate) return true;
  
  try {
    // Convertir les dates au format JJ/MM/AAAA en objets Date
    const parseDate = (dateStr: string) => {
      const [day, month, year] = dateStr.split('/').map(Number);
      return new Date(year, month - 1, day);
    };
    
    const devisDateObj = parseDate(devisDate);
    const engagementDateObj = parseDate(engagementDate);
    const factureDateObj = parseDate(factureDate);
    
    // Vérifier la chronologie: devis <= engagement <= facture
    return devisDateObj <= engagementDateObj && engagementDateObj <= factureDateObj;
  } catch (error) {
    console.error("Erreur lors de la validation de la chronologie des dates:", error);
    return true;
  }
}
