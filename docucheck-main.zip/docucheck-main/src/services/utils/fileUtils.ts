/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-async-promise-executor */

import { pdfjs } from 'react-pdf';

// Initialisation de PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

// Configuration constante pour la conversion PDF vers image
export const PDF_CONVERSION = {
  // Résolution pour l'analyse (entre 150-200 dpi)
  ANALYSIS_DPI: 300,
  // Résolution réduite pour la prévisualisation rapide
  PREVIEW_DPI: 100,
  // Formats acceptés
  SUPPORTED_IMAGE_FORMATS: ['image/png', 'image/jpeg', 'image/gif', 'image/webp'],
  // Qualité de compression JPEG (0.0-1.0)
  JPEG_QUALITY: 1.0
};

// Utility function to convert a file to base64 format
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64String = reader.result as string;
      // Extract the base64 part (remove the data:image/jpeg;base64, prefix)
      const base64Content = base64String.split(',')[1];
      resolve(base64Content);
    };
    reader.onerror = error => reject(error);
  });
};

// Convertit un PDF en image(s) pour l'analyse avec une résolution optimale (180 dpi)
export const convertPdfToImages = async (file: File, options: { allPages?: boolean, forAnalysis?: boolean } = {}): Promise<string[] | string> => {
  const { allPages = false, forAnalysis = true } = options;
  const dpi = forAnalysis ? PDF_CONVERSION.ANALYSIS_DPI : PDF_CONVERSION.PREVIEW_DPI;
  const quality = PDF_CONVERSION.JPEG_QUALITY;
  
  try {
    console.log(`Conversion du PDF en image${allPages ? 's' : ''} à ${dpi} DPI...`);
    const fileArrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjs.getDocument({ data: fileArrayBuffer }).promise;
    
    // Points par pouce en PDF = 72, donc scale = dpi/72
    const scale = dpi / 72;
    
    if (!allPages) {
      // Convertir uniquement la première page avec la résolution spécifiée
      const page = await pdf.getPage(1);
      const viewport = page.getViewport({ scale });
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      
      canvas.height = viewport.height;
      canvas.width = viewport.width;
      
      await page.render({
        canvasContext: context as any,
        viewport: viewport
      }).promise;
      
      const dataUrl = canvas.toDataURL('image/jpeg', quality);
      return dataUrl;
    } else {
      // Convertir toutes les pages
      const pageCount = pdf.numPages;
      const pagePromises: Promise<string>[] = [];
      
      for (let i = 1; i <= pageCount; i++) {
        pagePromises.push((async (pageNum) => {
          const page = await pdf.getPage(pageNum);
          const viewport = page.getViewport({ scale });
          const canvas = document.createElement('canvas');
          const context = canvas.getContext('2d');
          
          canvas.height = viewport.height;
          canvas.width = viewport.width;
          
          await page.render({
            canvasContext: context as any,
            viewport: viewport
          }).promise;
          
          return canvas.toDataURL('image/jpeg', quality);
        })(i));
      }
      
      return await Promise.all(pagePromises);
    }
  } catch (error) {
    console.error("Erreur lors de la conversion PDF en image:", error);
    throw new Error("Erreur lors de la conversion du PDF en image");
  }
};

export type ImageWithSize = {
  dataUrl: string;
  width: number;
  height: number;
};

// Function to convert an image to a format compatible with the OpenAI API
export const createValidImageUrl = async (file: File, forAnalysis: boolean = true): Promise<ImageWithSize> => {
  return new Promise(async (resolve, reject) => {
    try {
      // Si c'est un PDF, on le convertit d'abord en image avec la résolution appropriée
      if (file.type === "application/pdf") {
        console.log(`Conversion du PDF en image pour ${forAnalysis ? 'analyse' : 'prévisualisation'}...`);
        try {
          const imageDataUrl = await convertPdfToImages(file, { 
            allPages: false, 
            forAnalysis 
          }) as string;

          // Charger l'image pour en obtenir les dimensions
          const img = new Image();
          img.onload = () => {
            resolve({
              dataUrl: imageDataUrl,
              width: img.width,
              height: img.height
            });
          };
          img.onerror = () => reject(new Error("Erreur lors du chargement de l'image générée depuis PDF"));

          img.src = imageDataUrl;

        } catch (error) {
          reject(new Error("Erreur lors de la conversion du PDF: " + error));
        }
        return;
      }
      
      // Pour les images, on utilise le FileReader standard
      const reader = new FileReader();
      
      reader.onload = (event) => {
        if (!event.target?.result) {
          reject(new Error("Échec de la lecture du fichier"));
          return;
        }
        
        // For image files, ensure we have the correct data URL format
        // Check if the file is one of the supported image formats
        if (!PDF_CONVERSION.SUPPORTED_IMAGE_FORMATS.includes(file.type)) {
          reject(new Error(`Format d'image non supporté: ${file.type}. Veuillez utiliser PNG, JPEG, GIF, ou WEBP.`));
          return;
        }
        
        // Convert the image to a data URL with the correct format
        const dataUrl = event.target.result.toString();
        
        // Charger l'image pour lire ses dimensions
        const img = new Image();
        img.onload = () => {
          resolve({
            dataUrl,
            width: img.width,
            height: img.height
          });
        };
        img.onerror = () => reject(new Error("Erreur lors du chargement de l'image"));

        img.src = dataUrl;
      };
      
      reader.onerror = () => {
        reject(new Error("Erreur lors de la lecture du fichier"));
      };
      
      // Read the file as a data URL
      reader.readAsDataURL(file);
    } catch (error) {
      reject(error);
    }
  });
};
