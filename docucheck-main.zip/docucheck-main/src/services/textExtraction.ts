import Tesseract from 'tesseract.js';
import { preprocessImage } from './imageProcessing';
import { createValidImageUrl, PDF_CONVERSION } from './utils/fileUtils';
import { processDocument } from './optimizedDocumentProcessor';

// Clé API OpenAI intégrée directement dans l'application
const OPENAI_API_KEY = "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";

// Variable pour activer/désactiver l'utilisation de GPT Vision
const USE_GPT_VISION = true;

// Fonction pour extraire le texte d'une image ou d'un PDF
export const extractTextFromDocument = async (file: File): Promise<string> => {
  try {
    // Conversion du PDF en image si nécessaire avec résolution optimale pour l'analyse
    console.log(`Prétraitement de ${file.name} (${file.type})...`);
    
    // Si c'est un PDF, utiliser la nouvelle méthode de traitement optimisée
    if (file.type === 'application/pdf') {
      console.log('Traitement du PDF via la méthode optimisée...');
      const results = await processDocument(file);
      
      // Formater les résultats pour la compatibilité avec l'existant
      const formattedResults = results.map(r => 
        `=== PAGE ${r.pageNumber} ===\n${r.result}`
      ).join('\n\n');
      
      return formattedResults;
    }
    
    // Pour les images individuelles, utiliser le traitement habituel
    const processedImageUrl = await createValidImageUrl(file, true); // true = pour analyse
    
    console.log(`Analyse de ${file.name} avec GPT...`);
    
    // GPT Vision est toujours activé car la clé API est intégrée
    if (USE_GPT_VISION) {
      try {
        console.log("Utilisation de GPT pour l'analyse optimisée...");
        
        // Définir les instructions pour GPT - optimisées pour l'extraction complète
        const instructions = `
En tant qu'expert en analyse de documents CEE (Certificat d'Économie d'Énergie), examinez attentivement cette image avec une précision exceptionnelle.

DÉTAILS DE L'ENTREPRISE (recherchez méthodiquement):
- Nom complet de l'entreprise exactement comme imprimé
- Numéro SIRET (14 chiffres) - CRITIQUE
- Adresse complète et précise (numéro, rue, code postal, ville)
- Forme juridique (SARL, SAS, EURL, etc.)
- Tampon d'entreprise présent? (oui/non) - Décrivez son emplacement

DÉTAILS DU DOCUMENT (analysez scrupuleusement):
- Type précis du document (devis/facture/attestation sur l'honneur)
- Numéro du document (référence)
- Date exacte du document (JJ/MM/AAAA)
- Montant total TTC en euros (valeur numérique)
- Description détaillée des travaux/services énergétiques
- Références spécifiques aux fiches CEE/BAR-TH mentionnées
- Vérifiez les mentions légales obligatoires

CLIENT/BÉNÉFICIAIRE:
- Nom complet du bénéficiaire
- Adresse exacte des travaux
- Adresse de facturation si différente

SIGNATURE ET ÉLÉMENTS MANUSCRITS (examinez avec attention):
- Mention "Bon pour accord" présente? (oui/non)
- Signature manuscrite présente? (oui/non) - Décrivez son emplacement
- Nom manuscrit du signataire
- Fonction/rôle manuscrit du signataire
- Date manuscrite (JJ/MM/AAAA)
- Autres annotations manuscrites importantes

SPÉCIFICATIONS TECHNIQUES (si disponibles):
- Type d'équipement installé
- Marque et modèle
- Performances énergétiques (SCOP, SEER, etc.)
- Quantités et dimensions

CONFORMITÉ ET FIABILITÉ:
- Évaluez la conformité globale du document (0-100%)
- Identifiez précisément les éléments manquants ou problématiques
- Évaluez la fiabilité de chaque information extraite (0-100%)

Répondez STRICTEMENT au format JSON suivant, sans AUCUN texte supplémentaire:
{
  "document_type": "devis|facture|attestation|autre",
  "company": {
    "name": "Nom exact de l'entreprise",
    "siret": "14 chiffres exacts",
    "address": "Adresse complète",
    "legal_form": "SARL/SAS/etc",
    "stamp_present": true|false,
    "stamp_location": "Description précise",
    "reliability": 95
  },
  "client": {
    "name": "Nom complet",
    "work_address": "Adresse des travaux",
    "billing_address": "Adresse de facturation",
    "reliability": 90
  },
  "document": {
    "reference": "Numéro/référence",
    "date": "JJ/MM/AAAA",
    "amount_ttc": 0.0,
    "description": "Description détaillée",
    "cee_references": "BAR-TH-XXX",
    "legal_mentions_complete": true|false,
    "reliability": 85
  },
  "technical_specs": {
    "equipment_type": "Type",
    "brand": "Marque",
    "model": "Modèle",
    "performance": "Valeurs",
    "quantity": 0,
    "reliability": 80
  },
  "manuscript": {
    "bon_pour_accord": true|false,
    "signature": true|false,
    "signature_location": "Description précise",
    "name": "Nom manuscrit",
    "function": "Fonction manuscrite",
    "date": "JJ/MM/AAAA",
    "other_notes": "Annotations importantes",
    "reliability": 90
  },
  "conformity": {
    "score": 0-100,
    "missing_elements": ["élément 1", "élément 2"],
    "critical_issues": ["problème 1", "problème 2"],
    "recommendations": ["recommandation 1", "recommandation 2"]
  }
}

IMPORTANT: Pour chaque section, si l'information n'est pas visible, indiquez-le clairement. Ne faites AUCUNE supposition, soyez factuel. Fournissez UNIQUEMENT le JSON, sans texte additionnel.
        `;
        
        // Appeler l'API OpenAI avec GPT-4o - avec paramètres optimisés
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${OPENAI_API_KEY}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            model: "gpt-4o", // Utilisation du modèle gpt-4o qui supporte la vision
            messages: [
              {
                role: "system",
                content: "Vous êtes un expert en analyse de documents CEE avec une précision exceptionnelle. Vous êtes spécialisé dans la détection d'éléments manuscrits, signatures, tampons et informations techniques. Vous avez une connaissance approfondie des réglementations CEE et pouvez évaluer la conformité d'un document avec une grande précision. Vous répondez UNIQUEMENT au format JSON demandé, sans aucun texte supplémentaire."
              },
              {
                role: "user",
                content: [
                  {
                    type: "text",
                    text: instructions
                  },
                  {
                    type: "image_url",
                    image_url: {
                      url: processedImageUrl,
                      detail: "high" // Utiliser la plus haute résolution pour une meilleure précision
                    }
                  }
                ]
              }
            ],
            max_tokens: 3000,
            temperature: 0.1 // Température basse pour maximiser la précision
          })
        });

        if (!response.ok) {
          const errorData = await response.json();
          console.error("Erreur API OpenAI:", errorData);
          throw new Error(`Erreur API OpenAI: ${response.status} - ${JSON.stringify(errorData)}`);
        }

        const data = await response.json();
        
        // Parse la réponse JSON
        const content = data.choices[0].message.content;
        let parsedContent;
        
        try {
          // Extraction du JSON de la réponse
          const jsonMatch = content.match(/{[\s\S]*}/);
          const jsonContent = jsonMatch ? jsonMatch[0] : content;
          parsedContent = JSON.parse(jsonContent);
        } catch (e) {
          console.error("Impossible de parser la réponse JSON de GPT Vision:", e);
          // Fallback à l'OCR classique
          return await performOCR(processedImageUrl);
        }
        
        // Retourner le contenu analysé au format texte pour compatibilité
        return `=== ANALYSE GPT OPTIMISEE ===\n${JSON.stringify(parsedContent, null, 2)}`;
      } catch (visionError) {
        console.error("Erreur avec GPT Vision:", visionError);
        // Fallback à l'OCR classique
        return await performOCR(processedImageUrl);
      }
    } else {
      console.warn("GPT Vision désactivé. Utilisation de l'OCR classique.");
      // Utiliser OCR classique par défaut
      return await performOCR(processedImageUrl);
    }
  } catch (error) {
    console.error('Erreur lors de l\'extraction du texte:', error);
    return '';
  }
};

// Fonction pour réaliser l'OCR avec Tesseract si GPT Vision n'est pas disponible
async function performOCR(imageUrl: string): Promise<string> {
  try {
    // Use Tesseract.js API
    const worker = await Tesseract.createWorker('fra');
    
    // Exécution de l'OCR
    const result = await worker.recognize(imageUrl);
    console.log(`OCR terminé`);
    
    // Libération du worker
    await worker.terminate();
    
    return result.data.text;
  } catch (error) {
    console.error("Erreur lors de l'OCR:", error);
    return "";
  }
}

// Export pour pouvoir l'utiliser dans le service de positionnement de tampons
export { performOCR };
