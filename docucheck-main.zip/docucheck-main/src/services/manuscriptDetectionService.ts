/* eslint-disable @typescript-eslint/no-explicit-any */
import Tesseract from 'tesseract.js';
import { MANUSCRIPT_DETECTION_CONFIG } from './manuscriptDetectionConfig';

/**
 * Interface pour les coordonnées d'une zone manuscrite
 */
export interface ManuscriptZone {
  x: number;           // Position X en % (0-100)
  y: number;           // Position Y en % (0-100)
  width: number;       // Largeur en % (0-100)
  height: number;      // Hauteur en % (0-100)
  confidence: number;  // Niveau de confiance (0-100)
  type: 'handwriting' | 'stamp' | 'signature' | 'mixed';
}

/**
 * Interface pour le résultat de la détection
 */
export interface ManuscriptDetectionResult {
  hasManuscript: boolean;
  zones: ManuscriptZone[];
  globalBoundingBox?: string; // Format: "x,y,width,height"
}

/**
 * Détecte les zones manuscrites dans une image en utilisant Tesseract.js
 * Cette fonction analyse la confiance et les caractéristiques du texte pour identifier
 * les zones manuscrites par opposition au texte imprimé.
 * 
 * @param imageDataUrl - Image au format base64 data URL
 * @returns Résultat de la détection avec les coordonnées des zones manuscrites
 */
export async function detectManuscriptZones(imageDataUrl: string): Promise<ManuscriptDetectionResult> {
  let worker = null;
  
  try {
    console.log("Initialisation de la détection des zones manuscrites...");
    
    // Créer un worker Tesseract pour le français
    worker = await Tesseract.createWorker('fra');
    
    // Configuration pour améliorer la détection
    await worker.setParameters({
      tessedit_pageseg_mode: Tesseract.PSM.AUTO, // Mode de segmentation automatique
      tessjs_create_hocr: true,
      tessjs_create_tsv: true,
    });
    
    // Exécuter l'OCR
    const result = await worker.recognize(imageDataUrl);
    
    // Obtenir les dimensions de l'image
    const imageDimensions = await getImageDimensions(imageDataUrl);
    
    // Analyser les zones et identifier les éléments manuscrits
    const manuscriptZones = identifyManuscriptZones(
      result.data.words,
      imageDimensions.width,
      imageDimensions.height
    );
    
    // Calculer la boîte englobante globale
    const globalBoundingBox = manuscriptZones.length > 0 
      ? calculateGlobalBoundingBox(manuscriptZones)
      : undefined;
    
    console.log(`Détection terminée. ${manuscriptZones.length} zone(s) manuscrite(s) trouvée(s).`);
    
    return {
      hasManuscript: manuscriptZones.length > 0,
      zones: manuscriptZones,
      globalBoundingBox
    };
    
  } catch (error) {
    console.error("Erreur lors de la détection des zones manuscrites:", error);
    return {
      hasManuscript: false,
      zones: []
    };
  } finally {
    if (worker) {
      await worker.terminate();
    }
  }
}

/**
 * Identifie les zones manuscrites en analysant les mots détectés par Tesseract
 * Utilise la confiance, la taille et la position pour distinguer manuscrit vs imprimé
 */
function identifyManuscriptZones(
  words: Tesseract.Word[],
  imageWidth: number,
  imageHeight: number
): ManuscriptZone[] {
  if (!words || words.length === 0) {
    return [];
  }
  
  // Grouper les mots en zones potentiellement manuscrites
  const potentialZones: any[] = [];
  
  words.forEach(word => {
    // Critères STRICTS pour identifier du manuscrit (utilise la config)
    const confidence = word.confidence;
    const bbox = word.bbox;
    
    // Position verticale relative (en %)
    const yPosition = (bbox.y0 / imageHeight) * 100;
    
    // Taille relative du texte
    const wordWidth = bbox.x1 - bbox.x0;
    const wordHeight = bbox.y1 - bbox.y0;
    const wordArea = (wordWidth * wordHeight) / (imageWidth * imageHeight);
    
    // Critères configurables
    const isVeryLowConfidence = confidence < MANUSCRIPT_DETECTION_CONFIG.CONFIDENCE_THRESHOLD;
    const isInLowerHalf = yPosition > MANUSCRIPT_DETECTION_CONFIG.MIN_Y_POSITION;
    const isShortText = word.text.length < MANUSCRIPT_DETECTION_CONFIG.MAX_TEXT_LENGTH;
    const isSmallArea = wordArea < MANUSCRIPT_DETECTION_CONFIG.MAX_WORD_AREA;
    
    // N'accepter que les mots qui correspondent à AU MOINS X critères (configurable)
    const criteriaCount = [
      isVeryLowConfidence,
      isInLowerHalf,
      isShortText,
      isSmallArea
    ].filter(Boolean).length;
    
    if (criteriaCount >= MANUSCRIPT_DETECTION_CONFIG.MIN_CRITERIA_COUNT) {
      potentialZones.push({
        x: bbox.x0,
        y: bbox.y0,
        x2: bbox.x1,
        y2: bbox.y1,
        confidence: confidence,
        text: word.text,
        baseline: word.baseline,
        area: wordArea
      });
    }
  });
  
  if (MANUSCRIPT_DETECTION_CONFIG.DEBUG_LOGS) {
    console.log(`Zones potentielles manuscrites détectées: ${potentialZones.length}`);
  }
  
  // Si trop de zones détectées, c'est probablement du bruit
  if (potentialZones.length > MANUSCRIPT_DETECTION_CONFIG.MAX_POTENTIAL_ZONES) {
    if (MANUSCRIPT_DETECTION_CONFIG.DEBUG_LOGS) {
      console.warn("Trop de zones détectées, filtrage plus strict...");
    }
    // Garder seulement les zones avec confiance très faible
    const filteredZones = potentialZones.filter(
      z => z.confidence < MANUSCRIPT_DETECTION_CONFIG.STRICT_CONFIDENCE_THRESHOLD
    );
    if (MANUSCRIPT_DETECTION_CONFIG.DEBUG_LOGS) {
      console.log(`Zones après filtrage strict: ${filteredZones.length}`);
    }
    return processZones(filteredZones, imageWidth, imageHeight);
  }
  
  return processZones(potentialZones, imageWidth, imageHeight);
}

/**
 * Traite les zones détectées pour créer les bounding boxes finales
 */
function processZones(zones: any[], imageWidth: number, imageHeight: number): ManuscriptZone[] {
  if (zones.length === 0) return [];
  
  // Regrouper les zones proches
  const clusteredZones = clusterNearbyZones(zones, imageWidth, imageHeight);
  
  // Convertir en pourcentages et filtrer
  const finalZones = clusteredZones
    .filter(zone => {
      // Filtrer les zones qui couvrent trop de surface (configurable)
      return zone.area < MANUSCRIPT_DETECTION_CONFIG.MAX_ZONE_AREA;
    })
    .map(zone => ({
      x: (zone.x / imageWidth) * 100,
      y: (zone.y / imageHeight) * 100,
      width: (zone.width / imageWidth) * 100,
      height: (zone.height / imageHeight) * 100,
      confidence: zone.confidence,
      type: determineZoneType(zone)
    }));
  
  if (MANUSCRIPT_DETECTION_CONFIG.DEBUG_LOGS) {
    console.log(`Zones finales après filtrage: ${finalZones.length}`);
  }
  
  return finalZones;
}

/**
 * Regroupe les zones proches pour former des boîtes englobantes
 */
function clusterNearbyZones(zones: any[], imageWidth: number, imageHeight: number): any[] {
  if (zones.length === 0) return [];
  
  // Paramètres de clustering depuis la config
  const maxDistanceX = imageWidth * MANUSCRIPT_DETECTION_CONFIG.CLUSTERING.MAX_DISTANCE_X;
  const maxDistanceY = imageHeight * MANUSCRIPT_DETECTION_CONFIG.CLUSTERING.MAX_DISTANCE_Y;
  
  const clusters: any[] = [];
  const visited = new Set<number>();
  
  zones.forEach((zone, idx) => {
    if (visited.has(idx)) return;
    
    const cluster = {
      x: zone.x,
      y: zone.y,
      x2: zone.x2,
      y2: zone.y2,
      confidence: zone.confidence,
      count: 1
    };
    
    visited.add(idx);
    
    // Chercher les zones voisines
    zones.forEach((otherZone, otherIdx) => {
      if (visited.has(otherIdx)) return;
      
      const distX = Math.abs(zone.x - otherZone.x);
      const distY = Math.abs(zone.y - otherZone.y);
      
      if (distX < maxDistanceX && distY < maxDistanceY) {
        // Agrandir le cluster
        cluster.x = Math.min(cluster.x, otherZone.x);
        cluster.y = Math.min(cluster.y, otherZone.y);
        cluster.x2 = Math.max(cluster.x2, otherZone.x2);
        cluster.y2 = Math.max(cluster.y2, otherZone.y2);
        cluster.confidence = (cluster.confidence + otherZone.confidence) / 2;
        cluster.count++;
        visited.add(otherIdx);
      }
    });
    
    // Ajouter une marge depuis la config
    const marginX = (cluster.x2 - cluster.x) * MANUSCRIPT_DETECTION_CONFIG.ZONE_MARGIN;
    const marginY = (cluster.y2 - cluster.y) * MANUSCRIPT_DETECTION_CONFIG.ZONE_MARGIN;
    
    clusters.push({
      x: Math.max(0, cluster.x - marginX),
      y: Math.max(0, cluster.y - marginY),
      width: (cluster.x2 - cluster.x) + (2 * marginX),
      height: (cluster.y2 - cluster.y) + (2 * marginY),
      confidence: cluster.confidence,
      area: ((cluster.x2 - cluster.x) * (cluster.y2 - cluster.y)) / (imageWidth * imageHeight)
    });
  });
  
  return clusters;
}

/**
 * Détermine le type de zone manuscrite
 */
function determineZoneType(zone: any): ManuscriptZone['type'] {
  // Heuristique basée sur la taille et le ratio
  const aspectRatio = zone.width / zone.height;
  
  if (zone.area < 0.005) {
    return 'signature';
  } else if (aspectRatio > 2) {
    return 'stamp';
  } else if (zone.confidence < 60) {
    return 'handwriting';
  } else {
    return 'mixed';
  }
}

/**
 * Calcule la boîte englobante globale pour toutes les zones
 */
function calculateGlobalBoundingBox(zones: ManuscriptZone[]): string {
  if (zones.length === 0) return "";
  
  let minX = 100, minY = 100, maxX = 0, maxY = 0;
  
  zones.forEach(zone => {
    minX = Math.min(minX, zone.x);
    minY = Math.min(minY, zone.y);
    maxX = Math.max(maxX, zone.x + zone.width);
    maxY = Math.max(maxY, zone.y + zone.height);
  });
  
  // S'assurer que les valeurs sont dans les limites
  minX = Math.max(0, Math.min(100, minX));
  minY = Math.max(0, Math.min(100, minY));
  const width = Math.max(0, Math.min(100 - minX, maxX - minX));
  const height = Math.max(0, Math.min(100 - minY, maxY - minY));
  
  // Arrondir à 2 décimales
  return `${minX.toFixed(2)},${minY.toFixed(2)},${width.toFixed(2)},${height.toFixed(2)}`;
}

/**
 * Obtient les dimensions d'une image à partir de son data URL
 */
function getImageDimensions(dataUrl: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    
    img.onload = () => {
      resolve({
        width: img.width,
        height: img.height
      });
    };
    
    img.onerror = (error) => {
      reject(error);
    };
    
    img.src = dataUrl;
  });
}

/**
 * Détecte les zones manuscrites dans plusieurs images (batch)
 */
export async function detectManuscriptZonesInBatch(
  imageDataUrls: string[]
): Promise<ManuscriptDetectionResult[]> {
  console.log(`Détection des zones manuscrites pour ${imageDataUrls.length} image(s)...`);
  
  const results: ManuscriptDetectionResult[] = [];
  
  for (const imageDataUrl of imageDataUrls) {
    const result = await detectManuscriptZones(imageDataUrl);
    results.push(result);
  }
  
  return results;
}
