
import { Appointment, OptimizedRoute, Waypoint } from "@/types/route";

/**
 * Optimise un itinéraire en utilisant OpenRouteService
 * @param startLocation La position de départ
 * @param appointments La liste des rendez-vous à visiter
 * @returns L'itinéraire optimisé
 */
export const optimizeRoute = async (
  startLocation: { lat: number; lng: number },
  appointments: Appointment[]
): Promise<OptimizedRoute> => {
  try {
    // Pour la démonstration, nous utilisons un algorithme simple du problème du voyageur de commerce
    // En production, il faudrait utiliser une API comme OpenRouteService ou Google OR-Tools

    // Créer des waypoints pour tous les points, en commençant par la position actuelle
    const allPoints = [
      { 
        lat: startLocation.lat, 
        lng: startLocation.lng,
        name: "Position actuelle",
        originalIndex: -1
      },
      ...appointments.map((app, index) => ({
        lat: app.lat,
        lng: app.lng,
        name: app.name,
        originalIndex: index
      }))
    ];

    // Calculer la matrice de distances entre tous les points
    const distanceMatrix = await calculateDistanceMatrix(allPoints);
    
    // Trouver l'ordre optimal (algorithme approximatif du plus proche voisin)
    const optimalOrder = nearestNeighborAlgorithm(distanceMatrix);
    
    // Réorganiser les waypoints selon l'ordre optimal
    const orderedWaypoints: Waypoint[] = [];
    
    // Ignorer le point de départ (0) dans la liste finale des waypoints
    for (let i = 1; i < optimalOrder.length; i++) {
      const pointIndex = optimalOrder[i];
      if (pointIndex > 0) { // Ignorer la position de départ dans les résultats finaux
        orderedWaypoints.push({
          lat: allPoints[pointIndex].lat,
          lng: allPoints[pointIndex].lng,
          name: allPoints[pointIndex].name,
          originalIndex: allPoints[pointIndex].originalIndex
        });
      }
    }
    
    // Calculer la distance totale et la durée estimée
    let totalDistance = 0;
    for (let i = 0; i < optimalOrder.length - 1; i++) {
      const fromIndex = optimalOrder[i];
      const toIndex = optimalOrder[i + 1];
      totalDistance += distanceMatrix[fromIndex][toIndex];
    }
    
    // Simuler un temps de trajet (environ 50 km/h en moyenne)
    const averageSpeed = 50; // km/h
    const totalDuration = (totalDistance / 1000) / averageSpeed * 3600; // en secondes
    
    // Créer un tableau de coordonnées pour le polyline (simulé pour la démo)
    const routeGeometry = generateSimulatedRoute(allPoints, optimalOrder);
    
    return {
      waypoints: orderedWaypoints,
      distance: totalDistance,
      duration: totalDuration,
      routeGeometry: routeGeometry
    };
    
  } catch (error) {
    console.error("Erreur d'optimisation d'itinéraire:", error);
    throw new Error("Impossible d'optimiser l'itinéraire");
  }
};

/**
 * Calcule la matrice de distances entre tous les points
 * Dans une implémentation réelle, cette fonction appellerait une API de routage comme OSRM ou ORS
 */
const calculateDistanceMatrix = async (points: any[]): Promise<number[][]> => {
  const n = points.length;
  const matrix: number[][] = Array(n).fill(0).map(() => Array(n).fill(0));
  
  // Remplir la matrice avec des distances à vol d'oiseau
  // En production, il faudrait utiliser une API pour obtenir des distances routières réelles
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (i !== j) {
        matrix[i][j] = haversineDistance(
          points[i].lat, points[i].lng,
          points[j].lat, points[j].lng
        );
      }
    }
  }
  
  return matrix;
};

/**
 * Calcule la distance à vol d'oiseau entre deux points en mètres
 */
const haversineDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Rayon de la Terre en km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c * 1000; // Distance en mètres
};

/**
 * Algorithme du plus proche voisin pour résoudre le problème du voyageur de commerce
 * Commence par le point de départ (index 0) et visite le point le plus proche à chaque étape
 */
const nearestNeighborAlgorithm = (distanceMatrix: number[][]): number[] => {
  const n = distanceMatrix.length;
  const visited = Array(n).fill(false);
  const path: number[] = [0]; // Commencer par le point de départ (index 0)
  
  visited[0] = true;
  
  while (path.length < n) {
    const lastPoint = path[path.length - 1];
    let nextPoint = -1;
    let minDistance = Infinity;
    
    for (let i = 0; i < n; i++) {
      if (!visited[i] && distanceMatrix[lastPoint][i] < minDistance) {
        minDistance = distanceMatrix[lastPoint][i];
        nextPoint = i;
      }
    }
    
    if (nextPoint !== -1) {
      path.push(nextPoint);
      visited[nextPoint] = true;
    } else {
      break; // Tous les points accessibles ont été visités
    }
  }
  
  return path;
};

/**
 * Génère un polyline simulé pour la démonstration
 * Dans une implémentation réelle, cette géométrie viendrait d'une API de routage
 */
const generateSimulatedRoute = (points: any[], order: number[]): [number, number][] => {
  const result: [number, number][] = [];
  
  for (let i = 0; i < order.length; i++) {
    const pointIndex = order[i];
    result.push([points[pointIndex].lat, points[pointIndex].lng]);
    
    // Si ce n'est pas le dernier point, ajouter quelques points intermédiaires
    if (i < order.length - 1) {
      const nextPointIndex = order[i + 1];
      const startLat = points[pointIndex].lat;
      const startLng = points[pointIndex].lng;
      const endLat = points[nextPointIndex].lat;
      const endLng = points[nextPointIndex].lng;
      
      // Ajouter quelques points intermédiaires pour simuler une route
      const steps = 4;
      for (let j = 1; j <= steps; j++) {
        const ratio = j / (steps + 1);
        // Ajouter un peu de variation pour éviter une ligne droite
        const jitter = 0.0005 * (Math.random() - 0.5);
        result.push([
          startLat + (endLat - startLat) * ratio + jitter,
          startLng + (endLng - startLng) * ratio + jitter
        ]);
      }
    }
  }
  
  return result;
};

/**
 * Génère un lien pour ouvrir Waze avec l'adresse spécifiée
 */
export const generateWazeLink = (lat: number, lng: number): string => {
  return `https://waze.com/ul?ll=${lat},${lng}&navigate=yes`;
};

/**
 * Génère un message texte pour les rendez-vous
 */
export const generateAppointmentMessage = (appointment: Appointment, index: number): string => {
  let message = `📍 Rendez-vous #${index + 1}: ${appointment.name}\n`;
  message += `📌 Adresse: ${appointment.address}\n`;
  
  if (appointment.time) {
    message += `🕒 Heure: ${appointment.time}\n`;
  }
  
  if (appointment.duration) {
    message += `⏱️ Durée: ${appointment.duration} min\n`;
  }
  
  if (appointment.notes) {
    message += `📝 Notes: ${appointment.notes}\n`;
  }
  
  // Ajouter un lien Waze
  message += `🚗 Navigation: https://waze.com/ul?ll=${appointment.lat},${appointment.lng}&navigate=yes`;
  
  return message;
};

/**
 * Génère un lien pour envoyer un message WhatsApp
 */
export const generateWhatsAppLink = (phoneNumber: string, message: string): string => {
  // Retirer les caractères non numériques du numéro de téléphone
  const cleanNumber = phoneNumber.replace(/\D/g, '');
  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
};

/**
 * Génère un lien pour envoyer un SMS
 */
export const generateSMSLink = (phoneNumber: string, message: string): string => {
  return `sms:${phoneNumber}?body=${encodeURIComponent(message)}`;
};

// Ajout pour la gestion d'équipe
export interface Team {
  id: string;
  name: string;
  phoneNumber: string;
}

/**
 * Génère un message pour tous les rendez-vous d'une équipe
 */
export const generateTeamAppointmentsMessage = (appointments: Appointment[], teamName: string): string => {
  if (!appointments.length) return '';
  
  let message = `📅 Planning de l'équipe ${teamName} - ${new Date().toLocaleDateString('fr-FR')}\n\n`;
  
  appointments.forEach((appointment, index) => {
    message += `📍 RDV #${index + 1}: ${appointment.name}\n`;
    message += `📌 ${appointment.address}\n`;
    
    if (appointment.time) {
      message += `🕒 ${appointment.time}\n`;
    }
    
    if (appointment.duration) {
      message += `⏱️ ${appointment.duration} min\n`;
    }
    
    message += `🚗 Waze: https://waze.com/ul?ll=${appointment.lat},${appointment.lng}&navigate=yes\n\n`;
  });
  
  message += `✅ Total: ${appointments.length} rendez-vous`;
  
  return message;
};
