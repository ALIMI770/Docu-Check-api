import * as pdfjsLib from 'pdfjs-dist';
import Tesseract from 'tesseract.js';
import { createWorker } from 'tesseract.js';
import { analyzePdfContentForStampPosition } from './chatGptService';

// Liste étendue et optimisée des mots-clés pour le positionnement du tampon
const STAMP_KEYWORDS = [
  'cachet', 'tampon', 'signature', 'stamp', 'seal', 'bénéficiaire', 'attestation',
  'approuvé', 'certifié', 'validé', 'accord', 'fait à', 'date', 'lu et approuvé',
  'signataire', 'bon pour accord', 'acceptation', 'cachet entreprise', 'cachet societé',
  'signé', 'lu et approuvé', 'mention', 'obligatoire'
];

// Mots-clés à haute priorité
const HIGH_PRIORITY_KEYWORDS = [
  'cachet', 'tampon', 'signature', 'signataire', 'certifié', 'validé', 'cacheter'
];

// Structure pour représenter une position
export interface StampPosition {
  x: number;
  y: number;
  score: number;
}

// Position par défaut requise par l'utilisateur
const DEFAULT_POSITION = {
  x: 120,
  y: 370,
  score: 50
};

// Convertit une page PDF en image pour l'OCR avec une résolution améliorée
async function convertPdfPageToImage(pdfPage: pdfjsLib.PDFPageProxy, scale: number = 2.5): Promise<string> {
  try {
    const viewport = pdfPage.getViewport({ scale });
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    
    if (!context) {
      throw new Error("Unable to get canvas context");
    }
    
    canvas.height = viewport.height;
    canvas.width = viewport.width;
    
    await pdfPage.render({
      canvasContext: context,
      viewport: viewport
    }).promise;
    
    return canvas.toDataURL('image/jpeg', 0.95);
  } catch (error) {
    console.error("Erreur lors de la conversion de la page PDF en image:", error);
    throw error;
  }
}

// Extrait le texte d'une page avec OCR optimisé
async function extractTextFromPage(pageImage: string): Promise<Tesseract.RecognizeResult> {
  let worker = null;
  
  try {
    // Utiliser un travailleur OCR pour le français avec des paramètres optimisés
    worker = await createWorker('fra+eng');
    
    // Configuration avancée pour améliorer la reconnaissance
    await worker.setParameters({
      tessedit_char_whitelist: 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789éèêëàâäôöùûüïîçÉÈÊËÀÂÄÔÖÙÛÜÏÎÇ.,:;-_()\'"/!?@#$%&*+=[]{}|\\<>',
      tessedit_ocr_engine_mode: 3, // Mode le plus précis (Tesseract + LSTM)
      tessjs_create_hocr: true,    // Créer également du HOCR pour obtenir plus d'informations de position
      tessjs_create_tsv: true,     // Créer du TSV pour une analyse approfondie
    });
    
    const result = await worker.recognize(pageImage);
    return result;
  } catch (error) {
    console.error("Erreur lors de l'OCR:", error);
    throw error;
  } finally {
    if (worker) {
      try {
        await worker.terminate();
      } catch (e) {
        console.error("Error terminating Tesseract worker:", e);
      }
    }
  }
}

// Fonction pour vérifier si une page contient des mots-clés liés à la signature ou au tampon
export async function shouldApplyStampToPage(
  pdfPage: pdfjsLib.PDFPageProxy,
  pageNumber: number
): Promise<boolean> {
  try {
    console.log(`Analyse de la page ${pageNumber+1} pour déterminer si un tampon est nécessaire...`);
    
    // Convertir la page en image pour l'OCR avec résolution améliorée
    const pageImage = await convertPdfPageToImage(pdfPage, 2.5);
    
    // Extraire le texte avec OCR
    const ocrResult = await extractTextFromPage(pageImage);
    
    // Vérifier si le texte contient des mots-clés pertinents
    const pageText = ocrResult.data.text.toLowerCase();
    
    // Nettoyer le texte pour améliorer la détection
    const cleanText = pageText
      .replace(/\s+/g, '') // Supprimer les espaces
      .replace(/[^\w\séèêëàâäôöùûüïîç]/g, ''); // Supprimer les caractères spéciaux sauf les accents
    
    // Vérifier les mots-clés de haute priorité en premier
    for (const keyword of HIGH_PRIORITY_KEYWORDS) {
      if (cleanText.includes(keyword) || pageText.includes(keyword)) {
        console.log(`Page ${pageNumber+1}: Mot-clé de haute priorité trouvé "${keyword}"`);
        return true;
      }
    }
    
    // Vérifier les mots-clés standards
    for (const keyword of STAMP_KEYWORDS) {
      if (cleanText.includes(keyword) || pageText.includes(keyword)) {
        console.log(`Page ${pageNumber+1}: Mot-clé trouvé "${keyword}"`);
        return true;
      }
    }
    
    // Vérifier des phrases spécifiques qui pourraient indiquer une zone de signature
    const signatureIndicators = [
      "signature du bénéficiaire",
      "signature du client",
      "signature du demandeur",
      "lu et approuvé",
      "bon pour accord",
      "fait à",
      "le client",
      "le bénéficiaire"
    ];
    
    for (const phrase of signatureIndicators) {
      if (pageText.includes(phrase)) {
        console.log(`Page ${pageNumber+1}: Phrase indicatrice trouvée "${phrase}"`);
        return true;
      }
    }
    
    // Vérifier si la page contient un formulaire ou une zone pour signature
    const formIndicators = ["nom", "prénom", "date", "adresse", "téléphone"];
    let formIndicatorsCount = 0;
    
    for (const indicator of formIndicators) {
      if (pageText.includes(indicator)) {
        formIndicatorsCount++;
      }
    }
    
    // Si plusieurs indicateurs de formulaire sont présents, c'est probablement une page nécessitant un tampon
    if (formIndicatorsCount >= 3) {
      console.log(`Page ${pageNumber+1}: Multiple indicateurs de formulaire trouvés (${formIndicatorsCount})`);
      return true;
    }
    
    console.log(`Page ${pageNumber+1}: Pas de mot-clé pertinent pour le tampon trouvé`);
    return false;
  } catch (error) {
    console.error(`Erreur lors de l'analyse de la page ${pageNumber+1}:`, error);
    return false; // En cas d'erreur, ne pas appliquer le tampon
  }
}

// Détecte les zones vides qui seraient idéales pour placer un tampon
function detectEmptyAreas(
  ocrResult: Tesseract.RecognizeResult,
  pageWidth: number,
  pageHeight: number,
  stampWidth: number,
  stampHeight: number
): StampPosition[] {
  // Obtenir tous les mots détectés
  const words = ocrResult.data.words || [];
  
  // Créer une grille pour représenter la page
  // Une résolution plus élevée permet une meilleure précision
  const gridResolution = 20; // Nombre de pixels par cellule de grille
  const gridWidth = Math.ceil(pageWidth / gridResolution);
  const gridHeight = Math.ceil(pageHeight / gridResolution);
  
  // Initialiser la grille avec des valeurs à 0 (vide)
  const grid = Array(gridHeight).fill(0).map(() => Array(gridWidth).fill(0));
  
  // Marquer les zones où se trouvent du texte avec des valeurs de 1
  for (const word of words) {
    const bbox = word.bbox;
    
    // Convertir les coordonnées en indices de grille
    const x1 = Math.max(0, Math.floor(bbox.x0 / gridResolution));
    const y1 = Math.max(0, Math.floor(bbox.y0 / gridResolution));
    const x2 = Math.min(gridWidth - 1, Math.ceil(bbox.x1 / gridResolution));
    const y2 = Math.min(gridHeight - 1, Math.ceil(bbox.y1 / gridResolution));
    
    // Marquer les cellules de la grille
    for (let y = y1; y <= y2; y++) {
      for (let x = x1; x <= x2; x++) {
        grid[y][x] = 1;
      }
    }
  }
  
  // Ajouter une marge autour du texte pour éviter que le tampon ne soit trop proche
  const margin = Math.ceil(stampHeight / (3 * gridResolution)); // Marge adaptative en fonction de la taille du tampon
  
  for (let y = 0; y < gridHeight; y++) {
    for (let x = 0; x < gridWidth; x++) {
      if (grid[y][x] === 1) {
        // Ajouter une marge autour de chaque cellule de texte
        for (let dy = -margin; dy <= margin; dy++) {
          for (let dx = -margin; dx <= margin; dx++) {
            const ny = y + dy;
            const nx = x + dx;
            if (ny >= 0 && ny < gridHeight && nx >= 0 && nx < gridWidth && grid[ny][nx] === 0) {
              grid[ny][nx] = 0.5; // Marquer les zones proches du texte
            }
          }
        }
      }
    }
  }
  
  // Trouver les zones vides assez grandes pour contenir le tampon
  const stampGridWidth = Math.ceil(stampWidth / gridResolution);
  const stampGridHeight = Math.ceil(stampHeight / gridResolution);
  
  const emptyAreas: StampPosition[] = [];
  
  // Préférer le bas de la page (50% inférieur)
  const lowerThreshold = gridHeight * 0.5;
  
  // Échantillonner des positions potentielles (ne pas vérifier chaque cellule pour des raisons de performance)
  const sampleRate = 3; // Vérifier une cellule sur 3
  
  for (let y = 0; y < gridHeight - stampGridHeight; y += sampleRate) {
    for (let x = 0; x < gridWidth - stampGridWidth; x += sampleRate) {
      // Vérifier si la zone est vide (pas de texte ni de marge)
      let isEmpty = true;
      let hasPartialOverlap = false;
      
      // Vérifier chaque cellule de la grille couverte par le tampon
      for (let dy = 0; dy < stampGridHeight && isEmpty; dy++) {
        for (let dx = 0; dx < stampGridWidth && isEmpty; dx++) {
          const value = grid[y + dy][x + dx];
          if (value === 1) {
            isEmpty = false; // La zone contient du texte
          } else if (value === 0.5) {
            hasPartialOverlap = true; // La zone est proche du texte
          }
        }
      }
      
      if (isEmpty) {
        // Calculer un score pour cette position
        let score = 50; // Score de base
        
        // Préférer les zones dans la moitié inférieure de la page
        if (y > lowerThreshold) {
          score += 20;
        }
        
        // Préférer les positions éloignées des marges de la page
        const centerX = pageWidth / 2;
        const centerY = pageHeight * 0.75; // Préférer le bas mais pas tout en bas
        
        const distanceFromIdealX = Math.abs((x * gridResolution) - centerX);
        const distanceFromIdealY = Math.abs((y * gridResolution) - centerY);
        
        // Normaliser les distances
        const normalizedDistX = distanceFromIdealX / pageWidth;
        const normalizedDistY = distanceFromIdealY / pageHeight;
        
        // Réduire le score en fonction de la distance au point idéal (mais avec un poids modéré)
        score -= (normalizedDistX + normalizedDistY) * 20;
        
        // Pénaliser légèrement les zones proches du texte
        if (hasPartialOverlap) {
          score -= 10;
        }
        
        // Ajouter cette position à la liste
        emptyAreas.push({
          x: x * gridResolution,
          y: y * gridResolution,
          score: score
        });
      }
    }
  }
  
  return emptyAreas;
}

// Analyse les mots d'une page pour trouver la meilleure position pour le tampon
function analyzeWordsForStampPosition(
  ocrResult: Tesseract.RecognizeResult, 
  pageWidth: number, 
  pageHeight: number,
  stampWidth: number,
  stampHeight: number
): StampPosition[] {
  const positions: StampPosition[] = [];
  const words = ocrResult.data.words || [];
  
  console.log(`OCR a trouvé ${words.length} mots à analyser`);
  
  // Enregistrer un log détaillé des mots trouvés pour débogage
  words.forEach((word, index) => {
    if (index < 10) { // Limiter le nombre de logs pour éviter la surcharge
      console.log(`Mot trouvé: "${word.text}" à la position:`, word.bbox);
    }
  });
  
  // Première passe: rechercher les mots-clés prioritaires
  const priorityMatches = [];
  
  // Fusionner les mots adjacents pour détecter des phrases
  const mergedWords = [];
  for (let i = 0; i < words.length; i++) {
    mergedWords.push(words[i]); // Ajouter le mot actuel
    
    // Si possible, essayer de créer des phrases de 2-3 mots
    if (i < words.length - 1) {
      const currentWord = words[i];
      const nextWord = words[i+1];
      
      // Vérifier si les mots sont adjacents (même ligne, proches horizontalement)
      const sameY = Math.abs(currentWord.bbox.y0 - nextWord.bbox.y0) < 15;
      const closeX = nextWord.bbox.x0 - currentWord.bbox.x1 < 30;
      
      if (sameY && closeX) {
        mergedWords.push({
          text: currentWord.text + " " + nextWord.text,
          bbox: {
            x0: currentWord.bbox.x0,
            y0: Math.min(currentWord.bbox.y0, nextWord.bbox.y0),
            x1: nextWord.bbox.x1,
            y1: Math.max(currentWord.bbox.y1, nextWord.bbox.y1)
          }
        });
        
        // Pour les phrases de 3 mots
        if (i < words.length - 2) {
          const thirdWord = words[i+2];
          const sameYWithThird = Math.abs(nextWord.bbox.y0 - thirdWord.bbox.y0) < 15;
          const closeXWithThird = thirdWord.bbox.x0 - nextWord.bbox.x1 < 30;
          
          if (sameYWithThird && closeXWithThird) {
            mergedWords.push({
              text: currentWord.text + " " + nextWord.text + " " + thirdWord.text,
              bbox: {
                x0: currentWord.bbox.x0,
                y0: Math.min(currentWord.bbox.y0, nextWord.bbox.y0, thirdWord.bbox.y0),
                x1: thirdWord.bbox.x1,
                y1: Math.max(currentWord.bbox.y1, nextWord.bbox.y1, thirdWord.bbox.y1)
              }
            });
          }
        }
      }
    }
  }
  
  // Rechercher dans tous les mots (individuels et combinés)
  for (const word of mergedWords) {
    const text = word.text.toLowerCase();
    
    // Vérifier les mots prioritaires d'abord
    const priorityMatch = HIGH_PRIORITY_KEYWORDS.find(keyword => text.includes(keyword));
    if (priorityMatch) {
      console.log(`Mot-clé prioritaire trouvé: "${word.text}" avec bbox:`, word.bbox);
      priorityMatches.push({
        word,
        keyword: priorityMatch,
        priority: true
      });
    }
  }
  
  // Si nous trouvons des mots prioritaires, utiliser uniquement ceux-là
  const matchesToUse = priorityMatches.length > 0 ? 
    priorityMatches : 
    mergedWords.filter(word => {
      const text = word.text.toLowerCase();
      return STAMP_KEYWORDS.some(keyword => text.includes(keyword));
    }).map(word => {
      console.log(`Mot-clé standard trouvé: "${word.text}" avec bbox:`, word.bbox);
      return {
        word,
        keyword: STAMP_KEYWORDS.find(k => word.text.toLowerCase().includes(k)) || '',
        priority: false
      };
    });
  
  // Traiter les correspondances de mots-clés
  for (const match of matchesToUse) {
    const { word, keyword, priority } = match;
    
    // Base score - higher for priority keywords
    const baseScore = priority ? 95 : 85;
    
    // Position principale: Directement à côté du mot-clé
    positions.push({
      x: word.bbox.x1 + 20, // À droite du mot
      y: word.bbox.y0,      // Aligné verticalement
      score: baseScore
    });
    
    // Position alternative: en-dessous du mot
    positions.push({
      x: Math.max(word.bbox.x0, 20), // Aligné avec le début du mot, avec marge minimale
      y: word.bbox.y1 + 30, // Juste en dessous du mot
      score: baseScore - 5
    });
    
    // Si le mot est "signature" ou "cachet", ajouter des positions spécifiques
    if (word.text.toLowerCase().includes('signature') || 
        word.text.toLowerCase().includes('cachet') ||
        word.text.toLowerCase().includes('tampon') ||
        word.text.toLowerCase().includes('bénéficiaire')) {
      positions.push({
        x: word.bbox.x1 + 80, // Plus à droite pour laisser de la place à une signature manuscrite
        y: word.bbox.y0 + 10, // Aligné
        score: baseScore + 5 // Score très élevé pour cette position privilégiée
      });
    }
  }
  
  // Ajouter la position par défaut demandée par l'utilisateur (120, 370)
  positions.push({
    x: DEFAULT_POSITION.x,
    y: DEFAULT_POSITION.y,
    score: positions.length > 0 ? 60 : 90 // Score élevé uniquement si aucune autre position n'est trouvée
  });
  
  // Ajouter des positions pour les zones vides
  const emptyAreas = detectEmptyAreas(ocrResult, pageWidth, pageHeight, stampWidth, stampHeight);
  positions.push(...emptyAreas);
  
  console.log(`Nombre de positions trouvées: ${positions.length}`);
  
  return positions;
}

// Vérifie si une position est valide (pas de chevauchement avec du texte)
function isPositionValid(
  position: StampPosition,
  ocrResult: Tesseract.RecognizeResult,
  stampWidth: number,
  stampHeight: number
): boolean {
  const words = ocrResult.data.words || [];
  
  // Définir la zone du tampon
  const stampRect = {
    x0: position.x,
    y0: position.y,
    x1: position.x + stampWidth,
    y1: position.y + stampHeight
  };
  
  // Vérifier s'il y a un chevauchement avec du texte
  let overlapCount = 0;
  for (const word of words) {
    const bbox = word.bbox;
    
    // Calculer la surface du mot
    const wordArea = (bbox.x1 - bbox.x0) * (bbox.y1 - bbox.y0);
    
    // Ignorer les mots très petits (probablement du bruit ou des artéfacts)
    if (wordArea < 100) continue;
    
    // Vérifier le chevauchement
    const overlaps = (
      stampRect.x0 < bbox.x1 &&
      stampRect.x1 > bbox.x0 &&
      stampRect.y0 < bbox.y1 &&
      stampRect.y1 > bbox.y0
    );
    
    if (overlaps) {
      // Calculer le pourcentage de chevauchement
      const overlapX = Math.min(stampRect.x1, bbox.x1) - Math.max(stampRect.x0, bbox.x0);
      const overlapY = Math.min(stampRect.y1, bbox.y1) - Math.max(stampRect.y0, bbox.y0);
      
      // Si le chevauchement est significatif
      if (overlapX > 0 && overlapY > 0 && (overlapX * overlapY) > (wordArea * 0.2)) {
        overlapCount++;
      }
    }
  }
  
  // Tolérer un léger chevauchement (jusqu'à 1 mot)
  return overlapCount <= 1;
}

// Fonction pour obtenir les positions par défaut (en bas de la page)
function getDefaultPositions(pageWidth: number, pageHeight: number, stampWidth: number, stampHeight: number): StampPosition[] {
  return [
    // Bas de page à droite
    {
      x: pageWidth * 0.7,
      y: pageHeight * 0.85,
      score: 60
    },
    // Bas de page au centre
    {
      x: (pageWidth - stampWidth) / 2,
      y: pageHeight * 0.85,
      score: 50
    },
    // Bas de page à gauche
    {
      x: pageWidth * 0.1,
      y: pageHeight * 0.85,
      score: 40
    }
  ];
}

// Trouve la meilleure position pour le tampon en utilisant ChatGPT et l'OCR
export async function findOptimalStampPosition(
  pdfPage: pdfjsLib.PDFPageProxy, 
  pageNumber: number,
  pageWidth: number, 
  pageHeight: number,
  stampWidth: number,
  stampHeight: number
): Promise<StampPosition> {
  try {
    console.log(`Analyse de la page ${pageNumber+1} pour positionnement du tampon`);
    
    // Convertir la page en image pour l'OCR avec résolution améliorée
    const pageImage = await convertPdfPageToImage(pdfPage, 2.5);
    
    // Extraire le texte avec OCR
    const ocrResult = await extractTextFromPage(pageImage);
    const pageText = ocrResult.data.text;
    
    console.log(`OCR terminé pour la page ${pageNumber+1}, texte extrait:`, pageText.substring(0, 200) + "...");
    
    // Nouvelle méthode: utiliser l'API ChatGPT pour l'analyse avancée
    try {
      console.log("Utilisation de ChatGPT pour analyser la page...");
      const chatGptResult = await analyzePdfContentForStampPosition(
        pageText,
        pageWidth,
        pageHeight
      );
      
      if (chatGptResult.success && chatGptResult.position) {
        console.log("Position suggérée par ChatGPT:", chatGptResult.position, chatGptResult.message);
        
        // Vérifier que la position est valide (pas hors limites)
        const x = Math.min(Math.max(chatGptResult.position.x, 0), pageWidth - stampWidth);
        const y = Math.min(Math.max(chatGptResult.position.y, 0), pageHeight - stampHeight);
        
        return {
          x, 
          y,
          score: 95 // Score élevé pour la suggestion de ChatGPT
        };
      }
      
      // Si ChatGPT n'a pas pu déterminer une position, utiliser la méthode traditionnelle
      console.log("ChatGPT n'a pas pu déterminer une position, utilisation de la méthode traditionnelle");
    } catch (chatGptError) {
      console.error("Erreur lors de l'analyse avec ChatGPT:", chatGptError);
      console.log("Repli sur la méthode traditionnelle de positionnement");
    }
    
    // Méthode traditionnelle: analyser les mots pour trouver des positions potentielles
    const positions = analyzeWordsForStampPosition(
      ocrResult, 
      pageWidth, 
      pageHeight,
      stampWidth,
      stampHeight
    );
    
    // Filtrer les positions valides (pas de chevauchement avec du texte)
    const validPositions = positions.filter(pos => 
      isPositionValid(pos, ocrResult, stampWidth, stampHeight)
    );
    
    // Si aucune position valide n'est trouvée, utiliser la position par défaut demandée
    if (validPositions.length === 0) {
      console.log(`Page ${pageNumber+1}: Aucune position valide trouvée, utilisation de la position par défaut (${DEFAULT_POSITION.x}, ${DEFAULT_POSITION.y})`);
      return DEFAULT_POSITION;
    }
    
    // Trier les positions par score
    validPositions.sort((a, b) => b.score - a.score);
    
    // Retourner la meilleure position
    console.log(`Page ${pageNumber+1}: Position optimale trouvée (score: ${validPositions[0].score}): x=${validPositions[0].x}, y=${validPositions[0].y}`);
    return validPositions[0];
  } catch (error) {
    console.error(`Erreur lors de l'analyse de la page ${pageNumber+1}:`, error);
    
    // Position par défaut demandée par l'utilisateur
    return DEFAULT_POSITION;
  }
}

// Exporter cette fonction pour permettre de prévisualiser le tampon
export async function getStampPreviewPosition(
  pdfPage: pdfjsLib.PDFPageProxy,
  pageWidth: number,
  pageHeight: number,
  stampWidth: number,
  stampHeight: number
): Promise<StampPosition> {
  try {
    return await findOptimalStampPosition(pdfPage, 0, pageWidth, pageHeight, stampWidth, stampHeight);
  } catch (error) {
    console.error("Erreur lors de la prévisualisation du tampon:", error);
    return DEFAULT_POSITION;
  }
}
