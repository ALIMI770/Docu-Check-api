
/**
 * Service réduit au minimum, uniquement logique locale.
 * Le positionnement est 100% manuel ou par estimation locale basique.
 * Plus aucun appel à une API externe !
 */

interface ChatGptResponse {
  success: boolean;
  position?: {
    x: number;
    y: number;
  };
  message?: string;
}

// Mots-clés pertinents pour le positionnement du tampon
const STAMP_KEYWORDS = [
  'signature', 'cachet', 'tampon', 'approuvé', 'certifié', 
  'validé', 'bénéficiaire', 'fait à', 'date', 'attestation'
];

// Fonction d'analyse simple du texte pour suggérer une position
export const analyzePdfContentForStampPosition = async (
  pageText: string,
  pageWidth: number,
  pageHeight: number
): Promise<ChatGptResponse> => {
  // Utilise directement le fallback local (= manuel ou mot-clé)
  return fallbackLocalPositioning(pageText, pageWidth, pageHeight);
};

// Fonction de repli locale : recherche un mot-clé, sinon coin bas droit
const fallbackLocalPositioning = (
  pageText: string,
  pageWidth: number,
  pageHeight: number
): ChatGptResponse => {
  const lowerText = pageText.toLowerCase();
  for (const keyword of STAMP_KEYWORDS) {
    const index = lowerText.indexOf(keyword);
    if (index !== -1) {
      const charsPerLine = Math.floor(pageWidth / 10);
      const y = Math.min(pageHeight - 150, Math.floor(index / charsPerLine) * 20 + 40);
      const x = Math.min(pageWidth - 300, pageWidth * 0.6);
      return {
        success: true,
        position: { x, y },
        message: `Position basée sur le mot-clé "${keyword}"`
      };
    }
  }
  return {
    success: true,
    position: {
      x: pageWidth - 300,
      y: pageHeight - 150
    },
    message: "Position par défaut (aucun mot-clé trouvé)"
  };
};
