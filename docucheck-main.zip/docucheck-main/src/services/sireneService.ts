
import { SiretVerification, SireneApiResponse } from './types';

// Valide un SIRET en utilisant l'algorithme de Luhn
const validateSiretFormat = (siret: string): boolean => {
  // Vérifier que le SIRET a bien 14 chiffres
  if (!/^\d{14}$/.test(siret)) {
    return false;
  }
  
  // Algorithme de Luhn
  let sum = 0;
  let alternate = false;
  
  for (let i = siret.length - 1; i >= 0; i--) {
    let n = parseInt(siret.charAt(i), 10);
    
    if (alternate) {
      n *= 2;
      if (n > 9) {
        n = (n % 10) + 1;
      }
    }
    
    sum += n;
    alternate = !alternate;
  }
  
  return (sum % 10 === 0);
};

// Fonction pour vérifier un SIRET via l'API SIRENE
export const verifySiret = async (siret: string): Promise<SiretVerification> => {
  console.log("Vérification du SIRET:", siret);
  
  // Vérification basique du format (algorithme de Luhn)
  const isFormatValid = validateSiretFormat(siret);
  
  if (!isFormatValid) {
    return {
      isValid: false,
      error: "Format de SIRET invalide"
    };
  }
  
  try {
    // Appel à l'API SIRENE (INSEE)
    const response = await fetch(`https://api.insee.fr/entreprises/sirene/V3/siret/${siret}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${process.env.INSEE_API_KEY || localStorage.getItem('insee_api_key')}`,
        'Accept': 'application/json'
      }
    });
    
    // Si l'API n'est pas disponible ou une erreur se produit, on utilise la vérification locale
    if (!response.ok) {
      console.warn(`API SIRENE non disponible ou erreur: ${response.status}. Utilisation de la vérification locale.`);
      
      // Dans un environnement de démo, considérer le SIRET comme valide si format correct
      return {
        isValid: true,  // On considère valide pour la démo si le format est correct
        companyName: "Entreprise (vérification locale uniquement)",
        address: "Adresse non vérifiée par l'API",
        status: "Statut inconnu"
      };
    }
    
    const data = await response.json() as SireneApiResponse;
    
    // Extraction des données de la réponse
    const uniteLegale = data.etablissement?.uniteLegale;
    const adresse = data.etablissement?.adresseEtablissement;
    
    if (!uniteLegale) {
      return {
        isValid: false,
        error: "Établissement non trouvé"
      };
    }
    
    // Déterminer le nom de l'entreprise
    const companyName = uniteLegale.denominationUniteLegale || 
                      (uniteLegale.nomUniteLegale ? 
                        `${uniteLegale.nomUniteLegale} ${uniteLegale.prenomUsuelUniteLegale || ''}` : 
                        "Nom non disponible");
    
    // Construire l'adresse
    const addressParts = [
      adresse?.numeroVoieEtablissement,
      adresse?.typeVoieEtablissement,
      adresse?.libelleVoieEtablissement,
      adresse?.codePostalEtablissement,
      adresse?.libelleCommuneEtablissement
    ].filter(Boolean);
    
    const address = addressParts.join(' ');
    
    // Vérifier si l'établissement est actif
    const isActive = uniteLegale.etatAdministratifUniteLegale === "A";
    
    return {
      isValid: true,
      companyName,
      address,
      status: isActive ? "Actif" : "Fermé"
    };
    
  } catch (error) {
    console.error("Erreur lors de la vérification SIRET:", error);
    
    // En cas d'erreur, on peut toujours utiliser la vérification locale
    return {
      isValid: true,  // On considère valide pour la démo si le format est correct
      companyName: "Entreprise (vérification locale uniquement)",
      address: "Adresse non vérifiée - erreur API",
      status: "Statut inconnu",
      error: error instanceof Error ? error.message : "Erreur inconnue"
    };
  }
};
