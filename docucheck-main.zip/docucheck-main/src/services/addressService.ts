
/**
 * Service pour l'autocomplétion et la recherche d'adresses
 * Utilise l'API-Adresse.data.gouv.fr (Base Adresse Nationale)
 */

export interface AddressSuggestion {
  displayName: string;
  address: string;
  lat: number;
  lng: number;
}

/**
 * Recherche des suggestions d'adresses à partir d'un texte partiel
 * @param query Le texte de recherche d'adresse
 * @returns Une liste de suggestions d'adresses
 */
export const searchAddressSuggestions = async (query: string): Promise<AddressSuggestion[]> => {
  if (!query || query.length < 3) {
    return [];
  }
  
  try {
    // Utiliser l'API Adresse.data.gouv.fr (Base Adresse Nationale française)
    const response = await fetch(
      `https://api-adresse.data.gouv.fr/search/?q=${encodeURIComponent(query)}&limit=5`,
      {
        headers: {
          "Accept-Language": "fr"
        },
      }
    );

    if (!response.ok) {
      console.error("Erreur API-Adresse (recherche):", response.statusText);
      return [];
    }

    const data = await response.json();
    
    if (!data || !data.features || data.features.length === 0) {
      return [];
    }

    // Traiter les résultats pour obtenir des suggestions formatées
    return data.features.map((feature: any) => {
      const properties = feature.properties;
      const coordinates = feature.geometry.coordinates;
      
      // Formater l'adresse avec numéro, rue, code postal et ville
      let formattedAddress = '';
      const parts = [];
      
      if (properties.housenumber) {
        parts.push(properties.housenumber);
      }
      
      if (properties.street) {
        parts.push(properties.street);
      }
      
      const cityPart = [];
      if (properties.postcode) {
        cityPart.push(properties.postcode);
      }
      
      if (properties.city) {
        cityPart.push(properties.city);
      }
      
      if (cityPart.length > 0) {
        parts.push(cityPart.join(' '));
      }
      
      formattedAddress = parts.join(', ');
      
      return {
        displayName: properties.label,
        address: formattedAddress || properties.label,
        lat: coordinates[1], // API Adresse retourne [lon, lat]
        lng: coordinates[0]
      };
    });
    
  } catch (error) {
    console.error("Erreur de recherche d'adresses:", error);
    return [];
  }
};
