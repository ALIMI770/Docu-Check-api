import { AnalysisResult, CheckResult } from '@/types/document';
import { OcrResults } from './types';

interface GptAnalysis {
  documentType: string;
  entreprise: {
    nom: string;
    siret: string;
    adresse: string;
  };
  client: {
    adresseTravaux: string;
  };
  montants: {
    ht: number;
    ttc: number;
  };
  date: string;
  tampon: {
    present: boolean;
    texte: string;
  };
  manuscrit: {
    bonPourAccord: boolean;
    signature: boolean;
    nom: string;
    fonction: string;
    date: string;
  };
  error?: string;
  rawContent?: string;
}

// Fonction pour extraire l'analyse JSON de GPT Vision
const extractGptAnalysis = (text: string): GptAnalysis | null => {
  try {
    // Rechercher le contenu JSON dans la sortie
    const jsonMatch = text.match(/===\s*ANALYSE\s*GPT\s*VISION\s*===([\s\S]*)/i);
    if (jsonMatch && jsonMatch[1]) {
      return JSON.parse(jsonMatch[1].trim());
    }
    return null;
  } catch (error) {
    console.error("Erreur lors de l'extraction de l'analyse GPT:", error);
    return null;
  }
};

// Fonction pour comparer deux dates et vérifier leur cohérence
const areDatesConsistent = (date1: string, date2: string): boolean => {
  if (!date1 || !date2) return false;
  
  try {
    // Convertir les dates au format JJ/MM/AAAA en objets Date
    const [day1, month1, year1] = date1.split('/').map(Number);
    const [day2, month2, year2] = date2.split('/').map(Number);
    
    // Vérifier si les dates sont valides
    if (isNaN(day1) || isNaN(month1) || isNaN(year1) || 
        isNaN(day2) || isNaN(month2) || isNaN(year2)) {
      return false;
    }
    
    // Comparer les dates
    const date1Obj = new Date(year1, month1 - 1, day1);
    const date2Obj = new Date(year2, month2 - 1, day2);
    
    // Calculer la différence en jours
    const diffTime = Math.abs(date2Obj.getTime() - date1Obj.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    // Les dates sont considérées cohérentes si elles sont identiques ou proches (moins de 3 jours d'écart)
    return diffDays <= 3;
  } catch (error) {
    console.error("Erreur lors de la comparaison des dates:", error);
    return false;
  }
};

// Fonction pour générer le rapport d'analyse
export const generateAnalysisReport = async (texts: OcrResults): Promise<AnalysisResult> => {
  // Initialiser le score et les résultats
  let score = 0;
  const checks: CheckResult[] = [];
  const recommendations: string[] = [];
  let siretFound = "";
  
  // Extraire les analyses GPT pour chaque document
  const devisAnalysis = texts.devis ? extractGptAnalysis(texts.devis.toString()) : null;
  const factureAnalysis = texts.facture ? extractGptAnalysis(texts.facture.toString()) : null;
  const attestationAnalysis = texts.attestation ? extractGptAnalysis(texts.attestation.toString()) : null;
  
  console.log("Analyses extraites:", { devisAnalysis, factureAnalysis, attestationAnalysis });
  
  // Si au moins deux documents ont été analysés
  if ((devisAnalysis && attestationAnalysis) || 
      (devisAnalysis && factureAnalysis) || 
      (factureAnalysis && attestationAnalysis)) {
    
    // 1. Vérifier les SIRET
    const sirets = [
      devisAnalysis?.entreprise?.siret,
      factureAnalysis?.entreprise?.siret,
      attestationAnalysis?.entreprise?.siret
    ].filter(Boolean);
    
    if (sirets.length > 0) {
      const uniqueSirets = [...new Set(sirets)];
      const siretConsistent = uniqueSirets.length === 1;
      
      siretFound = uniqueSirets[0];
      
      checks.push({
        name: "Cohérence SIRET",
        status: siretConsistent ? "success" : "warning",
        details: siretConsistent
          ? `Le SIRET ${siretFound} est cohérent entre tous les documents (GPT Vision)`
          : `Les SIRET diffèrent entre les documents: ${uniqueSirets.join(', ')} (GPT Vision)`
      });
      
      score += siretConsistent ? 15 : 0;
    }
    
    // 2. Vérifier la cohérence des montants
    if (devisAnalysis?.montants && factureAnalysis?.montants) {
      const devisTTC = devisAnalysis.montants.ttc;
      const factureTTC = factureAnalysis.montants.ttc;
      
      const amountsConsistent = Math.abs(devisTTC - factureTTC) <= 1; // Tolérance de 1€
      
      checks.push({
        name: "Cohérence des montants",
        status: amountsConsistent ? "success" : "warning",
        details: amountsConsistent 
          ? `Les montants concordent entre le devis (${devisTTC} €) et la facture (${factureTTC} €) (GPT Vision)`
          : `Les montants diffèrent: devis (${devisTTC} €), facture (${factureTTC} €) (GPT Vision)`
      });
      
      score += amountsConsistent ? 15 : 0;
    }
    
    // 3. Vérifier la cohérence des dates entre documents
    if (devisAnalysis?.date && attestationAnalysis?.date) {
      const devisDate = devisAnalysis.date;
      const attestationDate = attestationAnalysis.date;
      
      const datesConsistent = areDatesConsistent(devisDate, attestationDate);
      
      checks.push({
        name: "Cohérence des dates entre documents",
        status: datesConsistent ? "success" : "warning",
        details: datesConsistent 
          ? `Les dates du devis (${devisDate}) et de l'attestation (${attestationDate}) sont cohérentes (GPT Vision)`
          : `Les dates du devis (${devisDate}) et de l'attestation (${attestationDate}) ne sont pas cohérentes (GPT Vision)`
      });
      
      score += datesConsistent ? 15 : 0;
    }
    
    // 4. Vérifier la cohérence entre date du document et date manuscrite
    if (devisAnalysis?.date && devisAnalysis?.manuscrit?.date) {
      const devisDate = devisAnalysis.date;
      const devisManuscritDate = devisAnalysis.manuscrit.date;
      
      const datesConsistent = areDatesConsistent(devisDate, devisManuscritDate);
      
      checks.push({
        name: "Cohérence date document/manuscrite",
        status: datesConsistent ? "success" : "warning",
        details: datesConsistent 
          ? `La date du devis (${devisDate}) correspond à la date manuscrite (${devisManuscritDate}) (GPT Vision)`
          : `La date du devis (${devisDate}) ne correspond pas à la date manuscrite (${devisManuscritDate}) (GPT Vision)`
      });
      
      score += datesConsistent ? 10 : 0;
    }
    
    // 5. Vérifier les informations manuscrites
    if (attestationAnalysis?.manuscrit) {
      const { bonPourAccord, signature, nom, fonction, date } = attestationAnalysis.manuscrit;
      
      const hasAllManuscritInfo = bonPourAccord && signature && nom && fonction && date;
      
      checks.push({
        name: "Mentions manuscrites",
        status: hasAllManuscritInfo ? "success" : "warning",
        details: hasAllManuscritInfo 
          ? `Toutes les mentions manuscrites sont présentes: "bon pour accord", signature, nom (${nom}), fonction (${fonction}), date (${date}) (GPT Vision)`
          : `Certaines mentions manuscrites sont manquantes: ${!bonPourAccord ? '"Bon pour accord" manquant, ' : ''}${!signature ? 'Signature manquante, ' : ''}${!nom ? 'Nom manquant, ' : ''}${!fonction ? 'Fonction manquante, ' : ''}${!date ? 'Date manquante' : ''} (GPT Vision)`
      });
      
      score += hasAllManuscritInfo ? 20 : (bonPourAccord || signature || nom || fonction || date ? 10 : 0);
    }
    
    // 6. Vérifier le tampon
    if (devisAnalysis?.tampon) {
      checks.push({
        name: "Tampon sur devis",
        status: devisAnalysis.tampon.present ? "success" : "warning",
        details: devisAnalysis.tampon.present 
          ? `Tampon détecté avec le texte: "${devisAnalysis.tampon.texte}" (GPT Vision)`
          : `Aucun tampon détecté sur le devis (GPT Vision)`
      });
      
      score += devisAnalysis.tampon.present ? 15 : 0;
    }
    
    // 7. Vérifier l'adresse des travaux
    if (attestationAnalysis?.client?.adresseTravaux) {
      const adresseTravaux = attestationAnalysis.client.adresseTravaux;
      
      checks.push({
        name: "Adresse de réalisation",
        status: adresseTravaux ? "success" : "warning",
        details: adresseTravaux
          ? `Adresse de réalisation détectée: '${adresseTravaux}' (GPT Vision)`
          : `Adresse de réalisation non détectée (GPT Vision)`
      });
      
      score += adresseTravaux ? 10 : 0;
    }
    
    // Ajouter des recommandations en fonction des résultats
    if (checks.some(check => check.status === "warning" || check.status === "error")) {
      const warningChecks = checks.filter(check => check.status === "warning" || check.status === "error");
      
      warningChecks.forEach(check => {
        if (check.name === "Mentions manuscrites") {
          recommendations.push("S'assurer que toutes les mentions manuscrites sont présentes et lisibles sur l'attestation sur l'honneur");
        } else if (check.name === "Tampon sur devis") {
          recommendations.push("Vérifier que le tampon de l'entreprise est bien apposé sur le devis");
        } else if (check.name === "Cohérence des dates entre documents") {
          recommendations.push("S'assurer que les dates sur tous les documents sont cohérentes");
        } else if (check.name === "Cohérence date document/manuscrite") {
          recommendations.push("Vérifier que la date manuscrite correspond bien à la date du document");
        }
      });
    }
  } else {
    // Si pas assez de documents pour comparer
    recommendations.push("Veuillez télécharger au moins deux documents pour une analyse complète (devis et attestation sur l'honneur recommandés)");
  }
  
  return {
    score: Math.min(100, score), // Limiter le score à 100 maximum
    timestamp: new Date().toISOString(),
    checks,
    recommendations,
    siretFound
  };
};
