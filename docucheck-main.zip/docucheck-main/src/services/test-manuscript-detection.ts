/**
 * Script de test pour la détection des zones manuscrites
 * 
 * Ce fichier peut être utilisé pour tester rapidement la détection
 * sans passer par l'interface utilisateur complète.
 */

import { detectManuscriptZones } from './manuscriptDetectionService';

/**
 * Test avec une image de base
 */
export async function testManuscriptDetection(imageDataUrl: string) {
  console.log("🔍 Début du test de détection manuscrite...");
  console.log("=".repeat(60));
  
  const startTime = performance.now();
  
  try {
    const result = await detectManuscriptZones(imageDataUrl);
    
    const endTime = performance.now();
    const duration = ((endTime - startTime) / 1000).toFixed(2);
    
    console.log("\n✅ Détection terminée avec succès");
    console.log(`⏱️  Temps d'exécution: ${duration}s`);
    console.log("=".repeat(60));
    
    console.log("\n📊 RÉSULTATS:");
    console.log(`   Manuscrit détecté: ${result.hasManuscript ? '✓ OUI' : '✗ NON'}`);
    console.log(`   Nombre de zones: ${result.zones.length}`);
    
    if (result.globalBoundingBox) {
      console.log(`   Boîte englobante: ${result.globalBoundingBox}`);
      
      const [x, y, width, height] = result.globalBoundingBox.split(',').map(Number);
      console.log(`   - Position X: ${x.toFixed(1)}%`);
      console.log(`   - Position Y: ${y.toFixed(1)}%`);
      console.log(`   - Largeur: ${width.toFixed(1)}%`);
      console.log(`   - Hauteur: ${height.toFixed(1)}%`);
    }
    
    if (result.zones.length > 0) {
      console.log("\n📍 DÉTAILS DES ZONES:");
      result.zones.forEach((zone, index) => {
        console.log(`\n   Zone ${index + 1}:`);
        console.log(`   - Type: ${zone.type}`);
        console.log(`   - Position: (${zone.x.toFixed(1)}%, ${zone.y.toFixed(1)}%)`);
        console.log(`   - Taille: ${zone.width.toFixed(1)}% × ${zone.height.toFixed(1)}%`);
        console.log(`   - Confiance: ${zone.confidence.toFixed(0)}%`);
      });
    }
    
    console.log("\n" + "=".repeat(60));
    
    return result;
    
  } catch (error) {
    console.error("\n❌ ERREUR lors de la détection:");
    console.error(error);
    throw error;
  }
}

/**
 * Exemple d'utilisation dans la console du navigateur:
 * 
 * // 1. Importer la fonction
 * import { testManuscriptDetection } from '@/services/test-manuscript-detection';
 * 
 * // 2. Tester avec une image
 * const imageUrl = "data:image/jpeg;base64,...";
 * await testManuscriptDetection(imageUrl);
 * 
 * // 3. Ou tester avec un élément <img> existant
 * const img = document.querySelector('img');
 * const canvas = document.createElement('canvas');
 * canvas.width = img.naturalWidth;
 * canvas.height = img.naturalHeight;
 * const ctx = canvas.getContext('2d');
 * ctx.drawImage(img, 0, 0);
 * const dataUrl = canvas.toDataURL('image/jpeg');
 * await testManuscriptDetection(dataUrl);
 */

/**
 * Test de performance avec plusieurs images
 */
export async function testBatchPerformance(imageDataUrls: string[]) {
  console.log(`🚀 Test de performance avec ${imageDataUrls.length} image(s)...`);
  console.log("=".repeat(60));
  
  const startTime = performance.now();
  const results = [];
  
  for (let i = 0; i < imageDataUrls.length; i++) {
    console.log(`\n📄 Traitement image ${i + 1}/${imageDataUrls.length}...`);
    
    const imageStart = performance.now();
    const result = await detectManuscriptZones(imageDataUrls[i]);
    const imageEnd = performance.now();
    
    const imageDuration = ((imageEnd - imageStart) / 1000).toFixed(2);
    console.log(`   ✓ Terminé en ${imageDuration}s - ${result.zones.length} zone(s) trouvée(s)`);
    
    results.push(result);
  }
  
  const endTime = performance.now();
  const totalDuration = ((endTime - startTime) / 1000).toFixed(2);
  const avgDuration = (parseFloat(totalDuration) / imageDataUrls.length).toFixed(2);
  
  console.log("\n" + "=".repeat(60));
  console.log("📊 STATISTIQUES GLOBALES:");
  console.log(`   Temps total: ${totalDuration}s`);
  console.log(`   Temps moyen par image: ${avgDuration}s`);
  console.log(`   Images avec manuscrit: ${results.filter(r => r.hasManuscript).length}/${results.length}`);
  console.log(`   Total zones détectées: ${results.reduce((sum, r) => sum + r.zones.length, 0)}`);
  console.log("=".repeat(60));
  
  return results;
}

/**
 * Compare les résultats avec des coordonnées attendues (pour validation)
 */
export function compareCoordinates(
  detected: string,
  expected: string,
  tolerancePercent: number = 5
) {
  if (!detected || !expected) {
    return {
      match: false,
      reason: "Coordonnées manquantes"
    };
  }
  
  const [dx, dy, dw, dh] = detected.split(',').map(Number);
  const [ex, ey, ew, eh] = expected.split(',').map(Number);
  
  const diffX = Math.abs(dx - ex);
  const diffY = Math.abs(dy - ey);
  const diffW = Math.abs(dw - ew);
  const diffH = Math.abs(dh - eh);
  
  const match = diffX <= tolerancePercent && 
                diffY <= tolerancePercent && 
                diffW <= tolerancePercent && 
                diffH <= tolerancePercent;
  
  return {
    match,
    differences: {
      x: diffX.toFixed(2),
      y: diffY.toFixed(2),
      width: diffW.toFixed(2),
      height: diffH.toFixed(2)
    },
    tolerance: tolerancePercent
  };
}
