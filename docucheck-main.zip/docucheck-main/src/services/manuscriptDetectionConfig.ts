/**
 * Configuration pour la détection des zones manuscrites
 * 
 * Ajustez ces paramètres selon vos besoins pour affiner la détection
 */

export const MANUSCRIPT_DETECTION_CONFIG = {
  /**
   * Seuil de confiance pour identifier du manuscrit
   * Plus bas = plus strict (détecte moins)
   * Plus haut = plus permissif (détecte plus)
   * 
   * Valeur recommandée: 50-70
   */
  CONFIDENCE_THRESHOLD: 60,
  
  /**
   * Position minimale (en % de la hauteur) pour rechercher du manuscrit
   * Les éléments manuscrits sont généralement en bas de page
   * 
   * 0 = toute la page
   * 50 = moitié inférieure
   * 70 = dernier tiers
   * 
   * Valeur recommandée: 40-50
   */
  MIN_Y_POSITION: 40,
  
  /**
   * Longueur maximale du texte pour être considéré comme manuscrit
   * 
   * Valeur recommandée: 10-20
   */
  MAX_TEXT_LENGTH: 15,
  
  /**
   * Surface maximale d'un mot par rapport à la page (en %)
   * Empêche de détecter de gros blocs de texte
   * 
   * Valeur recommandée: 0.01-0.03 (1%-3%)
   */
  MAX_WORD_AREA: 0.02,
  
  /**
   * Nombre minimum de critères à respecter (sur 4 possibles)
   * Plus c'est élevé, plus c'est strict
   * 
   * Critères:
   * 1. Confiance très faible
   * 2. Position dans la moitié inférieure
   * 3. Texte court
   * 4. Zone petite
   * 
   * Valeur recommandée: 2-3
   */
  MIN_CRITERIA_COUNT: 2,
  
  /**
   * Nombre maximum de zones potentielles avant filtrage strict
   * Si dépassé, applique un filtrage encore plus strict
   * 
   * Valeur recommandée: 30-50
   */
  MAX_POTENTIAL_ZONES: 50,
  
  /**
   * Seuil de confiance pour le filtrage strict (quand trop de zones)
   * 
   * Valeur recommandée: 40-50
   */
  STRICT_CONFIDENCE_THRESHOLD: 50,
  
  /**
   * Surface maximale d'une zone finale par rapport à la page (en %)
   * Empêche de retourner des zones qui couvrent toute la page
   * 
   * Valeur recommandée: 0.20-0.40 (20%-40%)
   */
  MAX_ZONE_AREA: 0.30,
  
  // Distance maximale pour regrouper deux zones (en % de la taille de l'image)
  CLUSTERING: {
    // Distance horizontale maximale - Valeur recommandée: 0.02-0.05 (2%-5%)
    MAX_DISTANCE_X: 0.02,
    
    // Distance verticale maximale - Valeur recommandée: 0.03-0.06 (3%-6%)
    MAX_DISTANCE_Y: 0.03,
  },
  
  // Marge ajoutée autour des zones détectées (en % de la taille de la zone)
  // Valeur recommandée: 0.03-0.05 (3%-5%)
  ZONE_MARGIN: 0.03,
  
  // Activer les logs de débogage
  DEBUG_LOGS: true,
};

/**
 * Profils prédéfinis pour différents types de documents
 */
export const DETECTION_PROFILES = {
  /**
   * Profil STRICT - Pour des documents avec peu d'éléments manuscrits
   * Réduit les faux positifs
   */
  STRICT: {
    ...MANUSCRIPT_DETECTION_CONFIG,
    CONFIDENCE_THRESHOLD: 50,
    MIN_Y_POSITION: 50,
    MAX_TEXT_LENGTH: 12,
    MIN_CRITERIA_COUNT: 3,
    MAX_ZONE_AREA: 0.20,
  },
  
  /**
   * Profil NORMAL - Configuration par défaut
   * Équilibre entre précision et rappel
   */
  NORMAL: MANUSCRIPT_DETECTION_CONFIG,
  
  /**
   * Profil PERMISSIF - Pour détecter plus d'éléments
   * Augmente les faux positifs mais réduit les faux négatifs
   */
  PERMISSIVE: {
    ...MANUSCRIPT_DETECTION_CONFIG,
    CONFIDENCE_THRESHOLD: 70,
    MIN_Y_POSITION: 30,
    MAX_TEXT_LENGTH: 20,
    MIN_CRITERIA_COUNT: 2,
    MAX_ZONE_AREA: 0.40,
    CLUSTERING: {
      MAX_DISTANCE_X: 0.05,
      MAX_DISTANCE_Y: 0.06,
    },
  },
};

/**
 * Obtenir le profil de détection selon le type
 */
export function getDetectionProfile(profileName: 'STRICT' | 'NORMAL' | 'PERMISSIVE' = 'NORMAL') {
  return DETECTION_PROFILES[profileName];
}
